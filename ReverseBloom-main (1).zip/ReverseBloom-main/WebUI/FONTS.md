# Используемые шрифты

## Barlow
- Семейство CSS: `Barlow`.
- Начертания, подключённые в проекте: Regular 400, Medium 500, SemiBold 600, Bold 700, ExtraBold 800.
- Используется для логотипа, меню, пресетов и основного текста.
- Каталог: https://fonts.google.com/specimen/Barlow

## Barlow Condensed
- Семейство CSS: `Barlow Condensed`.
- Начертания: Regular 400, Medium 500, SemiBold 600.
- Используется для подписей регуляторов, чисел, ритмического дисплея и переключателей эффектов.
- Каталог: https://fonts.google.com/specimen/Barlow+Condensed

## Подключение
В начале `src/index.css` уже есть Google Fonts CSS2 import со всеми указанными начертаниями.
Резервное семейство — `sans-serif`.

Файлы TTF/WOFF2 в архив не включены: проект использует загрузку через Google Fonts.
Для работы полностью офлайн скачайте семейства из официального каталога, сохраните нужные
файлы в `public/fonts/`, замените Google Fonts import на правила @font-face и приложите
оригинальные файлы лицензии SIL Open Font License из загруженного пакета шрифтов.

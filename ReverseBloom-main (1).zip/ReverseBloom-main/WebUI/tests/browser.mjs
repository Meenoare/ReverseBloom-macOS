import { chromium } from '@playwright/test';
import { createServer } from 'node:http';import {readFile} from 'node:fs/promises';import {extname,resolve} from 'node:path';import assert from 'node:assert/strict';
const server=createServer(async(req,res)=>{try{const path=resolve('dist',req.url==='/'?'index.html':'.'+decodeURI(req.url));const type={'.html':'text/html','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.woff2':'font/ttf'}[extname(path)]||'application/octet-stream';res.setHeader('Content-Type',type);res.end(await readFile(path))}catch{res.statusCode=404;res.end()}});await new Promise(r=>server.listen(4173,'127.0.0.1',r));
const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
try {
const page=await browser.newPage({viewport:{width:1280,height:1104}});const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:4173');await page.evaluate(()=>document.fonts.ready);
await page.getByLabel('Sound preset',{exact:true}).selectOption('1');assert.equal(await page.getByLabel('Room value',{exact:true}).inputValue(),'0.86');
await page.getByLabel('Room value',{exact:true}).fill('0.61');await page.getByRole('button',{name:'Compare: A active'}).click();assert.equal(await page.getByLabel('Room value',{exact:true}).inputValue(),'0.80');await page.getByRole('button',{name:'Compare: B active'}).click();assert.equal(await page.getByLabel('Room value',{exact:true}).inputValue(),'0.61');
await page.getByRole('button',{name:'TREMOLO',exact:true}).click();assert.equal(await page.getByLabel('LFO target',{exact:false}).count(),1);assert.equal(await page.locator('.settings-grid select').count(),4);
await page.getByRole('button',{name:'OUTPUT',exact:true}).click();assert.equal(await page.getByLabel('Level value',{exact:true}).count(),1);
await page.getByRole('button',{name:'MENU',exact:true}).click();await page.getByText('Length and export',{exact:true}).click();await page.locator('.settings-menu .setting').filter({hasText:'Length mode'}).locator('select').selectOption('1');await page.locator('.settings-menu .setting').filter({hasText:'Length (ms)'}).locator('input').fill('1250');await page.getByRole('button',{name:'Close menu'}).click();assert.equal(await page.locator('.rhythm-value').innerText(),'1250 ms');
// Inject a host adapter and test incoming automation, result display and outbound controls.
await page.evaluate(()=>{window.__sent=[];window.reverseBloomHost={send:m=>window.__sent.push(m)};window.reverseBloomReceive({type:'state',values:{lengthmode:0,length:0},sourceReady:true,resultReady:true,playing:false,meters:[.2,.4]});window.reverseBloomReceive({type:'waveform',bins:Array.from({length:145},(_,i)=>Math.sin(i/20)*.3),playhead:.4})});
await page.getByRole('button',{name:'LISTEN',exact:true}).click();assert.ok(await page.evaluate(()=>window.__sent.some(m=>m.action==='listen')));
await page.getByRole('button',{name:'CHORUS',exact:true}).click();await page.getByLabel('Room value',{exact:true}).fill('0.75');assert.ok(await page.evaluate(()=>window.__sent.some(m=>m.type==='parameters'&&m.values.size===.75)));
assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth),false);
// Return to idle for a truthful screenshot, no simulated playing status.
await page.evaluate(()=>window.reverseBloomReceive({type:'state',sourceReady:false,resultReady:false}));await page.evaluate(()=>window.reverseBloomReceive({type:'waveform',bins:[]}));await page.screenshot({path:'preview-chorus.png',fullPage:true});
// RAW pointer selection must send normalized bounds and never start file drag.
await page.evaluate(()=>{window.reverseBloomReceive({type:'state',sourceReady:true,resultReady:true,selection:[0,1]});window.reverseBloomReceive({type:'waveform',bins:Array(145).fill(.2)})});
await page.getByRole('button',{name:'RAW',exact:true}).click();
const bounds=await page.locator('.wave-screen').boundingBox();
await page.mouse.move(bounds.x+16+(bounds.width-32)*.2,bounds.y+70);await page.mouse.down();await page.mouse.move(bounds.x+16+(bounds.width-32)*.7,bounds.y+70,{steps:8});await page.mouse.up();
const selection=await page.evaluate(()=>window.__sent.filter(x=>x.type==='selection').at(-1));assert.ok(Math.abs(selection.selection[0]-.2)<.01);assert.ok(Math.abs(selection.selection[1]-.7)<.01);
assert.equal(await page.locator('.selection-overlay').count(),1);
await page.getByRole('button',{name:'Preview mode',exact:true}).click();assert.equal(await page.getByRole('button',{name:'Preview mode',exact:true}).innerText(),'Tail Source');
await page.getByRole('button',{name:'Preview mode',exact:true}).click();assert.equal(await page.getByRole('button',{name:'Preview mode',exact:true}).innerText(),'Tail');
await page.getByRole('button',{name:'OUTPUT',exact:true}).click();assert.equal(await page.getByRole('button',{name:'Auto Gain',exact:true}).count(),1);await page.getByRole('button',{name:'Gain Lock',exact:true}).click();assert.equal(await page.getByRole('button',{name:'Gain Lock',exact:true}).getAttribute('aria-pressed'),'true');
await page.getByRole('button',{name:'CHORUS',exact:true}).click();
assert.equal(await page.locator('.signature').innerText(),'@BYMEENOARE');
for(const field of await page.locator('.filter .value-input').all()){const box=await field.boundingBox();assert.ok(box.height>=29);assert.ok(box.width>=80)}
const bottom=await page.evaluate(()=>{const a=document.querySelector('.instrument').getBoundingClientRect(),b=document.querySelector('.signature').getBoundingClientRect();return a.bottom-b.bottom});assert.ok(bottom<=10);
await page.evaluate(()=>{window.reverseBloomReceive({type:'state',sourceReady:false,resultReady:false});window.reverseBloomReceive({type:'waveform',bins:[]})});
const first=await page.locator('canvas').evaluate(c=>c.toDataURL());await page.waitForTimeout(250);const second=await page.locator('canvas').evaluate(c=>c.toDataURL());assert.notEqual(first,second);
await page.getByRole('button',{name:'EDIT',exact:true}).click();await page.screenshot({path:'preview-chorus.png',fullPage:true});
console.log('PASS: RAW pointer selection, Tail toggle, gain buttons, field bounds, footer height and idle Canvas motion');

const sizes=[];for(const tab of ['CHORUS','TREMOLO','OUTPUT']){await page.getByRole('button',{name:tab,exact:true}).click();sizes.push(await page.locator('.instrument').evaluate(el=>el.offsetHeight))}assert.equal(new Set(sizes).size,1);console.log('Fixed page height',sizes);
assert.equal(await page.locator('a.brand').count(),0);
const aligned=await page.locator('.listen-controls>button').evaluateAll(els=>els.map(e=>{const r=e.getBoundingClientRect();return {y:r.y,h:r.height}}));assert.ok(aligned.every(r=>Math.abs(r.y-aligned[0].y)<.1&&Math.abs(r.h-28)<.1));
await page.evaluate(()=>{window.reverseBloomReceive({type:'state',sourceReady:false,recording:false});window.reverseBloomReceive({type:'waveform',bins:Array(145).fill(0)})});
const idle1=await page.locator('canvas').evaluate(c=>c.toDataURL());await page.waitForTimeout(350);assert.notEqual(idle1,await page.locator('canvas').evaluate(c=>c.toDataURL()));
await page.getByRole('button',{name:'RESET',exact:true}).click();assert.ok(await page.evaluate(()=>window.__sent.some(m=>m.action==='reset')));assert.equal(await page.locator('.notice').count(),0);
await page.getByRole('button',{name:'CHORUS',exact:true}).click();await page.screenshot({path:'preview-chorus.png',fullPage:true});
console.log('PASS: fixed panel/page heights, aligned Listen/Loop/Tail, noninteractive logo, animated zero-bin idle and silent reset command');

// Physical WebView viewport shrinks along with the native editor.
const geometry=[];
for(const [index,scale] of [[2,1],[1,.75],[0,.5]]){
 await page.setViewportSize({width:1280*scale,height:Math.floor(1150*scale)});
 await page.evaluate(index=>window.reverseBloomReceive({type:'state',uiScale:index}),index);
 await page.waitForTimeout(80);
 geometry.push(await page.evaluate(()=>{const root=document.querySelector('#root').getBoundingClientRect();return ['.preset-group','.preset-select','.master-control','.parameter-panel','.effect-switch'].map(sel=>{const el=document.querySelector(sel),r=el.getBoundingClientRect(),scale=root.width/1280;return [r.x/scale,r.y/scale,r.width/scale,r.height/scale]})}));
 const blocked=await page.evaluate(()=>{const e=new WheelEvent('wheel',{ctrlKey:true,deltaY:120,bubbles:true,cancelable:true});window.dispatchEvent(e);return e.defaultPrevented});assert.equal(blocked,true);
}
for(const g of geometry.slice(1))for(let i=0;i<g.length;i++)for(let j=0;j<4;j++)assert.ok(Math.abs(g[i][j]-geometry[0][i][j])<1,JSON.stringify({geometry}));
await page.setViewportSize({width:1280,height:1150});await page.evaluate(()=>window.reverseBloomReceive({type:'state',uiScale:2}));
console.log('PASS: identical normalized geometry at 50/75/100% physical viewport widths, Ctrl+wheel cancellation');

await page.getByRole('button',{name:'CHORUS',exact:true}).click();await page.getByRole('button',{name:/Reverb \/ Curve/}).click();
await page.getByRole('button',{name:'Hall',exact:true}).click();await page.getByLabel('Pre-delay ms value',{exact:true}).fill('80');
await page.getByRole('button',{name:'Late rise',exact:true}).click();assert.equal(await page.getByRole('slider',{name:'Rise point 1'}).count(),1);
const point=await page.getByRole('slider',{name:'Rise point 2'}).boundingBox();await page.mouse.move(point.x+point.width/2,point.y+point.height/2);await page.mouse.down();await page.mouse.move(point.x+point.width/2,point.y-20,{steps:4});await page.mouse.up();
assert.ok(await page.evaluate(()=>window.__sent.some(m=>m.type==='parameters'&&m.values.predelay===80&&m.values.reverbtype===1&&m.values.curvemode===1)));
await page.getByRole('button',{name:'Plate',exact:true}).click();await page.getByRole('button',{name:'Close curve editor',exact:true}).click();
await page.getByRole('button',{name:'MENU',exact:true}).click();await page.getByText('History and maintenance',{exact:true}).click();await page.getByLabel('UI scale',{exact:true}).selectOption('0');await page.getByRole('button',{name:'Close menu',exact:true}).click();
await page.getByRole('button',{name:/Reverb \/ Curve/}).click();await page.screenshot({path:'preview-reverb-curve.png',fullPage:true});await page.getByRole('button',{name:'Close curve editor',exact:true}).click();
console.log('PASS: character and pre-delay parameters, envelope presets and pointer point editor, host payload');

for(const [index,scale] of [[2,1],[1,.75],[0,.5]]){
 await page.setViewportSize({width:1280*scale,height:Math.floor(1150*scale)});
 await page.evaluate(index=>window.reverseBloomReceive({type:'state',uiScale:index}),index);await page.waitForTimeout(60);
 const before=await page.locator('.signature').boundingBox();
 await page.mouse.move(200*scale,300*scale);await page.mouse.wheel(0,2500);await page.waitForTimeout(60);
 await page.evaluate(()=>window.scrollTo(0,3000));
 const after=await page.locator('.signature').boundingBox();assert.ok(Math.abs(before.y-after.y)<.1);
 assert.equal(await page.evaluate(()=>window.scrollY),0);
 const metrics=await page.evaluate(()=>{const r=document.querySelector('.instrument').getBoundingClientRect();return {bottom:r.bottom,height:innerHeight,scroll:document.scrollingElement.scrollHeight,viewport:document.scrollingElement.clientHeight}});
 assert.ok(Math.abs(metrics.bottom-metrics.height)<=1);assert.ok(metrics.scroll<=metrics.viewport);
}
await page.setViewportSize({width:1280,height:1150});await page.evaluate(()=>window.reverseBloomReceive({type:'state',uiScale:2}));
await page.getByRole('button',{name:'MENU',exact:true}).click();for(const d of await page.locator('.settings-menu details').all())await d.evaluate(e=>e.open=true);
await page.locator('.settings-menu').evaluate(e=>e.scrollTop=9999);assert.ok(await page.locator('.settings-menu').evaluate(e=>e.scrollTop>0));assert.equal(await page.evaluate(()=>window.scrollY),0);await page.getByRole('button',{name:'Close menu',exact:true}).click();
console.log('PASS: no document scroll or blank page region at 50/75/100%, window.scrollTo and wheel blocked, menu internal scrolling retained');
assert.deepEqual(errors,[]);console.log('PASS: factory preset, editing, A/B independence, three panels, ms display, inbound host state/wave, outbound parameters/listen, layout overflow, browser errors');
} finally {await browser.close();server.close()}

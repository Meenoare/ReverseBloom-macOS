import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

// Cancel browser zoom gestures before WebView handles their default action.
window.addEventListener('wheel', e => {
 if(e.ctrlKey || e.metaKey){e.preventDefault();e.stopImmediatePropagation();return}
 const target=e.target instanceof Element?e.target:null;
 // Allow scroll only in an open dialog; contain it even at its edges.
 if(!target?.closest('.settings-menu,.bloom-editor'))e.preventDefault()
}, {passive:false,capture:true})
window.addEventListener('keydown', e => { if((e.ctrlKey || e.metaKey) && ['+','=','-','0'].includes(e.key)){e.preventDefault();e.stopImmediatePropagation()} }, {capture:true})
for(const type of ['gesturestart','gesturechange','gestureend'])window.addEventListener(type,e=>e.preventDefault(),{passive:false,capture:true})

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)

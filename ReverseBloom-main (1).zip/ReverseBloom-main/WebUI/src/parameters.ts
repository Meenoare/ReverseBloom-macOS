export const specs = {
"predelay":{"name": "Pre-delay (ms)", "min": 0, "max": 250, "initial": 0},"reverbtype":{"name": "Reverb character", "min": 0, "max": 2, "initial": 0, "options": ["Room", "Hall", "Plate"]},"curvemode":{"name": "Rise envelope", "min": 0, "max": 1, "initial": 0, "options": ["Rise", "Custom"]},"curve1":{"name": "Envelope 25%", "min": 0, "max": 1, "initial": 0.125},"curve2":{"name": "Envelope 50%", "min": 0, "max": 1, "initial": 0.35355339},"curve3":{"name": "Envelope 75%", "min": 0, "max": 1, "initial": 0.64951905},
  "size": {
    "name": "Room size",
    "min": 0.1,
    "max": 0.98,
    "initial": 0.8
  },
  "decay": {
    "name": "Tail decay (s)",
    "min": 0.2,
    "max": 12.0,
    "initial": 4.0
  },
  "tone": {
    "name": "Tone (Hz)",
    "min": 300.0,
    "max": 18000.0,
    "initial": 9000.0
  },
  "swell": {
    "name": "Swell curve",
    "min": 0.25,
    "max": 5.0,
    "initial": 1.5
  },
  "source": {
    "name": "Reverse source",
    "min": 0.0,
    "max": 1.0,
    "initial": 0.0
  },
  "depth": {
    "name": "LFO depth",
    "min": 0.0,
    "max": 1.0,
    "initial": 0.5
  },
  "rate": {
    "name": "LFO rate (Hz)",
    "min": 0.05,
    "max": 20.0,
    "initial": 2.0
  },
  "phase": {
    "name": "LFO phase",
    "min": 0.0,
    "max": 1.0,
    "initial": 0.0
  },
  "output": {
    "name": "Output (dB)",
    "min": -36.0,
    "max": 12.0,
    "initial": 0.0
  },
  "endgap": {
    "name": "End gap (ms)",
    "min": 0.0,
    "max": 200.0,
    "initial": 0.0
  },
  "looppause": {
    "name": "Loop pause (ms)",
    "min": 0.0,
    "max": 1000.0,
    "initial": 250.0
  },
  "lengthms": {
    "name": "Length (ms)",
    "min": 100.0,
    "max": 60000.0,
    "initial": 2000.0
  },
  "lowcut": {
    "name": "Tail Low Cut (Hz)",
    "min": 20.0,
    "max": 2000.0,
    "initial": 20.0
  },
  "highcut": {
    "name": "Tail High Cut (Hz)",
    "min": 1000.0,
    "max": 20000.0,
    "initial": 20000.0
  },
  "tailfade": {
    "name": "Tail End Fade (ms)",
    "min": 0.0,
    "max": 200.0,
    "initial": 3.0
  },
  "sourcefade": {
    "name": "Source Fade In (ms)",
    "min": 0.0,
    "max": 200.0,
    "initial": 3.0
  },
  "threshold": {
    "name": "Capture threshold (dBFS)",
    "min": -72.0,
    "max": -6.0,
    "initial": -36.0
  },
  "holdms": {
    "name": "Capture silence stop (ms)",
    "min": 100.0,
    "max": 3000.0,
    "initial": 600.0
  },
  "preroll": {
    "name": "Capture pre-roll (ms)",
    "min": 0.0,
    "max": 200.0,
    "initial": 50.0
  },
  "length": {
    "name": "Length (bars)",
    "min": 0,
    "max": 4,
    "initial": 2,
    "options": [
      "1/4",
      "1/2",
      "1",
      "2",
      "4"
    ]
  },
  "target": {
    "name": "LFO target",
    "min": 0,
    "max": 2,
    "initial": 0,
    "options": [
      "Volume",
      "Filter",
      "Pan"
    ]
  },
  "shape": {
    "name": "LFO shape",
    "min": 0,
    "max": 3,
    "initial": 0,
    "options": [
      "Sine",
      "Triangle",
      "Saw",
      "Soft square"
    ]
  },
  "division": {
    "name": "LFO division",
    "min": 0,
    "max": 5,
    "initial": 3,
    "options": [
      "1/1",
      "1/2",
      "1/4",
      "1/8",
      "1/16",
      "1/32"
    ]
  },
  "lfomode": {
    "name": "LFO mode",
    "min": 0,
    "max": 1,
    "initial": 0,
    "options": [
      "Retrigger",
      "Free Run"
    ]
  },
  "previewmode": {
    "name": "Preview mode",
    "min": 0,
    "max": 1,
    "initial": 0,
    "options": [
      "Tail Only",
      "Tail -> Source"
    ]
  },
  "lengthmode": {
    "name": "Length mode",
    "min": 0,
    "max": 1,
    "initial": 0,
    "options": [
      "Bars",
      "Milliseconds"
    ]
  },
  "exportmode": {
    "name": "Export contents",
    "min": 0,
    "max": 1,
    "initial": 0,
    "options": [
      "Tail Only",
      "Tail -> Source"
    ]
  },
  "sync": {
    "name": "Tempo sync",
    "min": 0,
    "max": 1,
    "initial": 1,
    "bool": true
  },
  "autogain": {
    "name": "Auto gain",
    "min": 0,
    "max": 1,
    "initial": 1,
    "bool": true
  },
  "gainlock": {
    "name": "Gain Lock",
    "min": 0,
    "max": 1,
    "initial": 0,
    "bool": true
  },
  "signalcap": {
    "name": "Capture by signal",
    "min": 0,
    "max": 1,
    "initial": 0,
    "bool": true
  },
  "autoselect": {
    "name": "Auto selection",
    "min": 0,
    "max": 1,
    "initial": 1,
    "bool": true
  },
  "autocapture": {
    "name": "Automatic transport capture",
    "min": 0,
    "max": 1,
    "initial": 1,
    "bool": true
  }
} as const;
export type ParameterID = keyof typeof specs;
export type Values = Record<ParameterID, number>;
export const defaults = Object.fromEntries(Object.entries(specs).map(([id,s])=>[id,s.initial])) as Values;
export const soundIDs = ["predelay","reverbtype","curvemode","curve1","curve2","curve3","length", "lengthmode", "lengthms", "size", "decay", "tone", "swell", "source", "depth", "rate", "phase", "target", "shape", "division", "sync", "output", "autogain", "lowcut", "highcut", "tailfade", "sourcefade", "lfomode"] as ParameterID[];
export const factoryPresets = [{"name": "Clean Bloom", "values": {"depth": 0.0, "lowcut": 100.0, "decay": 2.8}}, {"name": "Velvet Vocal", "values": {"size": 0.86, "decay": 4.5, "tone": 6500.0, "lowcut": 160.0, "highcut": 12000.0, "depth": 0.12, "swell": 1.8}}, {"name": "Neon Pulse", "values": {"shape": 1.0, "depth": 0.85, "division": 4.0, "lowcut": 180.0, "tone": 12000.0}}, {"name": "Glass Lift", "values": {"size": 0.65, "decay": 2.0, "tone": 16000.0, "swell": 2.5, "depth": 0.15, "length": 1.0, "lowcut": 350.0}}, {"name": "Dark Horizon", "values": {"size": 0.94, "decay": 8.0, "tone": 2400.0, "highcut": 5000.0, "lowcut": 90.0, "depth": 0.25, "length": 3.0}}, {"name": "Ghost Whisper", "values": {"size": 0.9, "source": 0.18, "tone": 4800.0, "depth": 0.0, "lowcut": 280.0, "output": -3.0}}, {"name": "Tape Mirage", "values": {"target": 1.0, "shape": 0.0, "depth": 0.4, "division": 1.0, "highcut": 7000.0, "source": 0.25}}, {"name": "Orbit Pan", "values": {"target": 2.0, "depth": 0.8, "division": 2.0, "size": 0.9, "lowcut": 180.0}}, {"name": "Impact Rise", "values": {"length": 1.0, "size": 0.6, "decay": 1.2, "swell": 3.5, "depth": 0.0, "lowcut": 70.0, "tailfade": 5.0}}, {"name": "Frozen Cathedral", "values": {"length": 3.0, "size": 0.98, "decay": 10.0, "swell": 1.1, "depth": 0.2, "division": 0.0, "lowcut": 220.0}}, {"name": "Micro Sweep", "values": {"lengthmode": 1.0, "lengthms": 350.0, "size": 0.55, "decay": 0.8, "swell": 2.0, "depth": 0.0, "lowcut": 300.0}}, {"name": "Silver Gate", "values": {"shape": 3.0, "depth": 0.9, "division": 5.0, "tone": 14000.0, "lowcut": 220.0, "decay": 2.5}}];

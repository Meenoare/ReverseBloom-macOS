import {useEffect,useRef,useState} from 'react'
import {defaults,specs,type ParameterID,type Values} from './parameters'
export type WaveData={bins:number[],playhead:number,viewport:[number,number]};
type State={values:Values,slot:'A'|'B',loop:boolean,playing:boolean,recording:boolean,busy:boolean,sourceReady:boolean,resultReady:boolean,connected:boolean,selection:[number,number],meters:[number,number],canUndo:boolean,canRedo:boolean,uiScale:number,error:string};
declare global {interface Window {reverseBloomHost?:{send:(message:unknown)=>void};reverseBloomReceive?:(message:unknown)=>void}}
export function sanitize(input:Partial<Values>):Values {const next={...defaults};for(const id of Object.keys(specs) as ParameterID[]){const s=specs[id];const n=input[id];if(typeof n==='number'&&Number.isFinite(n)){const v=Math.max(s.min,Math.min(s.max,n));next[id]=('options' in s||'bool' in s)?Math.round(v):v}}return next}
export function useInstrument(){
 const [state,update]=useState<State>(()=>{let values={...defaults};try{values=sanitize(JSON.parse(localStorage.getItem('rb-values')||'{}'))}catch{}return {values,slot:'A',loop:true,playing:false,recording:false,busy:false,sourceReady:false,resultReady:false,connected:false,selection:[0,1],meters:[0,0],canUndo:false,canRedo:false,uiScale:2,error:''}});
 const ref=useRef(state);ref.current=state;
 const wave=useRef<WaveData>({bins:[],playhead:0,viewport:[0,1]});const slots=useRef({A:state.values,B:{...state.values}});const history=useRef<Values[]>([]),future=useRef<Values[]>([]);
 const transaction=useRef(0),last=useRef(0);const [,revise]=useState(0);
 function send(message:unknown){try{window.reverseBloomHost?.send(message)}catch(e){update(s=>({...s,error:String(e)}))}}
 function apply(input:Partial<Values>,remember=true){const values=sanitize(input);if(remember){if(Date.now()-last.current>350){history.current.push({...ref.current.values});if(history.current.length>100)history.current.shift()}future.current=[];last.current=Date.now()}
 update(s=>({...s,values}));ref.current={...ref.current,values};slots.current[ref.current.slot]=values;
 try{localStorage.setItem('rb-values',JSON.stringify(values))}catch{}
 send({type:'parameters',id:++transaction.current,values});revise(v=>v+1);
 }
 function set(id:ParameterID,value:number){apply({...ref.current.values,[id]:value})}
 function command(action:string,payload:Record<string,unknown>={}){if(action==='resetView')wave.current.viewport=[0,1];if(action==='fitSelection')wave.current.viewport=ref.current.selection;if(action==='resetView')wave.current.viewport=[0,1];if(action==='fitSelection')wave.current.viewport=ref.current.selection;if(!window.reverseBloomHost){if(action!=='view'&&action!=='resetView'&&action!=='contentHeight')update(s=>({...s,error:'Audio host is not connected'}));return}send({type:'command',action,...payload})}
 function compare(){if(window.reverseBloomHost){send({type:'command',action:'switchAB'});return}const old=ref.current;slots.current[old.slot]={...old.values};const slot=old.slot==='A'?'B':'A';const values={...slots.current[slot]};update(s=>({...s,slot,values}));ref.current={...old,slot,values};send({type:'parameters',id:++transaction.current,values})}
 function undo(){if(window.reverseBloomHost){command('undo');return}const previous=history.current.pop();if(previous){future.current.push(ref.current.values);apply(previous,false)}}
 function redo(){if(window.reverseBloomHost){command('redo');return}const next=future.current.pop();if(next){history.current.push(ref.current.values);apply(next,false)}}
 function selection(selection:[number,number]){if(selection[0]<0||selection[1]>1||selection[0]>=selection[1])return;update(s=>({...s,selection}));send({type:'selection',selection})}
 useEffect(()=>{const receive=(message:unknown)=>{if(!message||typeof message!=='object')return;const m=message as Record<string,unknown>;
  if(m.type==='waveform'){if(Array.isArray(m.bins))wave.current.bins=m.bins.slice(0,8192).map(n=>typeof n==='number'&&Number.isFinite(n)?Math.max(-1,Math.min(1,n)):0);if(typeof m.playhead==='number'&&Number.isFinite(m.playhead))wave.current.playhead=Math.max(0,Math.min(1,m.playhead));return}
  if(m.type==='state'){update(s=>{const next={...s,connected:true};if(m.slot==='A'||m.slot==='B')next.slot=m.slot;if(typeof m.uiScale==='number')next.uiScale=Math.max(0,Math.min(2,Math.round(m.uiScale)));if(m.values&&typeof m.values==='object')next.values=sanitize({...s.values,...m.values});for(const key of ['playing','recording','busy','sourceReady','resultReady','loop','canUndo','canRedo'] as const)if(typeof m[key]==='boolean')next[key]=m[key] as boolean;if(Array.isArray(m.selection)&&m.selection.length===2&&m.selection.every(n=>typeof n==='number'&&Number.isFinite(n))&&m.selection[0]>=0&&m.selection[1]<=1&&m.selection[0]<m.selection[1])next.selection=m.selection as [number,number];if(Array.isArray(m.selection)&&m.selection.length===2&&m.selection.every(n=>typeof n==='number'&&Number.isFinite(n))&&m.selection[0]>=0&&m.selection[1]<=1&&m.selection[0]<m.selection[1])next.selection=m.selection as [number,number];if(Array.isArray(m.meters)&&m.meters.length===2)next.meters=m.meters.map(n=>Number.isFinite(n)?Math.max(0,Math.min(1,n)):0) as [number,number];return next})}
  if(m.type==='error')update(s=>({...s,error:String(m.message||'Host error')}));
 };window.reverseBloomReceive=receive;send({type:'ready',version:1});return()=>{delete window.reverseBloomReceive}},[]);
 return {state,set,apply,command,wave,compare,undo,redo,selection,canUndo:state.connected?state.canUndo:history.current.length>0,canRedo:state.connected?state.canRedo:future.current.length>0,clearError:()=>update(s=>({...s,error:''})),toggleLoop:()=>{const loop=!ref.current.loop;update(s=>({...s,loop}));send({type:'loop',value:loop})}};
}

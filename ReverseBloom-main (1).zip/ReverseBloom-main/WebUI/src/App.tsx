import React, { useEffect, useRef, useState, type CSSProperties } from 'react'
import { specs, defaults, soundIDs, factoryPresets, type ParameterID, type Values } from './parameters'
import { useInstrument, type WaveData } from './instrument'
function PanelOutline({ variant }: { variant: 'wave' | 'parameters' }) {
  const ref = useRef<SVGSVGElement>(null)
  const [size, setSize] = useState({ width: 1000, height: 350 })
  useEffect(() => {
    const element = ref.current!
    const observer = new ResizeObserver(([entry]) => {
      setSize({ width: entry.contentRect.width, height: entry.contentRect.height })
    })
    observer.observe(element)
    return () => observer.disconnect()
  }, [])
  const { width: w, height: h } = size
  const c = w / 2
  const r = variant === 'wave' ? 32 : 17
  const shoulder = Math.min(210, w * .32)
  const top = variant === 'parameters'
    ? `H${c - 46} C${c - 28} 1 ${c - 31} 26 ${c} 26 C${c + 31} 26 ${c + 28} 1 ${c + 46} 1`
    : ''
  const bottom = variant === 'wave'
    ? `H${c + shoulder} C${c + shoulder - 40} ${h - 1} ${c + 90} ${h - 53} ${c} ${h - 53} C${c - 90} ${h - 53} ${c - shoulder + 40} ${h - 1} ${c - shoulder} ${h - 1}`
    : ''
  return <svg ref={ref} className={`panel-outline ${variant}-outline`} aria-hidden="true">
    <defs><linearGradient id={`panel-fill-${variant}`} x2="1" y2="1"><stop stopColor={variant === 'wave' ? '#44424c' : '#29262f'} /><stop offset="1" stopColor="#2b2832" /></linearGradient></defs>
    <path d={`M${r} 1 ${top} H${w - r} Q${w - 1} 1 ${w - 1} ${r} V${h - r} Q${w - 1} ${h - 1} ${w - r} ${h - 1} ${bottom} H${r} Q1 ${h - 1} 1 ${h - r} V${r} Q1 1 ${r} 1 Z`} fill={`url(#panel-fill-${variant})`} stroke="#100d15" strokeWidth="1.5" />
  </svg>
}

function Waveform({data, recording, playing, sourceReady}: {data: React.MutableRefObject<WaveData>; recording:boolean; playing:boolean; sourceReady:boolean}) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  useEffect(() => {
    const canvas = canvasRef.current!
    const ctx = canvas.getContext('2d')!
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    let animation = 0
    const draw = (now: number) => {
      const width=canvas.clientWidth, height=canvas.clientHeight
      const dpr = Math.min(devicePixelRatio || 1, 2)
      if (canvas.width !== Math.round(width * dpr) || canvas.height !== Math.round(height * dpr)) {
        canvas.width = Math.round(width * dpr); canvas.height = Math.round(height * dpr)
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, width, height)
      const t = reduced ? 0 : now / 1300
      const bins = sourceReady || recording ? data.current.bins : []; const [start,end]=data.current.viewport; const cursor = (data.current.playhead-start)/(end-start);
      const gradient = ctx.createLinearGradient(0, 0, width, 0)
      gradient.addColorStop(0, '#a883f8'); gradient.addColorStop(.42, '#c582cf')
      gradient.addColorStop(.7, '#ff9589'); gradient.addColorStop(1, '#ffac73')
      ctx.strokeStyle = gradient
      ctx.globalAlpha = .2
      ctx.lineWidth = 1
      ctx.beginPath(); ctx.moveTo(0, height / 2); ctx.lineTo(width, height / 2); ctx.stroke()
      ctx.globalAlpha = 1
      ctx.lineWidth = Math.max(2, width / 360)
      ctx.lineCap = 'round'
      ctx.shadowBlur = 10; ctx.shadowColor = '#bd79df88'
      for (let i = 0; i < 145; i++) {
        const x = i / 144
        // Slow, incommensurate phases create continuous drifting lobes.
        const centerA=.28+.055*Math.sin(t*.23)+.021*Math.sin(t*.41);
        const centerB=.65+.065*Math.sin(t*.19+1.8)+.018*Math.cos(t*.37);
        const widthA=.10+.025*Math.sin(t*.17+.6),widthB=.13+.025*Math.cos(t*.21);
        const envelope=.035+.35*Math.exp(-Math.pow((x-centerA)/widthA,2))
          +.31*Math.exp(-Math.pow((x-centerB)/widthB,2))
          +.07*(1+Math.sin(x*13+t*.32))*Math.sin(Math.PI*x);
        const motion=.84+.12*Math.sin(t*.28+x*8)+.04*Math.sin(t*.47-x*11);
        const amplitude = bins.length ? Math.abs(bins[Math.min(bins.length-1,Math.floor((start+x*(end-start))*bins.length))] || 0) : envelope * motion * Math.sin(Math.PI*x);
        const h = Math.max(1, amplitude * height * .82)
        ctx.beginPath(); ctx.moveTo(16 + x * (width - 32), height / 2 - h / 2)
        ctx.lineTo(16 + x * (width - 32), height / 2 + h / 2); ctx.stroke()
      }
      if(bins.length && playing){ctx.shadowBlur=0;ctx.strokeStyle='#ffffff';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(cursor*width,8);ctx.lineTo(cursor*width,height-8);ctx.stroke()}
      animation = requestAnimationFrame(draw)
    }
    animation = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(animation)
  }, [data,recording,playing,sourceReady])
  return <canvas ref={canvasRef} aria-label={recording?"Live input waveform":"Source or rendered waveform"} />
}

function Knob({ name, value, min, max, onChange, large = false, defaultValue }: {
  name: string; value: number; min: number; max: number; onChange: (v: number) => void; large?: boolean; defaultValue?:number
}) {
  const drag = useRef<{ y: number; value: number } | null>(null)
  const fraction = (value - min) / (max - min)
  return <div className={`knob ${large ? 'master-knob' : ''}`} style={{ '--rotation': `${-135 + fraction * 270}deg`, '--progress': `${fraction * 270}deg` } as CSSProperties}>
    <div className="knob-ticks" /><div className="knob-housing" /><div className="knob-ring" />
    <div className="knob-face"><span className="knob-indicator"><i /></span></div>
    <input aria-label={name} type="range" min={min} max={max} step={(max - min) / 200} value={value}
      onChange={e => onChange(Number(e.target.value))}
      onPointerDown={e => { e.preventDefault(); e.currentTarget.setPointerCapture(e.pointerId); drag.current = { y: e.clientY, value } }}
      onPointerMove={e => { if (drag.current) onChange(Math.max(min, Math.min(max, drag.current.value + (drag.current.y - e.clientY) / 220 * (max - min)))) }}
      onDoubleClick={() => onChange(defaultValue??(min+(max-min)/2))}
      onPointerUp={() => { drag.current = null }} onPointerCancel={() => { drag.current = null }} />
  </div>
}


function ValueField({label,value,min,max,display,onChange,percent=false}: {label:string,value:number,min:number,max:number,display:string,onChange:(v:number)=>void,percent?:boolean}) {
 const [draft,setDraft]=useState<string|null>(null);
 return <input className="value-input" aria-label={label} type="text" inputMode="decimal" value={draft??display}
 onFocus={()=>setDraft(String(percent?value*100:value))}
 onChange={e=>{setDraft(e.target.value);const n=Number(e.target.value);if(e.target.value.trim()!==''&&Number.isFinite(n))onChange(Math.max(min,Math.min(max,percent?n/100:n)))}}
 onBlur={()=>setDraft(null)} onKeyDown={e=>{if(e.key==='Enter'||e.key==='Escape')e.currentTarget.blur()}}/>;
}

export default function App() {
 const model=useInstrument(); const {state,set,apply,command,wave}=model;
 const [effect,setEffect]=useState(1), [edited,setEdited]=useState(true), [menu,setMenu]=useState(false);
 const [bloomEditor,setBloomEditor]=useState(false);
 const [notice,setNotice]=useState('');
 const anchor=useRef<number|null>(null);
 const fraction=(e:React.PointerEvent<HTMLDivElement>)=>{const r=e.currentTarget.getBoundingClientRect();const [a,b]=wave.current.viewport;return Math.max(a,Math.min(b,a+((e.clientX-r.left)/r.width-e.currentTarget.clientLeft/e.currentTarget.offsetWidth-16/e.currentTarget.offsetWidth)/(1-32/e.currentTarget.offsetWidth)*(b-a)))};
 const choose=(e:React.PointerEvent<HTMLDivElement>)=>{if(anchor.current===null)return;const x=fraction(e);if(Math.abs(x-anchor.current)>.001)model.selection([Math.min(x,anchor.current),Math.max(x,anchor.current)])};
 const [preset,setPreset]=useState(-1);
 const values=state.values;const playing=state.playing;const loop=state.loop;
 const readout=values.lengthmode ? `${Math.round(values.lengthms)} ms` : ['1/4','1/2','1','2','4'][values.length];
 useEffect(()=>{ if(preset>=0){const p=factoryPresets[preset];if(soundIDs.some(id=>values[id]!==((p.values as Partial<Record<string,number>>)[id]??defaults[id])))setPreset(-1)} },[values,preset]);
 useEffect(()=>{const el=document.getElementById('root')!;const scale=state.connected?[.5,.75,1][state.uiScale]:1;el.style.transform=`scale(${scale})`;window.scrollTo(0,0);document.documentElement.scrollTop=0;document.body.scrollTop=0},[state.connected,state.uiScale]);
 useEffect(()=>{command('view',{view:edited?'result':'source'})},[edited]);

 useEffect(()=>{const close=(e:KeyboardEvent)=>{if(e.key==='Escape'){setMenu(false);setBloomEditor(false)}};window.addEventListener('keydown',close);return()=>window.removeEventListener('keydown',close)},[]);
 function selectPreset(index:number){
   if(index<0){setPreset(-1);return}
   const p=factoryPresets[(index+factoryPresets.length)%factoryPresets.length];
   const next={...values};for(const id of soundIDs)next[id]=(p.values as Partial<Record<string,number>>)[id]??defaults[id];
   apply(next);setPreset((index+factoryPresets.length)%factoryPresets.length);
 }
 function fmt(id:ParameterID,v:number){
   const def=specs[id] as {options?:readonly string[],bool?:boolean};
   if(def.options)return def.options[Math.round(v)];
   if(id==='source'||id==='depth'||id==='phase')return `${Math.round(v*100)} %`;
   if(id==='output')return `${v.toFixed(2)} dB`;
   if(id==='decay')return `${v.toFixed(2)} s`;
   if(['tone','lowcut','highcut'].includes(id))return `${v.toFixed(0)} Hz`;
   if(['endgap','looppause','tailfade','sourcefade','lengthms'].includes(id))return `${v.toFixed(1)} ms`;
   return v.toFixed(2);
 }
 const field=(id:ParameterID,label?:string)=>{
   const def=specs[id] as {name:string,min:number,max:number,options?:readonly string[],bool?:boolean};
   return <label className="setting" key={id}><span>{label||def.name}</span>{def.options?<select value={values[id]} onChange={e=>set(id,+e.target.value)}>{def.options.map((o,i)=><option value={i} key={o}>{o}</option>)}</select>:def.bool?<input type="checkbox" checked={!!values[id]} onChange={e=>set(id,+e.target.checked)}/>:<input type="number" min={def.min} max={def.max} step="any" value={values[id]} onChange={e=>{if(e.target.value!=='')set(id,+e.target.value)}}/>}</label>
 }
 const curvePoints=[0,values.curve1,Math.max(values.curve1,values.curve2),Math.max(values.curve1,values.curve2,values.curve3),1];
 const envelopeValue=(x:number)=>{if(!values.curvemode)return Math.pow(x,values.swell);const segment=Math.min(3,Math.floor(x*4)),t=x*4-segment,delta=curvePoints.slice(1).map((v,i)=>v-curvePoints[i]),slopes=[delta[0],...[1,2,3].map(i=>delta[i-1]*delta[i]>0?2*delta[i-1]*delta[i]/(delta[i-1]+delta[i]):0),delta[3]],t2=t*t,t3=t2*t;return Math.max(0,Math.min(1,(2*t3-3*t2+1)*curvePoints[segment]+(t3-2*t2+t)*slopes[segment]+(-2*t3+3*t2)*curvePoints[segment+1]+(t3-t2)*slopes[segment+1]))};
 const curvePath=Array.from({length:129},(_,i)=>{const x=i/128;return `${i?'L':'M'}${20+x*560},${180-envelopeValue(x)*160}`}).join(' ');
 const moveCurve=(index:number,e:React.PointerEvent<SVGCircleElement>)=>{if(!e.buttons)return;const rect=e.currentTarget.ownerSVGElement!.getBoundingClientRect();const next=Math.max(curvePoints[index-1],Math.min(curvePoints[index+1],(180-(e.clientY-rect.top)/rect.height*210)/160));set(('curve'+index) as ParameterID,next);if(!values.curvemode)set('curvemode',1)};
 const shapeCurve=(points:number[])=>apply({...values,curvemode:1,curve1:points[0],curve2:points[1],curve3:points[2]});
 const rotary=(id:ParameterID,label:string)=><div className="parameter" key={id}><label>{label}</label><Knob defaultValue={defaults[id]} name={label} min={specs[id].min} max={specs[id].max} value={values[id]} onChange={v=>set(id,v)}/><ValueField label={`${label} value`} value={values[id]} min={specs[id].min} max={specs[id].max} display={fmt(id,values[id])} onChange={v=>set(id,v)} percent={['source','depth','phase'].includes(id)}/></div>;
 const slider=(id:ParameterID,label:string)=><label className="filter" key={id}><span>{label}</span><input aria-label={label} type="range" min={specs[id].min} max={specs[id].max} step={(specs[id].max-specs[id].min)/1000} value={values[id]} style={{'--range-fill':`${(values[id]-specs[id].min)/(specs[id].max-specs[id].min)*100}%`} as CSSProperties} onChange={e=>set(id,+e.target.value)}/><input className="value-input" aria-label={`${label} value`} type="number" min={specs[id].min} max={specs[id].max} step="any" value={+values[id].toFixed(2)} onChange={e=>{if(e.target.value!=='')set(id,+e.target.value)}}/></label>;
 function savePreset(){if(state.connected){command('saveSoundPreset');return}const xml=`<ReverseBloomSoundPreset version="1" ${soundIDs.map(id=>`${id}="${values[id]}"`).join(' ')}/>`;const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([xml],{type:'application/xml'}));a.download='ReverseBloom.xml';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
 async function loadPreset(file?:File){if(!file)return;try{if(file.size>131072)throw Error('Preset exceeds 128 KB');const doc=new DOMParser().parseFromString(await file.text(),'application/xml');if(doc.documentElement.tagName!=='ReverseBloomSoundPreset'||doc.querySelector('parsererror'))throw Error('Invalid preset');const next={...values,predelay:defaults.predelay,reverbtype:defaults.reverbtype,curvemode:defaults.curvemode,curve1:defaults.curve1,curve2:defaults.curve2,curve3:defaults.curve3};for(const id of soundIDs){const val=doc.documentElement.getAttribute(id);if(val!==null){if(!Number.isFinite(+val))throw Error('Invalid value');next[id]=+val}}apply(next);setPreset(-1);setNotice('Preset loaded')}catch(e){setNotice(String(e))}}
 function workflow(save:boolean){if(state.connected){command(save?'saveWorkflow':'loadWorkflow');return}const ids:ParameterID[]=['autocapture','previewmode','exportmode','signalcap','autoselect','threshold','holdms','preroll','endgap','looppause'];if(save){localStorage.setItem('rb-workflow',JSON.stringify(Object.fromEntries(ids.map(id=>[id,values[id]]))));setNotice('Workflow saved')}else{try{const stored=JSON.parse(localStorage.getItem('rb-workflow')||'{}');const next={...values};for(const id of ids)if(Number.isFinite(stored[id]))next[id]=stored[id];apply(next)}catch{setNotice('Cannot read workflow')}}}
 return <main className="instrument">
  <header className="topbar"><span className="brand" aria-label="Reverse Bloom"><b className="brand-reversed">R</b>EVERSE BLOOM</span>
  <div className="preset-group"><label className="preset-select"><span>PRESET</span><select aria-label="Sound preset" value={preset} onChange={e=>selectPreset(+e.target.value)}><option value={-1}>Sound preset / Custom</option>{factoryPresets.map((p,i)=><option key={p.name} value={i}>{p.name}</option>)}</select><i/></label>
  <div className="preset-arrows"><button className="hardware-button" aria-label="Previous preset" onClick={()=>selectPreset(preset<0?factoryPresets.length-1:preset-1)}>‹</button><button className="hardware-button" aria-label="Next preset" onClick={()=>selectPreset(preset+1)}>›</button></div>
  <button className="hardware-button compare" onClick={model.compare} aria-label={`Compare: ${state.slot} active`}><span className={state.slot==='A'?'active':''}>A</span><span className="compare-divider">/</span><span className={state.slot==='B'?'active':''}>B</span></button></div>
  <div className="menu-wrap"><button className="hardware-button menu-button" aria-expanded={menu} onClick={()=>setMenu(!menu)}>MENU</button></div></header>
  <section className="wave-panel" aria-label="Reverse Bloom visualizer"><PanelOutline variant="wave"/><div className="panel-heading"><h1>REVERSE <span>BLOOM</span></h1><button onClick={()=>{setNotice('');model.clearError();setPreset(-1);if(state.connected)command('reset');else apply({...values,...Object.fromEntries([...soundIDs,'gainlock','previewmode'].map(id=>[id,defaults[id as ParameterID]]))});command('resetView')}}>RESET</button></div>
  <div className="wave-screen" onPointerDown={e=>{if(edited||!state.sourceReady||state.recording||e.button!==0)return;e.preventDefault();anchor.current=fraction(e);e.currentTarget.setPointerCapture(e.pointerId)}} onPointerMove={choose} onPointerUp={e=>{choose(e);anchor.current=null}} onPointerCancel={()=>{anchor.current=null}} onDragStart={e=>{if(!edited){e.preventDefault();return}e.preventDefault();command('dragWav')}} draggable={edited&&state.connected&&state.resultReady}>
   <Waveform data={wave} recording={state.recording} playing={playing} sourceReady={state.sourceReady}/><span className="wave-status"><i/>{state.recording?'REC / LIVE INPUT':state.busy?'UPDATING TAIL':state.sourceReady?(edited?'RENDERED TAIL':'CAPTURED SOURCE'):'WAITING FOR AUDIO'}</span><span className="screen-corner">RB / {state.connected?'HOST':'WEB'}</span>
   {state.sourceReady&&!edited&&<div className="selection-overlay" style={{left:`calc(16px + (100% - 32px) * ${(state.selection[0]-wave.current.viewport[0])/(wave.current.viewport[1]-wave.current.viewport[0])})`,width:`calc((100% - 32px) * ${(state.selection[1]-state.selection[0])/(wave.current.viewport[1]-wave.current.viewport[0])})`}}/>}
  </div>
  <div className="wave-footer"><div className="listen-controls"><button className={playing?'listening':''} aria-pressed={playing} disabled={!state.connected||!state.resultReady||state.recording} onClick={()=>command('listen')}><svg width="13" height="13" viewBox="0 0 16 16" aria-hidden="true">{playing?<path d="M4 3h3v10H4zm5 0h3v10H9z" fill="currentColor"/>:<path d="m5 2 9 6-9 6z" fill="currentColor"/>}</svg>{playing?'STOP':'LISTEN'}</button><button className="loop-button" role="switch" aria-checked={loop} onClick={model.toggleLoop}><svg className={loop?'lit':''} width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" aria-hidden="true"><path d="m16 2 4 4-4 4M4 11V8a2 2 0 0 1 2-2h14M8 22l-4-4 4-4m12-1v3a2 2 0 0 1-2 2H4"/></svg>Loop</button><button className="preview-toggle" aria-label="Preview mode" aria-pressed={!!values.previewmode} onClick={()=>set('previewmode',values.previewmode?0:1)}>{values.previewmode?'Tail Source':'Tail'}</button></div><div className={`mode-switch ${edited?'edited':''}`}><span/><button aria-pressed={!edited} onClick={()=>setEdited(false)}>RAW</button><button aria-pressed={edited} onClick={()=>setEdited(true)}>EDIT</button></div></div></section>
  <section className="master-section" aria-label="Reverse length"><div className="speaker speaker-left">{Array.from({length:6},(_,i)=><i key={i}/>)}</div><div className="master-control"><Knob defaultValue={values.lengthmode?defaults.lengthms:defaults.length} name="Reverse length" min={values.lengthmode?100:0} max={values.lengthmode?60000:4} value={values.lengthmode?values.lengthms:values.length} onChange={v=>set(values.lengthmode?'lengthms':'length',v)} large/><div className="rhythm-display" role="status"><span className="rhythm-value" key={readout}>{readout}</span></div></div><div className="speaker speaker-right">{Array.from({length:6},(_,i)=><i key={i}/>)}</div></section>
  <section className={`parameter-panel section-${effect}`} aria-label={['Output and preview','Tail and reverb','LFO'][effect]}><PanelOutline variant="parameters"/>{effect===1&&<button className="bloom-open" onClick={()=>setBloomEditor(true)}>Reverb / Curve · {['Room','Hall','Plate'][values.reverbtype]} · {Math.round(values.predelay)} ms</button>}<span className="amount-readout">{values.lengthmode?'ms':'bars'}</span>
  {effect===1?<><div className="parameter-knobs">{([['size','Room'],['decay','Decay'],['tone','Tone'],['swell','Rise'],['source','Source Blend']] as [ParameterID,string][]).map(([id,label])=>rotary(id,label))}</div><div className="filter-controls">{([['lowcut','Low Cut Hz'],['highcut','High Cut Hz'],['tailfade','Tail Fade ms'],['sourcefade','Source Fade ms']] as [ParameterID,string][]).map(([id,label])=>slider(id,label))}</div></>:
  effect===2?<><div className="parameter-knobs lfo-knobs">{rotary('depth','Depth')}{rotary('rate','Rate Hz')}{rotary('phase','Phase')}</div><div className="settings-grid">{field('sync')}{field('division')}{field('lfomode')}{field('target')}{field('shape')}</div></>:
  <><div className="texture-controls">{rotary('output','Level')}<div><div className="gain-buttons"><button aria-pressed={!!values.autogain} onClick={()=>set('autogain',values.autogain?0:1)}>Auto Gain</button><button aria-pressed={!!values.gainlock} onClick={()=>set('gainlock',values.gainlock?0:1)}>Gain Lock</button></div><div className="meters"><span>TAIL LEVEL</span><meter aria-label="Tail left level" min="0" max="1" value={state.meters[0]}/><meter aria-label="Tail right level" min="0" max="1" value={state.meters[1]}/><small>{state.connected?'Live host meters':'Host disconnected'}</small></div></div></div><div className="filter-controls">{slider('endgap','End Gap ms')}{slider('looppause','Loop Pause ms')}</div></>}
  </section>
  <footer className="bottom-panel"><div className="effect-switch" role="group" aria-label="Settings section"><div className="effect-highlight" style={{transform:`translateX(${effect*100}%)`}}/>{['OUTPUT','CHORUS','TREMOLO'].map((name,i)=><button key={name} aria-pressed={effect===i} onClick={()=>setEffect(i)}>{name}</button>)}</div><span className="signature">@BYMEENOARE</span></footer>
  {bloomEditor&&<div className="menu-backdrop" onClick={()=>setBloomEditor(false)}><section className="bloom-editor" role="dialog" aria-label="Reverb and rise curve" onClick={e=>e.stopPropagation()}><header><h2>REVERB & RISE CURVE</h2><button onClick={()=>setBloomEditor(false)} aria-label="Close curve editor">×</button></header>
  <div className="character-buttons">{['Room','Hall','Plate'].map((name,i)=><button key={name} aria-pressed={values.reverbtype===i} onClick={()=>set('reverbtype',i)}>{name}</button>)}</div>
  <p className="character-info">{['Original room algorithm: balanced early reflections.','Longer, darker room feedback with wider input diffusion.','Brighter, dense diffusion with short all-pass stages.'][values.reverbtype]}</p>
  {slider('predelay','Pre-delay ms')}
  <p className="character-info">Delay before the reverb, before reversing. Result length stays fixed.</p>
  <div className="curve-modes"><button aria-pressed={!values.curvemode} onClick={()=>set('curvemode',0)}>Rise knob</button><button aria-pressed={!!values.curvemode} onClick={()=>set('curvemode',1)}>Custom curve</button></div>
  <svg className="curve-editor" viewBox="0 0 600 210" aria-label="Rise envelope editor"><path d="M20 20V180H580" fill="none" stroke="#695674"/>{[.25,.5,.75].map(x=><path key={x} d={`M${20+x*560} 20V180`} stroke="#ffffff12"/>)}<path d={curvePath} fill="none" stroke="#c49aef" strokeWidth="3"/>{values.curvemode?[1,2,3].map(i=><circle key={i} role="slider" aria-label={`Rise point ${i}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(curvePoints[i]*100)} tabIndex={0} cx={20+i*140} cy={180-curvePoints[i]*160} r="9" fill="#cfabf1" onPointerDown={e=>{e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);moveCurve(i,e)}} onPointerMove={e=>moveCurve(i,e)} onKeyDown={e=>{if(['ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();set(('curve'+i) as ParameterID,Math.max(curvePoints[i-1],Math.min(curvePoints[i+1],curvePoints[i]+(e.key==='ArrowUp'?.01:-.01))))}}}/>):null}<text x="20" y="205">START</text><text x="545" y="205">END</text></svg>
  <div className="curve-presets"><button onClick={()=>shapeCurve([.25,.5,.75])}>Linear</button><button onClick={()=>shapeCurve([.04,.16,.45])}>Late rise</button><button onClick={()=>shapeCurve([.4,.72,.91])}>Early rise</button><button onClick={()=>shapeCurve([.1,.5,.9])}>S curve</button></div>
  <p className="character-info">Drag the three points vertically. Custom curve replaces Rise; switch to Rise knob to restore its envelope. All settings are saved with the sound preset and project.</p></section></div>}
  {(notice||state.error)&&<div className="notice" role="status" onClick={()=>{setNotice('');model.clearError()}}>{state.error||notice}<button aria-label="Dismiss">×</button></div>}
  {menu&&<div className="menu-backdrop" onClick={()=>setMenu(false)}><section className="settings-menu" role="dialog" aria-modal="true" aria-label="Reverse Bloom settings" onClick={e=>e.stopPropagation()}><header><h2>MENU</h2><button aria-label="Close menu" onClick={()=>setMenu(false)}>×</button></header><p className="connection">{state.connected?'Connected to audio host':'Web interface · audio host disconnected'}</p>
  <details open><summary>Capture</summary>{field('autocapture')}{field('signalcap')}{field('autoselect')}{field('threshold')}{field('holdms')}{field('preroll')}<div className="menu-actions">{['capture','stopCapture','rearm','trimSilence','fitSelection','resetView'].map(action=><button key={action} disabled={!state.connected} onClick={()=>command(action)}>{({capture:'Capture',stopCapture:'Stop capture',rearm:'Re-arm',trimSilence:'Trim silence',fitSelection:'Fit selection',resetView:'Reset view'} as Record<string,string>)[action]}</button>)}</div></details>
  <details><summary>Length and export</summary>{field('lengthmode')}{field('length')}{field('lengthms')}{field('exportmode')}<button disabled={!state.connected||!state.resultReady} onClick={()=>command('exportWav')}>Export WAV</button></details>
  <details><summary>Presets and workflow</summary><div className="menu-actions"><button onClick={savePreset}>Save sound preset</button><label className="file-button" onClick={e=>{if(state.connected){e.preventDefault();command('loadSoundPreset')}}}>Load sound preset<input type="file" accept=".xml" onChange={e=>loadPreset(e.target.files?.[0])}/></label><button onClick={()=>workflow(true)}>Save workflow defaults</button><button onClick={()=>workflow(false)}>Apply workflow defaults</button></div></details>
  <details><summary>History and maintenance</summary><label className="setting"><span>UI scale</span><select aria-label="UI scale" value={state.uiScale} onChange={e=>command('scale',{value:+e.target.value})} disabled={!state.connected}><option value="0">50%</option><option value="1">75%</option><option value="2">100%</option></select></label><div className="menu-actions"><button disabled={!model.canUndo} onClick={model.undo}>Undo</button><button disabled={!model.canRedo} onClick={model.redo}>Redo</button><button disabled={!state.connected} onClick={()=>command('clearCache')}>Clear cache</button><button onClick={()=>{if(state.connected)command('diagnostics');else navigator.clipboard?.writeText(JSON.stringify({values,connected:state.connected,slot:state.slot},null,2));setNotice('Diagnostics copied')}}>Copy diagnostics</button></div></details>
  </section></div>}
 </main>
}

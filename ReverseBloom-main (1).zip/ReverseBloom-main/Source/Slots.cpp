#include "Processor.h"
void BloomProcessor::writeEditSlots(juce::ValueTree& tree)
{
    pollHistory(); if(slotB) slotBState=readEditState(); else slotAState=readEditState();
    const auto save=[&](const char* name,const EditState& s) {
        juce::ValueTree t(name); t.setProperty("begin",s.begin,nullptr); t.setProperty("end",s.end,nullptr); t.setProperty("loop",s.loopValue,nullptr);
        const auto& ps=getParameters();
        for(int i=0;i<ps.size() && i<(int)s.values.size();++i)
            if(auto* id=dynamic_cast<juce::AudioProcessorParameterWithID*>(ps[i])) t.setProperty(juce::Identifier(id->paramID),s.values[(size_t)i],nullptr);
        tree.addChild(t,-1,nullptr);
    };
    tree.removeChild(tree.getChildWithName("SlotA"),nullptr); tree.removeChild(tree.getChildWithName("SlotB"),nullptr);
    save("SlotA",slotAState); save("SlotB",slotBState); tree.setProperty("slotB",slotB,nullptr);
}
void BloomProcessor::readEditSlots(const juce::ValueTree& tree)
{
    const auto load=[&](const char* name) {
        auto s=readEditState(); const auto t=tree.getChildWithName(name);
        if(!t.isValid()) return s;
        s.begin=(float)t.getProperty("begin",0); s.end=(float)t.getProperty("end",1); s.loopValue=(bool)t.getProperty("loop",false);
        const auto& ps=getParameters();
        for(int i=0;i<ps.size();++i) if(auto* id=dynamic_cast<juce::AudioProcessorParameterWithID*>(ps[i]))
            s.values[(size_t)i]=juce::jlimit(0.0f,1.0f,(float)t.getProperty(juce::Identifier(id->paramID),s.values[(size_t)i]));
        return s;
    };
    slotAState=load("SlotA"); slotBState=load("SlotB"); slotB=(bool)tree.getProperty("slotB",false); slotsReady=true;
    historyState=readEditState(); historyReady=true;
}

#include "WebEditor.h"
#if RB_WEB_UI
#include <BinaryData.h>
#include <cstring>
namespace {
juce::var object(std::initializer_list<std::pair<juce::Identifier,juce::var>> values) {
 auto* result=new juce::DynamicObject();for(const auto& p:values)result->setProperty(p.first,p.second);return result;
}
}
juce::WebBrowserComponent::Options BloomWebEditor::options(){
 auto o=juce::WebBrowserComponent::Options{}.withNativeIntegrationEnabled()
 .withEventListener("reverseBloom",[this](juce::var v){message(v);})
 .withUserScript("window.reverseBloomHost={send:function(m){window.__JUCE__.backend.emitEvent('reverseBloom',m)}};")
 .withResourceProvider([this](const juce::String& p){return resource(p);});
 #if JUCE_WINDOWS
 o=o.withBackend(juce::WebBrowserComponent::Options::Backend::webview2);
 #endif
 return o;
}
BloomWebEditor::BloomWebEditor(BloomProcessor& p):AudioProcessorEditor(p),processor(p),browser(options()) {
 addAndMakeVisible(browser);setResizable(false,false);const auto scale=processor.uiScale.load()==0?0.5f:processor.uiScale.load()==1?0.75f:1.0f;setSize((int)(1280*scale),(int)(1150*scale));
 browser.goToURL(juce::WebBrowserComponent::getResourceProviderRoot());startTimerHz(30);
}
BloomWebEditor::~BloomWebEditor(){stopTimer();}
void BloomWebEditor::resized(){browser.setBounds(getLocalBounds());}
std::optional<juce::WebBrowserComponent::Resource> BloomWebEditor::resource(const juce::String& path){
 auto file=path=="/"?juce::String("index.html"):path.fromLastOccurrenceOf("/",false,false);
 for(int i=0;i<BinaryData::namedResourceListSize;++i){if(file!=BinaryData::originalFilenames[i])continue;
  int bytes=0;const auto* data=BinaryData::getNamedResource(BinaryData::namedResourceList[i],bytes);
  if(data==nullptr||bytes<=0)return std::nullopt;
  auto mime=file.endsWith(".html")?"text/html":file.endsWith(".js")?"text/javascript":file.endsWith(".css")?"text/css":file.endsWith(".svg")?"image/svg+xml":file.endsWith(".ttf")?"font/ttf":"application/octet-stream";
  std::vector<std::byte> result((size_t)bytes);std::memcpy(result.data(),data,(size_t)bytes);return juce::WebBrowserComponent::Resource{std::move(result),mime};
 }return std::nullopt;
}
void BloomWebEditor::publish(juce::var v){if(ready)browser.evaluateJavascript("window.reverseBloomReceive&&window.reverseBloomReceive("+juce::JSON::toString(v,true)+");");}
void BloomWebEditor::message(const juce::var& m){
 const auto type=m["type"].toString();
 if(type=="ready"){ready=true;return;}
 if(type=="parameters"){
  if(auto* values=m["values"].getDynamicObject()){
   processor.pollHistory();
   for(const auto& pair:values->getProperties()){
    const double value=(double)pair.value;if(!std::isfinite(value))continue;
    if(auto* param=processor.parameters.getParameter(pair.name.toString())){param->beginChangeGesture();param->setValueNotifyingHost(param->convertTo0to1((float)value));param->endChangeGesture();}
   }
   processor.pollHistory();
  }return;
 }
 if(type=="loop"){processor.loop.store((bool)m["value"]);return;}
 if(type=="selection"){if(auto* a=m["selection"].getArray();a&&a->size()==2)processor.setSelection((float)a->getReference(0),(float)a->getReference(1));return;}
 if(type!="command")return;
 const auto action=m["action"].toString();
 if(action=="reset"){processor.pollHistory();
  const juce::StringArray soundIDs {"predelay","reverbtype","curvemode","curve1","curve2","curve3","length","lengthmode","lengthms","size","decay","tone","swell","source","depth","rate","phase","target","shape","division","sync","output","autogain","gainlock","lowcut","highcut","tailfade","sourcefade","lfomode","previewmode"};
  for(const auto& id:soundIDs)if(auto* param=processor.parameters.getParameter(id)){param->beginChangeGesture();param->setValueNotifyingHost(param->getDefaultValue());param->endChangeGesture();}
  processor.playing.store(false);processor.pollHistory();}
 else if(action=="view"){sourceView=m["view"].toString()=="source";previousAudio.reset();}
 else if(action=="scale"){const int index=juce::jlimit(0,2,(int)m["value"]);processor.uiScale.store(index);const float scale=index==0?0.5f:index==1?0.75f:1.0f;setSize((int)(1280*scale),(int)(1150*scale));}
 else if(action=="diagnostics")juce::SystemClipboard::copyTextToClipboard(processor.diagnostics());
 else if(action=="saveSoundPreset"||action=="loadSoundPreset"){
  const bool save=action=="saveSoundPreset";
  chooser=std::make_unique<juce::FileChooser>(save?"Save sound preset":"Load sound preset",juce::File::getSpecialLocation(juce::File::userDocumentsDirectory),"*.xml");
  chooser->launchAsync((save?juce::FileBrowserComponent::saveMode:juce::FileBrowserComponent::openMode)|juce::FileBrowserComponent::canSelectFiles,[safe=juce::Component::SafePointer<BloomWebEditor>(this),save](const juce::FileChooser& c){if(safe&&c.getResult()!=juce::File()){if(save)safe->processor.saveSoundPreset(c.getResult());else safe->processor.loadSoundPreset(c.getResult());}});
 }
 else if(action=="listen")processor.togglePreview();
 else if(action=="capture")processor.startCapture();
 else if(action=="stopCapture")processor.stopCapture();
 else if(action=="rearm")processor.requestAutomaticRearm();
 else if(action=="trimSilence")processor.trimSilence();
 else if(action=="switchAB")processor.switchAB();
 else if(action=="undo")processor.undoSettings();
 else if(action=="redo")processor.redoSettings();
 else if(action=="clearCache")processor.clearExportCache();
 else if(action=="saveWorkflow")processor.saveWorkflowDefaults();
 else if(action=="loadWorkflow")processor.loadWorkflowDefaults();
 else if(action=="resetView"||action=="fitSelection") { /* front-end viewport command acknowledged; source preserved */ }
 else if(action=="dragWav"){
  const auto f=processor.getExportFile();if(f.existsAsFile())juce::DragAndDropContainer::performExternalDragDropOfFiles({f.getFullPathName()},false,this);
 }
 else if(action=="exportWav"){
  chooser=std::make_unique<juce::FileChooser>("Export ReverseBloom WAV",juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile("ReverseBloom.wav"),"*.wav");
  chooser->launchAsync(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles|juce::FileBrowserComponent::warnAboutOverwriting,[safe=juce::Component::SafePointer<BloomWebEditor>(this)](const juce::FileChooser& c){if(safe&&c.getResult()!=juce::File())safe->processor.saveExportTo(c.getResult());});
 }
}
void BloomWebEditor::timerCallback(){
 if(!ready)return;
 processor.pollHistory();
 if(++ticks%3==0){
  auto* values=new juce::DynamicObject();for(auto* p:processor.getParameters())if(auto* r=dynamic_cast<juce::RangedAudioParameter*>(p))values->setProperty(r->getParameterID(),r->convertFrom0to1(r->getValue()));
  publish(object({{"type","state"},{"uiScale",processor.uiScale.load()},{"values",juce::var(values)},{"slot",processor.isSlotB()?"B":"A"},{"canUndo",processor.canUndo()},{"canRedo",processor.canRedo()},{"selection",juce::var(juce::Array<juce::var>{processor.getSelectionBegin(),processor.getSelectionEnd()})},{"canUndo",processor.canUndo()},{"canRedo",processor.canRedo()},{"selection",juce::var(juce::Array<juce::var>{processor.getSelectionBegin(),processor.getSelectionEnd()})},{"loop",processor.loop.load()},{"playing",processor.playing.load()},{"recording",processor.isRecordingCapture()},{"busy",processor.isBusy()},{"sourceReady",processor.getSource()!=nullptr},{"resultReady",processor.isResultCurrent()},{"meters",juce::var(juce::Array<juce::var>{processor.tailMeterL.load(),processor.tailMeterR.load()})}}));
 }
 const bool recording=processor.isRecordingCapture();
 auto audio=sourceView?processor.getSource():processor.getResult();
 if(recording){
  if(live.size()>=145)live.remove(0);
  live.add(std::sqrt(juce::jmax(0.0f,processor.inputMeter.load())));
 }else if(audio!=previousAudio){
  peaks.clear();previousAudio=audio;live.clear();
  if(audio){const int n=audio->getNumSamples();const int count=juce::jmin(145,n);
   for(int i=0;i<count;++i){float peak=0;for(int ch=0;ch<audio->getNumChannels();++ch)peak=juce::jmax(peak,audio->getMagnitude(ch,i*n/count,juce::jmax(1,(i+1)*n/count-i*n/count)));peaks.add(peak);}
  }
 }
 publish(object({{"type","waveform"},{"bins",juce::var(recording?live:peaks)},{"playhead",sourceView?processor.sourcePreviewPosition.load():processor.previewPosition.load()}}));
}
#endif

#include "Processor.h"

void BloomProcessor::updateAutomaticCapture(bool known, bool running)
{
    transportAvailable.store(known); hostTransportPlaying.store(known && running);
    const bool enabled=parameters.getRawParameterValue("autocapture")->load()>0.5f;
    if(!enabled) {
        if(autoWasEnabled) {
            signalArmed.store(false);
            if(captureState.load()==1) captureState.store(2);
            transportSession=false;
        }
        autoWasEnabled=false; autoHostWasPlaying=running; return;
    }
    if(!autoWasEnabled) {autoFallbackUsed=false; autoHostWasPlaying=false;}
    autoWasEnabled=true;
    const bool rearm=rearmAutoCapture.exchange(false);
    if(rearm) autoFallbackUsed=false;
    // Transport sessions end on host Stop, NOT on pauses between words.
    if(transportSession && known && !running) {
        signalArmed.store(false);
        if(captureState.load()==1) captureState.store(2);
        transportSession=false;
    }
    const bool start=known ? (running && (!autoHostWasPlaying || rearm)) : !autoFallbackUsed;
    if(start && !busy.load() && !analysisBusy.load() && !trimReady.load() && !trimRequested.load()) {
        if(known) preRollCount=0;
        playing.store(false); // own audition never feeds the capture buffer
        signalArmed.store(true); signalRecording=false;
        transportSession=known;
        autoFallbackUsed=true;
        // Keep prior capture intact until a real signal crosses the threshold.
    }
    autoHostWasPlaying=(start && (busy.load() || analysisBusy.load() || trimReady.load() || trimRequested.load())) ? false : running;
}

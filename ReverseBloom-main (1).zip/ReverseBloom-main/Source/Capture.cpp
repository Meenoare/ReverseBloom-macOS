#include "Processor.h"
#include <cmath>
void BloomProcessor::captureInput(juce::AudioBuffer<float>& audio)
{
    if(captureState.load()==4) {
        if(signalArmed.load()) { captureState.store(0); signalRecording=false; }
        else { captured.store(0); captureRevision.fetch_add(1); quietSamples=0; signalRecording=false; captureState.store(1); }
    }
    const float on=juce::Decibels::decibelsToGain(parameters.getRawParameterValue("threshold")->load());
    const float off=on*0.5f;
    const int hold=juce::jmax(1,(int)(activeRate.load()*parameters.getRawParameterValue("holdms")->load()/1000.0));
    const int pre=juce::jlimit(0,preRollBuffer.getNumSamples(),(int)(activeRate.load()*parameters.getRawParameterValue("preroll")->load()/1000.0));
    for(int i=0;i<audio.getNumSamples();++i)
    {
        const float l=audio.getSample(0,i),rr=audio.getSample(juce::jmin(1,audio.getNumChannels()-1),i);
        const float peak=juce::jmax(std::abs(l),std::abs(rr));
        if(signalArmed.load() && peak>=on) {
            const int count=juce::jmin(pre,preRollCount);
            captured.store(count); captureRevision.fetch_add(1);
            selectionBegin.store(0); selectionEnd.store(1); newCaptureHistory.store(true);
            for(int j=0;j<count;++j) {
                const int index=(preRollWrite-count+j+preRollBuffer.getNumSamples())%preRollBuffer.getNumSamples();
                for(int ch=0;ch<2;++ch) capturedAudio.setSample(ch,j,preRollBuffer.getSample(ch,index));
            }
            quietSamples=0; signalRecording=true; signalArmed.store(false); captureState.store(1);
        }
        if(captureState.load()==1) {
            const int at=captured.load();
            if(at<capturedAudio.getNumSamples()) { capturedAudio.setSample(0,at,l); capturedAudio.setSample(1,at,rr); captured.store(at+1); }
            quietSamples=peak<off ? quietSamples+1 : 0;
            if(at+1>=capturedAudio.getNumSamples() || (signalRecording && !transportSession && quietSamples>=hold)) {
                // Exclude trailing stop silence, but leave 5ms for a safe boundary.
                if(signalRecording && !transportSession && quietSamples>=hold) captured.store(juce::jmax(0,captured.load()-quietSamples+(int)(activeRate.load()*0.005)));
                captureState.store(3); signalRecording=false;
            }
        }
        preRollBuffer.setSample(0,preRollWrite,l); preRollBuffer.setSample(1,preRollWrite,rr);
        preRollWrite=(preRollWrite+1)%preRollBuffer.getNumSamples(); preRollCount=juce::jmin(preRollCount+1,preRollBuffer.getNumSamples());
    }
    if(captureState.load()==2) {captureState.store(3); signalRecording=false;}
}

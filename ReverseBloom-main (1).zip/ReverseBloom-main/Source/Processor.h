#pragma once
#include "Renderer.h"
#include "PreviewTimeline.h"
#include <thread>

class BloomProcessor final : public juce::AudioProcessor, private juce::Timer
{
public:
    BloomProcessor();
    ~BloomProcessor() override;
    void prepareToPlay (double, int) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "ReverseBloom"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;
    void startCapture();
    void stopCapture();
    void generate (float startFraction, float endFraction);
    void togglePreview();
    juce::File getExportFile();
    void saveExportTo(const juce::File&);
    void retryExport();
    void clearExportCache();
    juce::String diagnostics() const;
    void trimSilence();
    void switchAB();
    void undoSettings();
    void redoSettings();
    void pollHistory();
    bool canUndo() const { return !undoStack.empty(); }
    bool canRedo() const { return !redoStack.empty(); }
    bool isSlotB() const { return slotB; }
    juce::StringArray factoryPresetNames() const;
    void applyFactoryPreset(int index);
    void saveSoundPreset(const juce::File&);
    void loadSoundPreset(const juce::File&);
    void saveWorkflowDefaults();
    void loadWorkflowDefaults();
    bool isSignalArmed() const { return signalArmed.load(); }
    bool isAnalysisBusy() const { return analysisBusy.load(); }
    std::atomic<bool> userEditing {false};
    std::atomic<int> bufferSize {0}, cacheStatus {0};
    std::atomic<float> lockedGain {1.0f};
    std::atomic<bool> lockedGainValid {false};
    void setLastError(const juce::String&);
    void resetEditHistory();
    std::atomic<int> exportStatus {0}; // 0 pending, 1 writing, 2 ready, -1 failed
    std::atomic<int> uiScale {1}; // 50/75/100%, saved in project
    struct PreviewPacket
    {
        std::shared_ptr<juce::AudioBuffer<float>> tail, source;
        int first=0,count=0;
    };
    bool isResultCurrent() const;
    std::shared_ptr<juce::AudioBuffer<float>> getSource() const { return std::atomic_load (&sourceSnapshot); }
    std::atomic<float> tailMeterL {0.0f}, tailMeterR {0.0f}, tailHeldPeak {0.0f};
    std::atomic<bool> resetTailPeak {false};
    std::atomic<int> previewStage {0};
    std::atomic<float> sourcePreviewPosition {0.0f};
    std::atomic<bool> previewPending {false};
    std::atomic<float> lfoPosition {0};
    std::atomic<float> previewPosition {0.0f}, outputPeak {0.0f};
    std::shared_ptr<juce::AudioBuffer<float>> getResult() const { return std::atomic_load (&result); }
    bool isBusy() const { return busy.load(); }
    bool isRecordingCapture() const { return captureState.load()==1; }
    std::atomic<float> inputMeter {0};
    bool isCapturing() const { const auto s = captureState.load(); return s == 1 || s == 4 || signalArmed.load(); }
    void setSelection (float begin, float end)
    { selectionBegin.store (juce::jlimit (0.0f,0.9999f,begin)); selectionEnd.store (juce::jlimit (selectionBegin.load()+0.0001f,1.0f,end)); }
    float getSelectionBegin() const { return selectionBegin.load(); }
    float getSelectionEnd() const { return selectionEnd.load(); }
    int getCapturedSamples() const { return captured.load(); }
    double getSampleRateForUI() const { return activeRate.load(); }
    juce::AudioProcessorValueTreeState parameters;
    std::atomic<bool> loop { false }, playing { false };
    std::atomic<double> bpm { 120.0 };
    std::atomic<int> numerator { 4 }, denominator { 4 };
    std::atomic<int> renderStatus { 0 }; // 0 idle, 1 rendering, 2 ready, -1 failed
private:
    struct EditState { std::vector<float> values; float begin=0,end=1; bool loopValue=false; };
    EditState readEditState() const;
    void applyEditState(const EditState&);
    static bool sameEditState(const EditState&,const EditState&);
    EditState historyState, slotAState, slotBState;
    std::vector<EditState> undoStack, redoStack;
    bool historyReady=false, slotB=false, slotsReady=false;
    double lastEditTime=0;
    juce::String lastError;
    mutable juce::CriticalSection errorLock;
    juce::String cacheInstanceID=juce::Uuid().toString();
    std::unique_ptr<juce::InterProcessLock> cacheLease;
    std::atomic<bool> clearCacheRequested {false};
    juce::AudioBuffer<float> preRollBuffer;
    int preRollWrite=0,preRollCount=0,quietSamples=0;
    std::atomic<bool> signalArmed {false};
    bool signalRecording=false;
    void captureInput(juce::AudioBuffer<float>&);
    void updateAutomaticCapture(bool transportKnown, bool hostPlaying);
    std::atomic<bool> transportAvailable {false}, hostTransportPlaying {false};
    std::atomic<bool> rearmAutoCapture {false};
    bool transportSession=false, autoHostWasPlaying=false, autoFallbackUsed=false;
    bool autoWasEnabled=true;
    std::atomic<bool> newCaptureHistory {false};
public:
    bool hasHostTransport() const { return transportAvailable.load(); }
    bool isHostPlaying() const { return hostTransportPlaying.load(); }
    void requestAutomaticRearm() { rearmAutoCapture.store(true); }
private:
    std::thread analysisWorker;
    std::atomic<bool> analysisBusy {false},trimRequested {false},trimReady {false};
    unsigned int analysedRevision=0,trimRevision=0;
    float trimBegin=0,trimEnd=1;
    void serviceAnalysis();
    void requestTrim(bool autoRequest=false);
    void writeEditSlots(juce::ValueTree&);
    void readEditSlots(const juce::ValueTree&);
    std::atomic<unsigned int> gainCaptureRevision {0};
    bool gainWasLocked=false;
    juce::File cacheDirectory() const;
    void cleanCache(bool allEligible);
    void registerCacheFile(const juce::File&);
    static juce::AudioProcessorValueTreeState::ParameterLayout layout();
    RenderSettings settings() const;
    juce::AudioBuffer<float> capturedAudio;
    std::atomic<int> captureState { 0 }, captured { 0 };
    std::atomic<bool> busy { false }, cancel { false }, resetPreview { false };
    std::atomic<double> activeRate { 44100.0 };
    std::shared_ptr<juce::AudioBuffer<float>> result;
    std::thread worker, exportWorker;
    std::atomic<bool> exportBusy {false};
    std::atomic<unsigned int> exportEpoch {0};
    juce::String exportAttemptKey;
    std::atomic<bool> exportRetry {false};
    std::shared_ptr<PreviewPacket> publishedPacket, activePacket;
    std::vector<std::shared_ptr<PreviewPacket>> retainedPackets;
    std::vector<std::shared_ptr<juce::AudioBuffer<float>>> retainedAudio;
    void prepareExport();
    void collectRetired();
    mutable juce::CriticalSection exportLock;
    std::shared_ptr<juce::AudioBuffer<float>> sourceSnapshot;
    double sourceRate = 44100.0;
    unsigned int snapshotRevision = 0;
    void publishSource();
    juce::CriticalSection controlLock;
    juce::File exportFile;
    void timerCallback() override;
    juce::String fingerprint (bool baseOnly) const;
    std::atomic<float> selectionBegin {0.0f}, selectionEnd {1.0f};
    std::atomic<unsigned int> captureRevision {0};
    juce::String requestedKey, requestedBaseKey, cachedBaseKey, exportedKey, resultKey;
    std::shared_ptr<juce::AudioBuffer<float>> baseResult, cachedBase;
    std::shared_ptr<juce::AudioBuffer<float>> auditionBase, fadingBase;
    std::shared_ptr<juce::AudioBuffer<float>> previewSource;
    std::int64_t sequencePosition = 0;
    int sequenceFirst = 0, sequenceCount = 0;
    bool sequenceTogether = false;
    int sequenceGap = 0, sequencePause = 0;
    int playbackPosition = 0, fadePosition = 0, fadeLength = 1, lfoTransition = 1000000;
    float liveFilter[2] {}, oldFilter[2] {}, lastOutput[2] {};
    RenderSettings liveSettings;
    juce::SmoothedValue<float> depthSmooth, rateSmooth, phaseSmooth, previewMix, outputSmooth;
    double oscillatorPhase = 0.0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (BloomProcessor)
};

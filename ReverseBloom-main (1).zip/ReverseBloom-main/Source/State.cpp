#include "Processor.h"
#include "StateCodec.h"

bool BloomProcessor::isResultCurrent() const
{
    if (busy.load() || isCapturing()) return false;
    const auto key = fingerprint(false);
    const juce::ScopedLock lock(exportLock);
    return getResult() && resultKey == key;
}
juce::File BloomProcessor::getExportFile()
{
    if(!isResultCurrent() || exportStatus.load()!=2) return {};
    const juce::ScopedLock lock(exportLock);
    return exportedKey==fingerprint(false) ? exportFile : juce::File{};
}
void BloomProcessor::publishSource()
{
    // controlLock is held by callers; recording writes must already have stopped.
    if (captureState.load() != 3 || snapshotRevision == captureRevision.load()) return;
    const int count = captured.load();
    if (count < 1) return;
    auto copy = std::make_shared<juce::AudioBuffer<float>>(2,count);
    for (int ch=0;ch<2;++ch) copy->copyFrom(ch,0,capturedAudio,ch,0,count);
    retainedAudio.push_back(copy);
    std::atomic_store(&sourceSnapshot,copy);
    sourceRate = activeRate.load(); snapshotRevision = captureRevision.load();
}
void BloomProcessor::getStateInformation (juce::MemoryBlock& data)
{
    const juce::ScopedLock control(controlLock);
    std::shared_ptr<juce::AudioBuffer<float>> source;
    double sr = activeRate.load();
    if(captureState.load()==3) { publishSource(); source=getSource(); }
    else {
        // Saving mid-capture takes a consistent copy. Host callback lock is held only during the copy.
        const juce::ScopedLock callback(getCallbackLock());
        const int count = captured.load();
        if (count > 0)
        {
            source = std::make_shared<juce::AudioBuffer<float>>(2,count);
            for (int ch=0;ch<2;++ch) source->copyFrom(ch,0,capturedAudio,ch,0,count);
        }
    }
    auto tree = parameters.copyState();
    writeEditSlots(tree);
    tree.setProperty("selectionBegin",selectionBegin.load(),nullptr);
    tree.setProperty("selectionEnd",selectionEnd.load(),nullptr);
    tree.setProperty("previewLoop",loop.load(),nullptr);
    tree.setProperty("uiScale",uiScale.load(),nullptr);
    tree.setProperty("lockedGain",lockedGain.load(),nullptr);
    tree.setProperty("lockedGainValid",lockedGainValid.load(),nullptr);
    if (auto xml = tree.createXml())
    {
        if (source) BloomState::encode(*xml,*source,sr);
        copyXmlToBinary(*xml,data);
    }
}
void BloomProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary(data,size))
        if (xml->hasTagName(parameters.state.getType()))
        {
            const juce::ScopedLock control(controlLock);
            exportEpoch.fetch_add(1);
            if(exportWorker.joinable()) exportWorker.join();
            exportBusy.store(false); exportStatus.store(0); exportAttemptKey.clear();
            if(analysisWorker.joinable()) { analysisWorker.join(); }
    analysisBusy.store(false); trimReady.store(false); trimRequested.store(false); signalArmed.store(false);
            cancel.store(true); if (worker.joinable()) worker.join(); busy.store(false);
            auto decoded = BloomState::decode(*xml);
            if (auto* capture = xml->getChildByName("BloomCapture")) xml->removeChildElement(capture,true);
            auto state = juce::ValueTree::fromXml(*xml);
            for(const auto* id:{"predelay","reverbtype","curvemode","curve1","curve2","curve3"})if(!state.getChildWithProperty("id",id).isValid())if(auto* p=parameters.getParameter(id)){
                juce::ValueTree node("PARAM");node.setProperty("id",id,nullptr);node.setProperty("value",p->convertFrom0to1(p->getDefaultValue()),nullptr);state.addChild(node,-1,nullptr);
            }
            parameters.replaceState(state);
            setSelection((float)state.getProperty("selectionBegin",0.0f),(float)state.getProperty("selectionEnd",1.0f));
            loop.store((bool)state.getProperty("previewLoop",false));
            uiScale.store(juce::jlimit(0,2,(int)state.getProperty("uiScale",1)));
            std::shared_ptr<juce::AudioBuffer<float>> converted;
            if (decoded.audio) converted = BloomState::resample(*decoded.audio,decoded.rate,activeRate.load());
            const juce::ScopedLock callback(getCallbackLock());
            playing.store(false); resetPreview.store(true);
            transportSession=false; autoHostWasPlaying=hostTransportPlaying.load(); autoFallbackUsed=true;
            std::atomic_store(&result,std::shared_ptr<juce::AudioBuffer<float>>{});
            std::atomic_store(&baseResult,std::shared_ptr<juce::AudioBuffer<float>>{});
            std::atomic_store(&publishedPacket,std::shared_ptr<PreviewPacket>{});
            cachedBase.reset(); cachedBaseKey.clear(); requestedKey.clear();
            captured.store(0); captureState.store(0); captureRevision.fetch_add(1);
            std::atomic_store(&sourceSnapshot,std::shared_ptr<juce::AudioBuffer<float>>{});
            if (converted)
            {
                capturedAudio.setSize(2,(int)(activeRate.load()*30.0)); capturedAudio.clear();
                const int count = juce::jmin(converted->getNumSamples(),capturedAudio.getNumSamples());
                for (int ch=0;ch<2;++ch) capturedAudio.copyFrom(ch,0,*converted,ch,0,count);
                captured.store(count); captureState.store(3); snapshotRevision = 0; publishSource();
            }
            // Audio child is stored by getStateInformation, not kept in APVTS copies.
            auto child = parameters.state.getChildWithName("BloomCapture");
            if (child.isValid()) parameters.state.removeChild(child,nullptr);
            lockedGain.store(juce::jlimit(0.0f,16.0f,(float)state.getProperty("lockedGain",1.0f)));
            lockedGainValid.store((bool)state.getProperty("lockedGainValid",false));
            gainWasLocked=parameters.getRawParameterValue("gainlock")->load()>0.5f;
            gainCaptureRevision.store(captureRevision.load());
            analysedRevision=captureRevision.load();
            resetEditHistory(); readEditSlots(state);
            cancel.store(false); renderStatus.store(0);
        }
}

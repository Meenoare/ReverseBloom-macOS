#pragma once
#include <JuceHeader.h>
#include <atomic>

struct RenderSettings
{
    double sampleRate = 44100.0, bpm = 120.0;
    int numerator = 4, denominator = 4, lengthIndex = 2;
    float size = 0.8f, decay = 4.0f, tone = 9000.0f, swell = 1.5f;
    float reverseSource = 0.0f, depth = 0.5f, rate = 2.0f, phase = 0.0f;
    int target = 0, shape = 0, rateIndex = 3;
    bool sync = true, autoGain = true;
    float preDelayMs=0,curve1=0.125f,curve2=0.35355339f,curve3=0.64951905f;
    int reverbType=0;
    bool customCurve=false;
    float outputDb = 0.0f;
    bool lengthInMs=false;
    float lengthMs=2000,lowCut=20,highCut=20000,tailFadeMs=3,sourceFadeMs=3;
};

namespace BloomRenderer
{
    std::shared_ptr<juce::AudioBuffer<float>> render (
        const juce::AudioBuffer<float>& source, const RenderSettings& settings,
        const std::atomic<bool>& cancel);
    float envelope(float position, const RenderSettings&);
    bool writeWav (const juce::File&, const juce::AudioBuffer<float>&, double sampleRate);
}

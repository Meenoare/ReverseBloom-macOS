#include "Processor.h"
#include "CachePolicy.h"

juce::File BloomProcessor::cacheDirectory() const
{
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("ReverseBloom").getChildFile("Exports").getChildFile(cacheInstanceID);
}
void BloomProcessor::registerCacheFile(const juce::File& file)
{
    // Sidecar registration is written only for service WAVs created by this instance.
    if(!file.getSiblingFile(file.getFileName()+".rb-cache").replaceWithText("ReverseBloomCacheV1\n"+file.getFileName()))
        setLastError("Cannot register cache WAV; automatic deletion disabled for this file");
}
void BloomProcessor::clearExportCache()
{
    clearCacheRequested.store(true); cacheStatus.store(1);
}
void BloomProcessor::cleanCache(bool allEligible)
{
    try {
    // Serialise cleaners across processes. Active instance folders have leases.
    juce::InterProcessLock cleaner("ReverseBloomCacheCleanup");
    if(!cleaner.enter(0)) { cacheStatus.store(0); return; }
    struct Unlock { juce::InterProcessLock& l; ~Unlock(){l.exit();} } unlock{cleaner};
    const auto root=cacheDirectory().getParentDirectory();
    if(root.isSymbolicLink()) {cacheStatus.store(-1); setLastError("Cache root is a symbolic link; cleanup skipped"); return;}
    const auto now=juce::Time::getCurrentTime().toMilliseconds();

    juce::File current; { const juce::ScopedLock lock(exportLock); current=exportFile; }
    struct Entry { juce::File wav,marker; juce::int64 modified,size; };
    std::vector<Entry> files; juce::int64 total=0; bool failed=false;
    auto folders=root.findChildFiles(juce::File::findDirectories,false);
    for(const auto& folder:folders)
    {
        if(folder.isSymbolicLink()) continue;
        const auto id=folder.getFileName();
        if(juce::Uuid(id).toString()!=id) continue;
        std::unique_ptr<juce::InterProcessLock> lease;
        if(id!=cacheInstanceID) {
            lease=std::make_unique<juce::InterProcessLock>("ReverseBloomCache_"+id);
            if(!lease->enter(0)) continue; // protect ALL files in other active instances
        }
        auto markers=folder.findChildFiles(juce::File::findFiles,false,"*.rb-cache");
        for(const auto& marker:markers)
        {
            if(marker.isSymbolicLink()) continue;
            const auto name=marker.getFileName().dropLastCharacters(9);
            const auto wav=folder.getChildFile(name);
            if(!name.startsWith("ReverseBloom_") || !name.endsWith(".wav") || wav.isSymbolicLink()) continue;
            if(marker.loadFileAsString()!= "ReverseBloomCacheV1\n"+name || !wav.existsAsFile()) continue;
            const auto modified=wav.getLastModificationTime().toMilliseconds();
            total+=wav.getSize();
            if(BloomCachePolicy::eligible(true,wav==current,false,now-modified)) files.push_back({wav,marker,modified,wav.getSize()});
        }
        if(lease) lease->exit();
    }
    std::sort(files.begin(),files.end(),[](const auto& a,const auto& b){return a.modified<b.modified;});
    for(const auto& e:files)
    {
        // Re-check lease and age at deletion; never touch a now-active folder.
        std::unique_ptr<juce::InterProcessLock> lease;
        const auto id=e.wav.getParentDirectory().getFileName();
        if(id!=cacheInstanceID) {
            lease=std::make_unique<juce::InterProcessLock>("ReverseBloomCache_"+id);
            if(!lease->enter(0)) continue;
        }
        if(BloomCachePolicy::shouldRemove(true,allEligible,now-e.modified,total)) {
            if(e.wav.deleteFile()) { total-=e.size; e.marker.deleteFile(); }
            else failed=true;
        }
        if(lease) lease->exit();
    }
    cacheStatus.store(failed?-1:2);
    if(failed) setLastError("Some eligible cache files could not be removed");
    } catch(...) { cacheStatus.store(-1); setLastError("Cache cleanup failed"); }
}

#pragma once
#include "Renderer.h"
#include <cmath>

// Shared LFO implementation for live audition and the waveform/WAV snapshot.
// LFO is relative to clip position, not the host's global transport PPQ.
namespace BloomLive
{
inline double frequency (const RenderSettings& s)
{
    constexpr double cycles[] {0.25, 0.5, 1, 2, 4, 8};
    return s.sync ? s.bpm / 60.0 * cycles[juce::jlimit (0,5,s.rateIndex)] : s.rate;
}
inline void processPhase (float& left, float& right, double p, const RenderSettings& s, float* filter)
{
    p += s.phase;
    const float phase = (float) (p - std::floor (p));
    float wave = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * phase);
    if (s.shape == 1) wave = 1.0f - std::abs (2.0f * phase - 1.0f);
    if (s.shape == 2) wave = phase;
    if (s.shape == 3) wave = 0.5f + 0.5f * std::tanh (8.0f * std::sin (juce::MathConstants<float>::twoPi * phase));
    if (s.target == 0)
    {
        const float gain = 1.0f - s.depth + s.depth * wave;
        left *= gain; right *= gain;
    }
    else if (s.target == 1)
    {
        const float cutoff = 200.0f * std::pow (60.0f, wave);
        const float a = std::exp (-juce::MathConstants<float>::twoPi
            * juce::jmin (cutoff, (float) s.sampleRate * 0.45f) / (float) s.sampleRate);
        filter[0] = (1.0f-a)*left + a*filter[0];
        filter[1] = (1.0f-a)*right + a*filter[1];
        left += s.depth * (filter[0]-left);
        right += s.depth * (filter[1]-right);
    }
    else
    {
        const float pan = (2.0f*wave-1.0f)*s.depth;
        // Attenuation-only balance keeps stereo peaks within the base headroom.
        left *= std::sqrt (1.0f-juce::jmax (0.0f,pan));
        right *= std::sqrt (1.0f+juce::jmin (0.0f,pan));
    }
}
inline void process (float& left, float& right, double time, const RenderSettings& s, float* filter)
{ processPhase (left, right, time * frequency (s), s, filter); }
inline std::shared_ptr<juce::AudioBuffer<float>> bake (
    const juce::AudioBuffer<float>& base, const RenderSettings& s, const std::atomic<bool>& cancel)
{
    auto out = std::make_shared<juce::AudioBuffer<float>> (base);
    float filter[2] {};
    for (int i=0;i<out->getNumSamples();++i)
    {
        if ((i&4095)==0 && cancel.load()) return {};
        float left = out->getSample (0,i), right = out->getSample (1,i);
        process (left,right,i/s.sampleRate,s,filter);
        const float gain = juce::Decibels::decibelsToGain (s.outputDb);
        out->setSample (0,i,left*gain); out->setSample (1,i,right*gain);
    }
    return out;
}
}

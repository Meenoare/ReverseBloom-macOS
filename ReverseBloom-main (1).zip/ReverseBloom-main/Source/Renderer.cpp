#include "Renderer.h"
#include <cmath>

namespace BloomRenderer
{
float envelope(float x,const RenderSettings& s)
{
    x=juce::jlimit(0.0f,1.0f,x);
    if(!s.customCurve)return std::pow(x,s.swell);
    // Sorted levels guarantee a rising envelope, including automated values.
    const float a=juce::jlimit(0.0f,1.0f,s.curve1);
    const float b=juce::jlimit(a,1.0f,s.curve2),c=juce::jlimit(b,1.0f,s.curve3);
    const float levels[]={0,a,b,c,1};
    const float phase=x*4;const int segment=juce::jmin(3,(int)phase);
    const float t=phase-(float)segment;
    float slopes[5],delta[4];for(int i=0;i<4;++i)delta[i]=levels[i+1]-levels[i];
    slopes[0]=delta[0];slopes[4]=delta[3];
    for(int i=1;i<4;++i)slopes[i]=delta[i-1]*delta[i]>0?2*delta[i-1]*delta[i]/(delta[i-1]+delta[i]):0;
    const float t2=t*t,t3=t2*t;
    return juce::jlimit(0.f,1.f,(2*t3-3*t2+1)*levels[segment]+(t3-2*t2+t)*slopes[segment]+(-2*t3+3*t2)*levels[segment+1]+(t3-t2)*slopes[segment+1]);
}

std::shared_ptr<juce::AudioBuffer<float>> render (const juce::AudioBuffer<float>& source,
                                                const RenderSettings& s,
                                                const std::atomic<bool>& cancel)
{
    if (source.getNumSamples() < 1) return {};
    const double bars[] { 0.25, 0.5, 1.0, 2.0, 4.0 };
    const double beatsPerBar = s.numerator * 4.0 / juce::jmax (1, s.denominator);
    const double seconds = juce::jlimit (0.1, 60.0,
        s.lengthInMs ? s.lengthMs/1000.0 : bars[juce::jlimit (0, 4, s.lengthIndex)] * beatsPerBar * 60.0 / s.bpm);
    const int n = juce::jmax (64, (int) std::round (seconds * s.sampleRate));
    auto out = std::make_shared<juce::AudioBuffer<float>> (2, n);
    out->clear();
    juce::Reverb reverb;
    reverb.setSampleRate (s.sampleRate);
    juce::Reverb::Parameters p;
    p.roomSize = juce::jlimit (0.0f, 0.98f, s.size);
    p.damping = 0.35f; p.wetLevel = 1.0f; p.dryLevel = 0.0f;
    p.width = 1.0f; p.freezeMode = 0.0f;
    const int character=juce::jlimit(0,2,s.reverbType);
    if(character==1){p.roomSize=juce::jlimit(0.0f,0.98f,.35f+.64f*s.size);p.damping=.52f;}
    if(character==2){p.roomSize=juce::jlimit(0.0f,0.98f,.2f+.72f*s.size);p.damping=.12f;}
    reverb.setParameters (p);
    // Additional all-pass input diffusion for Hall and Plate, sample-rate scaled.
    std::vector<float> diffusion[2][2];int diffusionIndex[2][2]{};
    for(int ch=0;ch<2;++ch)for(int stage=0;stage<2;++stage)
        diffusion[ch][stage].resize((size_t)juce::jmax(1,(int)(s.sampleRate*(character==1?.019:.0047)*(1+stage*.37+ch*.11))),0);
    const int delaySamples=juce::jmax(0,(int)std::round(juce::jlimit(0.f,250.f,s.preDelayMs)*s.sampleRate/1000));
    // Process the selected source first; then extract its wet tail.
    // Decay is an explicit tail envelope, not a calibrated reverb RT60.
    constexpr int block = 512;
    juce::AudioBuffer<float> temp (2, block);
    const int inputN = source.getNumSamples();
    const int total = inputN + n;
    float lp[2] {};
    const float pole = std::exp (-juce::MathConstants<float>::twoPi
        * juce::jlimit (100.0f, (float) (s.sampleRate * 0.45), s.tone) / (float) s.sampleRate);
    for (int pos = 0; pos < total; pos += block)
    {
        if (cancel.load()) return {};
        const int count = juce::jmin (block, total - pos);
        temp.clear();
        for (int ch = 0; ch < 2; ++ch)
            for (int i = 0; i < count; ++i)
            {
                const int index=pos+i-delaySamples;
                float value=index>=0 && index<inputN?source.getSample(juce::jmin(ch,source.getNumChannels()-1),index):0;
                if(character!=0)for(int stage=0;stage<2;++stage){
                    auto& line=diffusion[ch][stage];auto& at=diffusionIndex[ch][stage];
                    const float coefficient=character==1?.62f:.72f;
                    const float delayed=line[(size_t)at],next=delayed-coefficient*value;
                    line[(size_t)at]=value+coefficient*next;at=(at+1)%(int)line.size();value=next;
                }
                temp.setSample(ch,i,value);
            }
        reverb.processStereo (temp.getWritePointer (0), temp.getWritePointer (1), count);
        for (int i = 0; i < count; ++i)
        {
            const int tail = pos + i - inputN;
            if (tail < 0) continue;
            const int dst = n - 1 - tail;
            const float decay = std::exp (-6.907755f * (float) (tail / s.sampleRate) / s.decay);
            for (int ch = 0; ch < 2; ++ch)
            {
                lp[ch] = (1.0f-pole) * temp.getSample (ch, i) + pole * lp[ch];
                out->setSample (ch, dst, lp[ch] * decay);
            }
        }
    }
    const double cyclesPerBeat[] { 0.25, 0.5, 1, 2, 4, 8 };
    const double hz = s.sync ? s.bpm / 60.0 * cyclesPerBeat[juce::jlimit (0, 5, s.rateIndex)] : s.rate;
    float filterState[2] {}, hpIn[2]{},hpOut[2]{},lpOut[2]{};
    const float hpPole=std::exp(-juce::MathConstants<float>::twoPi*juce::jmin(s.lowCut,(float)s.sampleRate*0.45f)/(float)s.sampleRate);
    const float lpPole=std::exp(-juce::MathConstants<float>::twoPi*juce::jmin(s.highCut,(float)s.sampleRate*0.45f)/(float)s.sampleRate);
    for (int i = 0; i < n; ++i)
    {
        if ((i & 4095) == 0 && cancel.load()) return {};
        const double t = (double) i / s.sampleRate;
        const float phase = (float) (t * hz + s.phase - std::floor (t * hz + s.phase));
        float wave = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * phase);
        if (s.shape == 1) wave = 1.0f - std::abs (2.0f * phase - 1.0f);
        if (s.shape == 2) wave = phase;
        if (s.shape == 3) wave = 0.5f + 0.5f * std::tanh (8.0f * std::sin (juce::MathConstants<float>::twoPi * phase));
        const float swell = envelope((float)i/(float)(n-1),s);
        const float endFade = s.tailFadeMs<=0 ? 1.0f : juce::jlimit (0.0f, 1.0f, (float) (n-1-i) / (float) juce::jmax (1, (int) (s.sampleRate * s.tailFadeMs / 1000.0)));
        const float cutoff = 200.0f * std::pow (60.0f, 1.0f-s.depth+s.depth*wave);
        const float a = std::exp (-juce::MathConstants<float>::twoPi * juce::jmin (cutoff, (float) s.sampleRate*0.45f) / (float) s.sampleRate);
        for (int ch = 0; ch < 2; ++ch)
        {
            const int srcIndex = n-1-i;
            const float dry = srcIndex >= 0 && srcIndex < inputN
                ? source.getSample (juce::jmin (ch, source.getNumChannels()-1), srcIndex) : 0.0f;
            float v = ((1.0f-s.reverseSource)*out->getSample (ch,i) + s.reverseSource*dry) * swell;
            if (s.target == 0) v *= 1.0f-s.depth+s.depth*wave;
            if (s.target == 1) { filterState[ch] = (1.0f-a)*v+a*filterState[ch]; v = filterState[ch]; }
            if (s.target == 2)
            {
                const float pan = (2.0f*wave-1.0f)*s.depth;
                v *= std::sqrt (juce::jmax (0.0f, ch == 0 ? 1.0f-pan : 1.0f+pan));
            }
            if(s.lowCut>20.01f) { const float hp=hpPole*(hpOut[ch]+v-hpIn[ch]); hpIn[ch]=v; hpOut[ch]=hp; v=hp; }
            if(s.highCut<19999.0f) { lpOut[ch]=(1-lpPole)*v+lpPole*lpOut[ch]; v=lpOut[ch]; }
            out->setSample (ch,i,v*endFade);
        }
    }
    float peak = juce::jmax (out->getMagnitude (0,0,n), out->getMagnitude (1,0,n));
    if (s.autoGain && peak > 0.000001f) out->applyGain (juce::jmin (16.0f, 0.89125f/peak));
    return out;
}

bool writeWav (const juce::File& file, const juce::AudioBuffer<float>& buffer, double sr)
{
    auto stream = file.createOutputStream();
    if (!stream) return false;
    juce::WavAudioFormat format;
    std::unique_ptr<juce::AudioFormatWriter> writer (format.createWriterFor (stream.get(), sr,
        (unsigned int) buffer.getNumChannels(), 24, {}, 0));
    if (!writer) return false;
    stream.release();
    return writer->writeFromAudioSampleBuffer (buffer, 0, buffer.getNumSamples());
}
}

#include "Editor.h"
#include "Theme.h"
#include <cmath>

namespace { const auto mint=BloomTheme::amber; }

void BloomEditor::TailMeter::refresh()
{
    left=juce::jmax(processor.tailMeterL.load(),left*0.85f);
    right=juce::jmax(processor.tailMeterR.load(),right*0.85f);
    repaint();
}
void BloomEditor::TailMeter::paint(juce::Graphics& g)
{
    const auto fraction=[](float v) { return juce::jlimit(0.0f,1.0f,(juce::Decibels::gainToDecibels(v,-60.0f)+60.0f)/60.0f); };
    g.setFont(juce::FontOptions(12.0f)); g.setColour(mint);
    g.drawText("TAIL LEVEL",0,0,110,18,juce::Justification::left);
    for(int ch=0;ch<2;++ch)
    {
        const float v=ch==0?left:right; const int y=24+ch*20;
        g.setColour(juce::Colours::white); g.drawText(ch==0?"L":"R",0,y,15,14,juce::Justification::left);
        g.setColour(juce::Colour(0xff30364c)); g.fillRoundedRectangle(20.0f,(float)y,250.0f,12.0f,3.0f);
        g.setColour(v>=1.0f?juce::Colours::orange:mint); g.fillRoundedRectangle(20.0f,(float)y,250.0f*fraction(v),12.0f,3.0f);
    }
    const float peak=processor.tailHeldPeak.load();
    g.setColour(peak>1.0f?juce::Colours::red:juce::Colour(0xffc3cade));
    const auto text=peak>0.0f?juce::String(juce::Decibels::gainToDecibels(peak),1)+" dBFS":"-- dBFS";
    g.drawText("Peak: "+text,0,66,210,18,juce::Justification::left);
    g.drawText(peak>1.0f?"OVER":"",214,66,66,18,juce::Justification::right);
}
BloomEditor::WaveView::~WaveView() {if(peakWorker.joinable()) peakWorker.join();}
void BloomEditor::WaveView::updatePeaks(const std::shared_ptr<juce::AudioBuffer<float>>& audio)
{
    const int width=juce::jmax(1,getWidth()-24);
    const float start=isSource?viewStart:0.0f,span=isSource?viewSpan:1.0f;
    if(peakReady.exchange(false)) {
        if(pendingSource==audio && pendingStart==start && pendingSpan==span && pendingWidth==width) {
            peakBins=std::move(pendingBins);peakSource=pendingSource;peakViewStart=start;peakViewSpan=span;
        }
    }
    if(audio==peakSource && peakViewStart==start && peakViewSpan==span && (int)peakBins.size()==width) return;
    if(peakBusy.load()) return;
    if(peakWorker.joinable()) peakWorker.join();
    peakBusy.store(true);
    peakWorker=std::thread([this,audio,start,span,width]{
        try {
            std::vector<float> bins((size_t)width);const int n=audio->getNumSamples();
            if(n>0) for(int x=0;x<width;++x) {
                const int a=juce::jlimit(0,n-1,(int)((start+span*x/width)*n));
                const int b=juce::jlimit(a+1,n,(int)((start+span*(x+1)/width)*n));
                bins[(size_t)x]=juce::jmax(audio->getMagnitude(0,a,b-a),audio->getMagnitude(1,a,b-a));
            }
            pendingBins=std::move(bins);pendingSource=audio;pendingStart=start;pendingSpan=span;pendingWidth=width;peakReady.store(true);
        } catch(...) {}
        peakBusy.store(false);
    });
}
void BloomEditor::applyScale()
{
    appliedScale=juce::jlimit(0,2,processor.uiScale.load());
    scaleChoice.setSelectedId(appliedScale+1,juce::dontSendNotification);
    const float factor=appliedScale==0?0.5f:appliedScale==1?0.75f:1.0f;
    canvas.setTransform(juce::AffineTransform::scale(factor));
    setSize((int)(900*factor),(int)(900*factor));
}
void BloomEditor::updateRateBinding()
{
    const int binding=processor.parameters.getRawParameterValue("sync")->load()>0.5f ? 1:0;
    if(binding==rateBinding) return;
    rateAttachment.reset(); rateBinding=binding;
    auto& slider=*knobs[6]; slider.setEnabled(true);
    slider.setTextValueSuffix("");
    if(binding)
    {
        slider.textFromValueFunction=[](double v) { return juce::StringArray{"1/1","1/2","1/4","1/8","1/16","1/32"}[juce::jlimit(0,5,(int)std::round(v))]; };
        slider.valueFromTextFunction=[](const juce::String& t) { const int i=juce::StringArray{"1/1","1/2","1/4","1/8","1/16","1/32"}.indexOf(t.trim()); return (double)juce::jmax(0,i); };
    }
    else
    {
        slider.textFromValueFunction=[](double v){return juce::String(v,2)+" Hz";};
        slider.valueFromTextFunction=[](const juce::String& t){return t.getDoubleValue();};
    }
    auto* parameter=processor.parameters.getParameter(binding ? "division":"rate");
    rateAttachment=std::make_unique<SliderAttachment>(processor.parameters,binding ? "division":"rate",slider);
    slider.setDoubleClickReturnValue(true,parameter->convertFrom0to1(parameter->getDefaultValue()));
    slider.setTooltip(binding ? "LFO speed in musical divisions, following BPM." : "LFO speed in Hz, independent of BPM.");
    slider.updateText();
}


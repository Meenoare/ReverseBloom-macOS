#pragma once
#include <JuceHeader.h>
#include <cmath>
namespace BloomTheme {
inline const juce::Colour background(0xff303037), surface(0xff202025), raised(0xff3b3b44),
    border(0xff101014), text(0xffededf0), muted(0xffb0adb7), violet(0xffad77ed), amber(0xff78c9d9);
inline juce::ColourGradient neon(float x,float y,float w,float h,double phase=0) {
    const float mix=(float)(0.5+0.5*std::sin(phase));
    juce::ColourGradient g(amber.interpolatedWith(violet,mix),x,y,violet.interpolatedWith(amber,mix),x+w,y+h,false);
    g.addColour(0.5,juce::Colour(0xff8c8fea));return g;
}
inline void glow(juce::Graphics& g,juce::Rectangle<float> r,float radius,juce::Colour c) {
    for(int i=6;i>=1;--i){g.setColour(c.withAlpha(0.012f*(7-i)));g.drawRoundedRectangle(r.expanded(i*0.7f),radius+i*0.5f,1.4f);}
}

inline juce::Font font(float size, bool bold=false) {return juce::Font(juce::FontOptions(size,bold?juce::Font::bold:juce::Font::plain));}
}

#include "Processor.h"
#ifndef RB_VERSION
#define RB_VERSION "0.9.7"
#define RB_BUILD_ID "local-syntax-check"
#endif

void BloomProcessor::setLastError(const juce::String& message)
{ const juce::ScopedLock lock(errorLock); lastError=message; }
BloomProcessor::EditState BloomProcessor::readEditState() const
{
    EditState s; for(auto* p:getParameters()) s.values.push_back(p->getValue());
    s.begin=getSelectionBegin(); s.end=getSelectionEnd(); s.loopValue=loop.load(); return s;
}
bool BloomProcessor::sameEditState(const EditState& a,const EditState& b)
{ return a.values==b.values && a.begin==b.begin && a.end==b.end && a.loopValue==b.loopValue; }
void BloomProcessor::resetEditHistory()
{ historyReady=false; slotsReady=false; slotB=false; undoStack.clear(); redoStack.clear(); }
void BloomProcessor::pollHistory()
{
    while(undoStack.size()>100) undoStack.erase(undoStack.begin());
    while(redoStack.size()>100) redoStack.erase(redoStack.begin());
    const auto s=readEditState();
    if(!historyReady) { historyState=s; historyReady=true; slotAState=s; slotBState=s; slotsReady=true; return; }
    if(sameEditState(s,historyState)) return;
    if(!userEditing.load()) {historyState=s; return;}
    const auto now=juce::Time::getMillisecondCounterHiRes();
    if(now-lastEditTime>500 || undoStack.empty()) {
        undoStack.push_back(historyState);
        if(undoStack.size()>100) undoStack.erase(undoStack.begin());
    }
    redoStack.clear(); historyState=s; lastEditTime=now;
}
void BloomProcessor::applyEditState(const EditState& s)
{
    const auto& ps=getParameters();
    for(int i=0;i<ps.size() && i<(int)s.values.size();++i) {
        if(ps[i]->getValue()!=s.values[(size_t)i]) {
            ps[i]->beginChangeGesture(); ps[i]->setValueNotifyingHost(s.values[(size_t)i]); ps[i]->endChangeGesture();
        }
    }
    setSelection(s.begin,s.end); loop.store(s.loopValue);
    historyState=readEditState(); historyReady=true; lastEditTime=0;
}
void BloomProcessor::undoSettings()
{
    pollHistory(); if(undoStack.empty()) return;
    redoStack.push_back(readEditState()); const auto s=undoStack.back(); undoStack.pop_back(); applyEditState(s);
}
void BloomProcessor::redoSettings()
{
    pollHistory(); if(redoStack.empty()) return;
    undoStack.push_back(readEditState()); const auto s=redoStack.back(); redoStack.pop_back(); applyEditState(s);
}
void BloomProcessor::switchAB()
{
    pollHistory(); if(!slotsReady) return;
    if(slotB) slotBState=readEditState(); else slotAState=readEditState();
    undoStack.push_back(readEditState()); redoStack.clear(); slotB=!slotB;
    applyEditState(slotB?slotBState:slotAState);
}
void BloomProcessor::trimSilence() { requestTrim(); }
void BloomProcessor::requestTrim(bool)
{ if(!isCapturing()) trimRequested.store(true); }
void BloomProcessor::serviceAnalysis()
{
    if(trimReady.exchange(false)) {
        if(trimRevision==captureRevision.load() && !isCapturing()) {
            pollHistory(); undoStack.push_back(readEditState()); redoStack.clear();
            setSelection(trimBegin,trimEnd); historyState=readEditState(); lastEditTime=0;
        }
    }
    if(!trimRequested.load() || analysisBusy.load() || trimReady.load() || isCapturing()) return;
    if(analysisWorker.joinable()) analysisWorker.join();
    auto source=getSource(); if(!source) {trimRequested.store(false); return;}
    trimRequested.store(false); analysisBusy.store(true);
    const auto revision=captureRevision.load(); const auto sr=activeRate.load();
    analysisWorker=std::thread([this,source,revision,sr] {
        try {
            const int n=source->getNumSamples(); float peak=0;
            for(int ch=0;ch<source->getNumChannels();++ch) peak=juce::jmax(peak,source->getMagnitude(ch,0,n));
            if(peak<1.0e-7f) {setLastError("Auto selection: source is silent"); analysisBusy.store(false); return;}
            const float threshold=peak*juce::Decibels::decibelsToGain(-50.0f);
            auto audible=[&](int i){for(int ch=0;ch<source->getNumChannels();++ch) if(std::abs(source->getSample(ch,i))>=threshold) return true; return false;};
            int first=0,last=n-1; while(first<n && !audible(first)) ++first; while(last>first && !audible(last)) --last;
            const int pad=(int)(sr*0.005); first=juce::jmax(0,first-pad); last=juce::jmin(n,last+pad+1);
            if(last-first>=64) {trimBegin=(float)first/n; trimEnd=(float)last/n; trimRevision=revision; trimReady.store(true);}
            else setLastError("Auto selection: range too short");
        } catch(...) {setLastError("Selection analysis failed");}
        analysisBusy.store(false);
    });
}
juce::String BloomProcessor::diagnostics() const
{
    juce::String text;
    text<<"ReverseBloom "<<RB_VERSION<<"\nBuild: "<<RB_BUILD_ID<<"\n"
        <<"Sample rate: "<<activeRate.load()<<"\nBuffer size (last block): "<<bufferSize.load()
        <<"\nBPM: "<<bpm.load()<<"\nUI scale index: "<<uiScale.load()
        <<"\nRender status: "<<renderStatus.load()<<"\nExport status: "<<exportStatus.load()
        <<"\nCache status: "<<cacheStatus.load()<<"\nCapture state: "<<captureState.load()
        <<"\nPlaying: "<<(int)playing.load()<<"\nLoop: "<<(int)loop.load()
        <<"\nSelection: "<<getSelectionBegin()<<".."<<getSelectionEnd()
        <<"\nGain lock value: "<<lockedGain.load()<<" (valid="<<(int)lockedGainValid.load()<<")\nParameters:\n";
    for(auto* p:getParameters()) text<<p->getName(100)<<": "<<p->getCurrentValueAsText()<<"\n";
    {const juce::ScopedLock lock(errorLock); text<<"Last error: "<<(lastError.isEmpty()?"none":lastError)<<"\n";}
    text<<"No audio, paths, user names, project names or system identifiers included.\n";
    return text;
}

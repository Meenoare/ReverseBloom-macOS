#include "Processor.h"

void BloomProcessor::collectRetired()
{
    // Only called after worker released busy; registry always owns callback-visible objects.
    retainedPackets.erase(std::remove_if(retainedPackets.begin(),retainedPackets.end(),
        [](const auto& p){ return p.use_count()==1; }),retainedPackets.end());
    retainedAudio.erase(std::remove_if(retainedAudio.begin(),retainedAudio.end(),
        [](const auto& p){ return p.use_count()==1; }),retainedAudio.end());
}
void BloomProcessor::prepareExport()
{
    if(exportBusy.load() || !isResultCurrent()) return;
    const bool retry=exportRetry.exchange(false);
    const auto key=fingerprint(false);
    { const juce::ScopedLock lock(exportLock);
      if(exportedKey==key && exportFile.existsAsFile()) { if(retry || exportStatus.load()!=-1) exportStatus.store(2); return; } }
    if(!retry && exportAttemptKey==key) return;
    exportAttemptKey=key;
    if(exportWorker.joinable()) exportWorker.join();
    const auto snapshot=getResult(); const auto sr=activeRate.load(),tempo=bpm.load();
    const auto packet=std::atomic_load(&publishedPacket);
    const bool joined=parameters.getRawParameterValue("exportmode")->load()>0.5f;
    const float gap=parameters.getRawParameterValue("endgap")->load();
    const float fade=parameters.getRawParameterValue("sourcefade")->load();
    const auto epoch=exportEpoch.load();
    exportBusy.store(true); exportStatus.store(1);
    exportWorker=std::thread([this,snapshot,packet,joined,gap,fade,sr,tempo,key,epoch]
    {
        bool ok=false; juce::File file;
        try {
            const auto folder=cacheDirectory();
            if(folder.createDirectory()) {
                file=folder.getChildFile("ReverseBloom_"+juce::String(tempo,1)+"BPM_"+juce::Uuid().toString()+".wav");
                auto output=snapshot;
                if(joined && snapshot && packet && packet->source) {
                    const int gapSamples=(int)std::round(gap*sr/1000.0), tail=snapshot->getNumSamples();
                    output=std::make_shared<juce::AudioBuffer<float>>(2,tail+gapSamples+packet->count); output->clear();
                    for(int ch=0;ch<2;++ch) {
                        output->copyFrom(ch,0,*snapshot,ch,0,tail);
                        output->copyFrom(ch,tail+gapSamples,*packet->source,ch,packet->first,packet->count);
                        const int fadeSamples=juce::jmin(packet->count,(int)(fade*sr/1000.0));
                        if(fadeSamples>0) for(int i=0;i<fadeSamples;++i)
                            output->setSample(ch,tail+gapSamples+i,output->getSample(ch,tail+gapSamples+i)*(float)i/(float)juce::jmax(1,fadeSamples));
                    }
                }
                ok=output && BloomRenderer::writeWav(file,*output,sr);
            }
        } catch(...) { ok=false; }
        if(ok && epoch==exportEpoch.load()) {
            registerCacheFile(file);
            const juce::ScopedLock lock(exportLock); exportFile=file; exportedKey=key;
            exportStatus.store(2);
        } else { if(file.existsAsFile()) file.deleteFile(); setLastError("Cannot prepare cache WAV (disk space or permissions)"); exportStatus.store(-1); }
        cleanCache(false);
        exportBusy.store(false);
    });
}
void BloomProcessor::saveExportTo(const juce::File& destination)
{
    const auto managedRoot=cacheDirectory().getParentDirectory();
    if(destination.isAChildOf(managedRoot)) {
        setLastError("Choose an export destination outside the managed cache folder"); exportStatus.store(-1); return;
    }
    const auto source=getExportFile(); if(!source.existsAsFile() || exportBusy.load()) return;
    if(exportWorker.joinable()) exportWorker.join();
    exportBusy.store(true); exportStatus.store(1);
    exportWorker=std::thread([this,source,destination]
    {
        bool ok=false;
        try { ok=source==destination || source.copyFileTo(destination); } catch(...) {}
        if(ok) source.setLastModificationTime(juce::Time::getCurrentTime());
        if(!ok) setLastError("Cannot save WAV (disk space or destination permissions)");
        exportStatus.store(ok ? 2 : -1); exportBusy.store(false);
    });
}

void BloomProcessor::retryExport() { exportRetry.store(true); }

#include "Editor.h"
#include "Theme.h"
#include <cmath>
using namespace BloomTheme;
juce::Font BloomLook::getComboBoxFont(juce::ComboBox&) {return font(14);}
juce::Font BloomLook::getTextButtonFont(juce::TextButton& b,int) {return font(b.getName()=="reference-flat"?12.0f:14.0f,true);}
void BloomLook::drawButtonBackground(juce::Graphics& g,juce::Button& b,const juce::Colour&,bool hover,bool down)
{
 const auto name=b.getName();auto r=b.getLocalBounds().toFloat().reduced(3);
 const bool tab=name=="reference-tab",flat=name=="reference-flat",selected=b.getToggleState();
 const bool luminous=name=="neon-menu"||(tab&&selected);
 g.setOpacity(b.isEnabled()?1.0f:0.38f);
 if(tab){if(hover||down){g.setColour(text.withAlpha(0.045f));g.fillRoundedRectangle(r,15);}if(b.hasKeyboardFocus(false)){g.setColour(amber);g.drawRoundedRectangle(r,15,1);}return;}
 if(flat){if(hover||down){g.setColour(text.withAlpha(0.06f));g.fillRoundedRectangle(r,5);}return;}
 const float corner=tab?7.0f:9.0f;
 if(luminous){glow(g,r.reduced(2),corner,tab?violet:amber);glow(g,r.reduced(1),corner,amber);}
 g.setColour(juce::Colours::black.withAlpha(0.4f));g.fillRoundedRectangle(r.translated(0,2),corner);
 g.setGradientFill(juce::ColourGradient(down?surface:raised,r.getX(),r.getY(),surface,r.getRight(),r.getBottom(),false));g.fillRoundedRectangle(r,corner);
 g.setColour(border);g.drawRoundedRectangle(r,corner,1.5f);
 g.setColour(text.withAlpha(0.13f));g.drawRoundedRectangle(r.reduced(1.5f),corner-1,0.7f);
 if(luminous){g.setGradientFill(neon(r.getX(),r.getY(),r.getWidth(),r.getHeight(),juce::Time::getMillisecondCounterHiRes()*0.0005));g.drawRoundedRectangle(r.reduced(1),corner,1.4f);}
 if(hover){g.setColour(text.withAlpha(0.045f));g.fillRoundedRectangle(r,corner);}
 if(b.hasKeyboardFocus(false)){g.setColour(amber);g.drawRoundedRectangle(r.reduced(1),corner,1.5f);}
}
void BloomLook::drawButtonText(juce::Graphics& g,juce::TextButton& b,bool,bool)
{
 g.setOpacity(b.isEnabled()?1.0f:0.38f);g.setColour(b.getToggleState()?violet:text);g.setFont(getTextButtonFont(b,b.getHeight()));
 auto box=b.getLocalBounds().reduced(3,0);const bool preview=b.getButtonText()=="LISTEN"||b.getButtonText()=="STOP";
 if(preview){
  // Reserve an icon box; do not paint icon on top of the label.
  const float x=7,y=b.getHeight()*0.5f;
  if(b.getButtonText()=="LISTEN"){juce::Path p;p.startNewSubPath(x,y-4);p.lineTo(x+6,y);p.lineTo(x,y+4);p.closeSubPath();g.fillPath(p);}
  else g.fillRoundedRectangle(x,y-3,6,6,1);
  box.removeFromLeft(12);
 }
 g.drawText(b.getButtonText(),box,juce::Justification::centred);
}
void BloomLook::drawComboBox(juce::Graphics& g,int w,int h,bool,int,int,int,int,juce::ComboBox& box)
{
 auto r=juce::Rectangle<float>(2,3,(float)w-4,(float)h-6);
 g.setGradientFill(juce::ColourGradient(juce::Colour(0xff19191e),0,0,juce::Colour(0xff2b2a32),0,(float)h,false));g.fillRoundedRectangle(r,8);
 g.setColour(border);g.drawRoundedRectangle(r,8,1.4f);g.setColour(text.withAlpha(0.15f));g.drawRoundedRectangle(r.reduced(1),7,0.6f);
 if(box.hasKeyboardFocus(true)){g.setColour(amber);g.drawRoundedRectangle(r,8,1.5f);}
 juce::Path p;p.startNewSubPath(w-19.0f,h*0.46f);p.lineTo(w-14.0f,h*0.58f);p.lineTo(w-9.0f,h*0.46f);g.setColour(muted);g.strokePath(p,juce::PathStrokeType(1.5f));
}
void BloomLook::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float value,float begin,float end,juce::Slider& slider)
{
 const bool hero=slider.getName()=="reverse-hero";const float radius=juce::jmin((float)w,(float)h)*0.5f-(hero?9:9),cx=x+w*0.5f,cy=y+h*0.5f;
 const auto disk=juce::Rectangle<float>(cx-radius,cy-radius,2*radius,2*radius);
 for(int i=12;i>=1;--i){g.setColour(juce::Colours::black.withAlpha(0.025f));g.fillEllipse(disk.expanded(i*0.8f).translated(0,4));}
 g.setGradientFill(juce::ColourGradient(juce::Colour(0xff55545e),cx,cy-radius-4,juce::Colour(0xff111115),cx,cy+radius+5,false));g.fillEllipse(disk.expanded(5));
 g.setColour(juce::Colours::black.withAlpha(0.88f));g.drawEllipse(disk.expanded(3),hero?1.2f:2.0f);
 g.setGradientFill(juce::ColourGradient(raised.brighter(0.18f),cx,cy-radius,surface.darker(0.08f),cx,cy+radius,false));g.fillEllipse(disk);
 g.setColour(text.withAlpha(0.22f));g.drawEllipse(disk.reduced(1),0.7f);
 g.setColour(border);g.drawEllipse(disk,1.4f);
 if(hero){
  const float ring=radius-12;
  g.setGradientFill(juce::ColourGradient(juce::Colour(0xff191322),cx,cy-radius,juce::Colour(0xff141521),cx,cy+radius,false));g.fillEllipse(disk.reduced(3));
  const float phase=(float)(juce::Time::getMillisecondCounterHiRes()*0.001);
  const float breath=0.84f+0.16f*std::sin(phase*1.1f);
  for(int i=16;i>=1;--i){g.setColour(violet.withAlpha(0.018f*breath));g.drawEllipse(cx-ring,cy-ring,ring*2,ring*2,(float)i+1);}
  const float motion=phase*0.38f;
  juce::ColourGradient ringGradient(juce::Colour(0xff758ccf),cx+std::cos(motion)*ring,cy+std::sin(motion)*ring,juce::Colour(0xffb67af1),cx-std::cos(motion)*ring,cy-std::sin(motion)*ring,false);
  ringGradient.addColour(0.52,juce::Colour(0xff7986ed));g.setGradientFill(ringGradient);g.drawEllipse(cx-ring,cy-ring,ring*2,ring*2,5.2f);
  g.setColour(juce::Colour(0xffd6c4ff).withAlpha(0.32f*breath));g.drawEllipse(cx-ring+3,cy-ring+3,ring*2-6,ring*2-6,0.85f);
  for(int i=0;i<=64;++i){const float a=begin+(end-begin)*i/64.0f;g.setColour(text.withAlpha(i%8==0?0.8f:0.35f));g.drawLine(cx+std::sin(a)*(radius+6),cy-std::cos(a)*(radius+6),cx+std::sin(a)*(radius+6+(i%8==0?2.4f:1.2f)),cy-std::cos(a)*(radius+6+(i%8==0?2.4f:1.2f)),i%8==0?1.5f:0.8f);}
 } else {
  juce::Path track;track.addCentredArc(cx,cy,radius+5,radius+5,0,begin,end,true);g.setColour(juce::Colour(0xff4a4852));g.strokePath(track,juce::PathStrokeType(3.0f));
  juce::Path active;active.addCentredArc(cx,cy,radius+5,radius+5,0,begin,begin+value*(end-begin),true);g.setColour(amber);g.strokePath(active,juce::PathStrokeType(3.0f));
 }
 const float inner=radius-(hero?23:7);
 g.setGradientFill(juce::ColourGradient(juce::Colour(0xff41404a),cx-inner,cy-inner,juce::Colour(0xff25252c),cx+inner,cy+inner,false));g.fillEllipse(cx-inner,cy-inner,2*inner,2*inner);
 g.setGradientFill(juce::ColourGradient(text.withAlpha(hero?0.055f:0.09f),cx-inner*0.45f,cy-inner*0.65f,juce::Colours::transparentWhite,cx,cy,true));g.fillEllipse(cx-inner,cy-inner,2*inner,2*inner);
 g.setColour(text.withAlpha(0.14f));g.drawEllipse(cx-inner,cy-inner,inner*2,inner*2,0.8f);

 const float a=begin+value*(end-begin);g.setColour(text);g.drawLine(cx+std::sin(a)*inner*0.77f,cy-std::cos(a)*inner*0.77f,cx+std::sin(a)*inner*0.95f,cy-std::cos(a)*inner*0.95f,hero?3:2);
}
void BloomLook::drawToggleButton(juce::Graphics& g,juce::ToggleButton& b,bool hover,bool down)
{
 const float cy=b.getHeight()*0.5f;auto r=juce::Rectangle<float>(3,cy-8,13,16);
 g.setOpacity(b.isEnabled()?1:0.38f);if(b.getToggleState())glow(g,r,3,violet);
 g.setGradientFill(juce::ColourGradient(b.getToggleState()?violet:surface,3,cy-8,b.getToggleState()?amber:raised,16,cy+8,false));g.fillRoundedRectangle(r,3);
 g.setColour(b.hasKeyboardFocus(false)?amber:muted.withAlpha(0.5f));g.drawRoundedRectangle(r,3,0.8f);
 g.setColour(hover||down?text:muted);g.setFont(font(13));g.drawText(b.getButtonText(),22,0,b.getWidth()-23,b.getHeight(),juce::Justification::left);
}
void BloomLook::drawLinearSlider(juce::Graphics& g,int x,int y,int w,int h,float pos,float,float,const juce::Slider::SliderStyle style,juce::Slider& slider)
{
 if(style!=juce::Slider::LinearHorizontal){juce::LookAndFeel_V4::drawLinearSlider(g,x,y,w,h,pos,pos,pos,style,slider);return;}
 const float cy=y+h*0.5f;auto r=juce::Rectangle<float>((float)x,cy-3,(float)w,6);
 g.setColour(border);g.fillRoundedRectangle(r.expanded(1),4);g.setColour(juce::Colour(0xff34203f));g.fillRoundedRectangle(r,3);
 g.setGradientFill(juce::ColourGradient(violet,(float)x,cy,juce::Colour(0xffffa16f),(float)(x+w),cy,false));g.fillRoundedRectangle((float)x,cy-3,juce::jmax(0.0f,pos-x),6,3);
 g.setColour(violet.withAlpha(0.08f));g.fillEllipse(pos-11,cy-11,22,22);g.setColour(violet.withAlpha(0.13f));g.fillEllipse(pos-8,cy-8,16,16);g.setColour(violet);g.fillEllipse(pos-5,cy-5,10,10);g.setColour(text.withAlpha(0.5f));g.drawEllipse(pos-5,cy-5,10,10,0.6f);
}

juce::Slider::SliderLayout BloomLook::getSliderLayout(juce::Slider& slider)
{
 auto result=juce::LookAndFeel_V4::getSliderLayout(slider);
 if(slider.getName()=="reverse-hero") {
     result.sliderBounds={0,0,362,322};
     result.textBoxBounds={151,317,60,24};
 }
 return result;
}

namespace {
class BloomValueLabel final : public juce::Label {
public:
 explicit BloomValueLabel(bool bare):plain(bare) {setJustificationType(juce::Justification::centred);setFont(BloomTheme::font(15));}
 void paint(juce::Graphics& g) override {
  if(!plain){auto r=getLocalBounds().toFloat().reduced(0.6f);g.setGradientFill(juce::ColourGradient(juce::Colour(0xff1b1b20),0,0,BloomTheme::surface,0,(float)getHeight(),false));g.fillRoundedRectangle(r,3);g.setColour(juce::Colour(0xff62616a));g.drawRoundedRectangle(r,3,0.8f);}
  if(!isBeingEdited()){g.setColour(isEnabled()?BloomTheme::text:BloomTheme::muted);g.setFont(getFont());g.drawFittedText(getText(),getLocalBounds().reduced(2),juce::Justification::centred,1);}
 }
private: bool plain;
};
}
juce::Label* BloomLook::createSliderTextBox(juce::Slider& slider) {
 auto* label=new BloomValueLabel(slider.getName()=="reverse-hero");
 label->setColour(juce::TextEditor::backgroundColourId,BloomTheme::surface);
 label->setColour(juce::TextEditor::textColourId,BloomTheme::text);
 label->setColour(juce::TextEditor::outlineColourId,BloomTheme::violet);
 return label;
}

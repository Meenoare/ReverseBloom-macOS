#pragma once
#include "Processor.h"

class BloomLook final : public juce::LookAndFeel_V4
{
public:
    BloomLook();
    juce::Label* createSliderTextBox(juce::Slider&) override;
    juce::Slider::SliderLayout getSliderLayout(juce::Slider&) override;
    void drawButtonBackground(juce::Graphics&,juce::Button&,const juce::Colour&,bool,bool) override;
    void drawButtonText(juce::Graphics&,juce::TextButton&,bool,bool) override;
    void drawComboBox(juce::Graphics&,int,int,bool,int,int,int,int,juce::ComboBox&) override;
    void drawToggleButton(juce::Graphics&,juce::ToggleButton&,bool,bool) override;
    void drawLinearSlider(juce::Graphics&,int,int,int,int,float,float,float,const juce::Slider::SliderStyle,juce::Slider&) override;
    juce::Font getComboBoxFont(juce::ComboBox&) override;
    juce::Font getTextButtonFont(juce::TextButton&,int) override;
    void drawRotarySlider (juce::Graphics&, int,int,int,int,float,float,float,juce::Slider&) override;
};

class BloomEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit BloomEditor (BloomProcessor&);
    ~BloomEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;
private:
    class WaveView final : public juce::Component
    {
    public:
        explicit WaveView (BloomProcessor& p, bool source = false) : processor (p), isSource(source) {}
        ~WaveView() override;
        void mouseDown(const juce::MouseEvent&) override;
        void fitSelection() {viewStart=processor.getSelectionBegin(); viewSpan=juce::jmax(0.0001f,processor.getSelectionEnd()-viewStart); repaint();}
        void resetView() {viewStart=0;viewSpan=1;repaint();}
        void mouseDrag(const juce::MouseEvent&) override;
        void mouseDoubleClick(const juce::MouseEvent&) override;
        void mouseWheelMove(const juce::MouseEvent&, const juce::MouseWheelDetails&) override;
        void paint (juce::Graphics&) override;
    private:
        BloomProcessor& processor;
        std::array<float,160> liveBins {};
        double lastLiveUpdate=0;
        float liveEnvelope=0;
        bool wasRecording=false;
        bool isSource = false;
        float viewStart = 0.0f, viewSpan = 1.0f, anchor = 0.0f;
        juce::Point<int> dragOrigin;
        bool waveDragStarted=false;
        float fraction(float x) const;
        std::shared_ptr<juce::AudioBuffer<float>> peakSource;
        std::vector<float> peakBins;
        float peakViewStart=-1.0f, peakViewSpan=-1.0f;
        void updatePeaks(const std::shared_ptr<juce::AudioBuffer<float>>&);
        std::thread peakWorker;
        std::atomic<bool> peakBusy {false}, peakReady {false};
        std::vector<float> pendingBins;
        std::shared_ptr<juce::AudioBuffer<float>> pendingSource;
        float pendingStart=0,pendingSpan=1;
        int pendingWidth=0;
    };
    class DragButton final : public juce::TextButton
    {
    public:
        explicit DragButton (BloomProcessor& p) : juce::TextButton ("DRAG WAV"), processor (p) {}
        void mouseDown (const juce::MouseEvent& e) override
        { origin = e.getPosition(); dragged = false; juce::TextButton::mouseDown (e); }
        void mouseDrag (const juce::MouseEvent& e) override;
    private:
        BloomProcessor& processor;
        juce::Point<int> origin;
        bool dragged = false;
    };
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    void timerCallback() override;
    void updateRateBinding();
    void applyScale();
    juce::ComboBox scaleChoice;
    juce::TextButton clearCacheButton {"Clear Cache"}, diagnosticsButton {"Copy Diagnostics"},
        trimButton {"Trim Silence"}, abButton {"A / B"}, undoButton {"Undo"}, redoButton {"Redo"};
    juce::ToggleButton gainLockButton {"Gain Lock"};
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> gainLockAttachment;
    void setupTools();
    void showSettings();
    void showAdvanced();
    void presetFileDialog(bool save);
    void updateLengthBinding();
    juce::TextButton settingsButton {"Settings"}, fitButton {"Fit Selection"}, resetViewButton {"Reset View"};
    juce::ComboBox presetChoice;
    juce::TextButton previousPreset {"<"}, nextPreset {">"};
    juce::Label rangeInfo;
    juce::TextButton rawButton {"RAW"}, editButton {"EDIT"}, tailPanelButton {"TAIL"}, lfoPanelButton {"LFO"}, outputPanelButton {"OUTPUT"};
    bool showRaw=false;
    int openPanel=0;
    void setupWorkflowUI();
    juce::TextButton resetWaveButton {"RESET"};
    float tabTransition=0.0f;
    std::vector<std::unique_ptr<juce::Slider>> tailDetails;
    std::vector<std::unique_ptr<juce::Label>> tailDetailLabels;
    std::vector<std::unique_ptr<SliderAttachment>> tailDetailAttachments;
    std::unique_ptr<SliderAttachment> lengthAttachment;
    juce::String presetSignature;
    int lengthBinding=-1;
    std::unique_ptr<SliderAttachment> rateAttachment;
    int rateBinding=-1, appliedScale=-1, lastExportStatus=0;
    void addKnob (const char* id, const char* title);
    void addChoice (const char* id, const char* title, const juce::StringArray&);
    BloomProcessor& processor;
    BloomLook look;
    class ScaledCanvas final : public juce::Component
    {
    public:
        std::function<void(juce::Graphics&)> draw;
        void paint(juce::Graphics& g) override { if(draw) draw(g); }
    };
    ScaledCanvas canvas;
    void paintCanvas(juce::Graphics&);
    class TailMeter final : public juce::Component, public juce::SettableTooltipClient
    {
    public:
        explicit TailMeter(BloomProcessor& p) : processor(p) {}
        void paint(juce::Graphics&) override;
        void mouseDown(const juce::MouseEvent&) override { processor.resetTailPeak.store(true); }
        void refresh();
    private:
        BloomProcessor& processor;
        float left=0.0f,right=0.0f;
    };
    TailMeter tailMeter;
    WaveView waveform, sourceWave;
    juce::TextButton capture {"CAPTURE"}, stop {"STOP CAPTURE"};
    juce::Label autoLabel;
    juce::TextButton listen {"LISTEN"}, exportButton {"EXPORT WAV"};
    DragButton drag;
    juce::ToggleButton loop {"Loop"}, sync {"Tempo sync"}, autoGain {"Auto Gain"};
    juce::Label status, trimLabel, gapLabel, pauseLabel;
    juce::Slider gapSlider, pauseSlider;
    std::unique_ptr<SliderAttachment> gapAttachment, pauseAttachment;
    juce::TooltipWindow tooltips {this,650};
    juce::Slider selection;
    std::vector<std::unique_ptr<juce::Slider>> knobs;
    std::vector<std::unique_ptr<juce::Label>> knobLabels;
    std::vector<std::unique_ptr<SliderAttachment>> sliderAttachments;
    std::vector<std::unique_ptr<juce::ComboBox>> choices;
    std::vector<std::unique_ptr<juce::Label>> choiceLabels;
    std::vector<std::unique_ptr<ComboAttachment>> comboAttachments;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> syncAttachment, gainAttachment;
    std::unique_ptr<juce::FileChooser> chooser;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (BloomEditor)
};

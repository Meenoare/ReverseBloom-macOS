#pragma once
#include <algorithm>
#include <cstdint>

namespace BloomPreview
{
enum Stage { idle=0, tail=1, gap=2, source=3, pause=4 };
struct Frame { Stage stage=idle; int offset=0; };
struct Timeline
{
    int tailSamples=0, gapSamples=0, sourceSamples=0, pauseSamples=0;
    std::int64_t total() const
    { return (std::int64_t)tailSamples+gapSamples+sourceSamples+pauseSamples; }
    Frame at(std::int64_t position) const
    {
        if(position<0 || position>=total()) return {};
        if(position<tailSamples) return {tail,(int)position};
        position-=tailSamples;
        if(position<gapSamples) return {gap,(int)position};
        position-=gapSamples;
        if(position<sourceSamples) return {source,(int)position};
        position-=sourceSamples;
        return {pause,(int)position};
    }
};
inline float edgeGain(int at,int length,int fadeSamples)
{
    const int fade=std::max(1,std::min(fadeSamples,length/2));
    return std::max(0.0f,std::min(1.0f,std::min((float)at/fade,(float)(length-1-at)/fade)));
}
// Keep source/gap offset when a newly rendered tail changes duration.
inline std::int64_t remap(std::int64_t position,int oldTail,int newTail)
{
    if(oldTail>0 && position<oldTail)
        return std::min((std::int64_t)newTail-1,position*newTail/oldTail);
    return position+(std::int64_t)newTail-oldTail;
}
}

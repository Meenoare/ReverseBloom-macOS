#include "Processor.h"
#include "LiveEngine.h"

void BloomProcessor::processBlock (juce::AudioBuffer<float>& audio, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    bool transportKnown=false, transportRunning=false;
    if (auto* head = getPlayHead())
        if (auto pos = head->getPosition())
        {
            transportKnown=true; transportRunning=pos->getIsPlaying();
            if (auto tempo = pos->getBpm()) if (*tempo > 0.0) bpm.store (*tempo);
            if (auto sig = pos->getTimeSignature())
            { numerator.store (sig->numerator); denominator.store (sig->denominator); }
        }
    float meterL=0.0f, meterR=0.0f;
    if(resetTailPeak.exchange(false)) tailHeldPeak.store(0.0f);
    const int n = audio.getNumSamples(); bufferSize.store(n);
    updateAutomaticCapture(transportKnown,transportRunning);
    float inputPeak=0;
    for(int ch=0;ch<audio.getNumChannels();++ch) inputPeak=juce::jmax(inputPeak,audio.getMagnitude(ch,0,n));
    inputMeter.store(inputPeak);
    captureInput(audio);
    const auto pendingPacket=std::atomic_load(&publishedPacket);
    if(!playing.load() && previewMix.getCurrentValue()==0.0f && pendingPacket!=activePacket)
    {
        activePacket=pendingPacket;
        auditionBase=activePacket ? activePacket->tail : nullptr;
        previewSource=activePacket ? activePacket->source : nullptr;
        sequenceFirst=activePacket ? activePacket->first : 0;
        sequenceCount=activePacket ? activePacket->count : 0;
        fadingBase.reset();
    }
    if (resetPreview.exchange (false))
    {
        playbackPosition = 0; sequencePosition = 0;
        activePacket=pendingPacket;
        auditionBase=activePacket ? activePacket->tail : nullptr;
        previewSource=activePacket ? activePacket->source : nullptr;
        sequenceFirst=activePacket ? activePacket->first : 0;
        sequenceCount=activePacket ? activePacket->count : 0;
        sequenceTogether = parameters.getRawParameterValue("previewmode")->load() > 0.5f;
        sequenceGap = (int)std::round(parameters.getRawParameterValue("endgap")->load()*activeRate.load()/1000.0);
        sequencePause = (int)std::round(parameters.getRawParameterValue("looppause")->load()*activeRate.load()/1000.0);
        if (parameters.getRawParameterValue("lfomode")->load() < 0.5f) oscillatorPhase = 0.0;
        liveFilter[0] = liveFilter[1] = 0.0f;
    }
    auto config = settings();
    depthSmooth.setTargetValue (config.depth);
    rateSmooth.setTargetValue ((float)BloomLive::frequency(config));
    outputSmooth.setTargetValue(juce::Decibels::decibelsToGain(config.outputDb));
    previewMix.setTargetValue(playing.load() ? 1.0f : 0.0f);
    const bool retrigger = parameters.getRawParameterValue("lfomode")->load() < 0.5f;
    phaseSmooth.setTargetValue (config.phase);
    if ((playing.load() || previewMix.getCurrentValue() > 0.0f) && auditionBase && !isCapturing())
    {
        float peak = 0.0f;
        for (int i = 0; i < n; ++i)
        {
            const BloomPreview::Timeline timeline {auditionBase->getNumSamples(),
                sequenceTogether ? sequenceGap : 0, sequenceTogether ? sequenceCount : 0,
                sequenceTogether && loop.load() ? sequencePause : 0};
            if (sequencePosition >= timeline.total())
            {
                if (loop.load() && playing.load())
                {
                    sequencePosition=0;
                    // Source/range/mode edits take effect at the next full loop, not mid-word.
                    if(pendingPacket) activePacket=pendingPacket;
                    auditionBase=activePacket ? activePacket->tail : nullptr;
                    previewSource=activePacket ? activePacket->source : nullptr;
                    sequenceFirst=activePacket ? activePacket->first : 0;
                    sequenceCount=activePacket ? activePacket->count : 0;
                    sequenceTogether=parameters.getRawParameterValue("previewmode")->load()>0.5f;
                    sequenceGap=(int)std::round(parameters.getRawParameterValue("endgap")->load()*config.sampleRate/1000.0);
                    sequencePause=(int)std::round(parameters.getRawParameterValue("looppause")->load()*config.sampleRate/1000.0);
                    if(retrigger) oscillatorPhase=0.0;
                    liveFilter[0]=liveFilter[1]=0.0f;
                }
                else { playing.store(false); previewMix.setTargetValue(0.0f); }
            }
            // Rebuild after a loop boundary, since the next loop may have a different source range.
            const BloomPreview::Timeline current {auditionBase->getNumSamples(),
                sequenceTogether ? sequenceGap : 0,sequenceTogether ? sequenceCount : 0,
                sequenceTogether && loop.load() ? sequencePause : 0};
            const auto frame=current.at(sequencePosition);
            const bool inTail=frame.stage==BloomPreview::tail;
            playbackPosition=inTail ? frame.offset : 0;
            previewStage.store((int)frame.stage);
            previewPosition.store(inTail ? (float)frame.offset/auditionBase->getNumSamples() : 0.0f);
            sourcePreviewPosition.store(frame.stage==BloomPreview::source && previewSource
                ? (float)(sequenceFirst+frame.offset)/previewSource->getNumSamples() : 0.0f);
            config.depth = depthSmooth.getNextValue();
            const double hz = rateSmooth.getNextValue();
            config.phase = phaseSmooth.getNextValue();
            float left=0.0f,right=0.0f;
            if (inTail)
            {
            left = auditionBase->getSample (0,playbackPosition);
            right = auditionBase->getSample (1,playbackPosition);
            BloomLive::processPhase (left,right,oscillatorPhase,config,liveFilter);
            if (fadingBase && fadePosition < fadeLength)
            {
                const int oldPos = playbackPosition % fadingBase->getNumSamples();
                float oldLeft = fadingBase->getSample (0,oldPos), oldRight = fadingBase->getSample (1,oldPos);
                BloomLive::processPhase (oldLeft,oldRight,oscillatorPhase,config,oldFilter);
                const float mix = (float) fadePosition++ / (float) fadeLength;
                left = oldLeft + mix*(left-oldLeft); right = oldRight + mix*(right-oldRight);
            }
            // Short output smoothing on LFO target/shape changes.
            if (config.target != liveSettings.target || config.shape != liveSettings.shape
                || config.sync != liveSettings.sync || config.rateIndex != liveSettings.rateIndex)
            { lfoTransition = 0; liveSettings = config; }
            if (lfoTransition < fadeLength)
            {
                const float mix = (float) ++lfoTransition / (float) fadeLength;
                left = lastOutput[0] + mix*(left-lastOutput[0]);
                right = lastOutput[1] + mix*(right-lastOutput[1]);
            }
            lastOutput[0] = left; lastOutput[1] = right;
            }
            else if(frame.stage==BloomPreview::source && previewSource)
            {
                const float edge=BloomPreview::edgeGain(frame.offset,sequenceCount,(int)(config.sampleRate*0.001));
                left=previewSource->getSample(0,sequenceFirst+frame.offset)*edge;
                right=previewSource->getSample(1,sequenceFirst+frame.offset)*edge;
            }
            oscillatorPhase += hz/config.sampleRate;
            oscillatorPhase -= std::floor(oscillatorPhase);
            const float gain = outputSmooth.getNextValue(), mix = previewMix.getNextValue();
            if(inTail)
            {
                meterL=juce::jmax(meterL,std::abs(left*gain));
                meterR=juce::jmax(meterR,std::abs(right*gain));
            }
            for (int ch = 0; ch < audio.getNumChannels(); ++ch)
            {
                const float sourceFade=frame.stage==BloomPreview::source && config.sourceFadeMs>0
                    ? juce::jlimit(0.0f,1.0f,(float)frame.offset/(float)juce::jmax(1,(int)(config.sampleRate*config.sourceFadeMs/1000.0))) : 1.0f;
                const float wet = (ch == 0 ? left : right)*(inTail ? gain : sourceFade);
                const float value = audio.getSample(ch,i)*(1.0f-mix) + wet*mix;
                audio.setSample(ch,i,value); peak = juce::jmax(peak,std::abs(value));
            }
            ++sequencePosition;
        }
        outputPeak.store(peak);

    }
    else
    {
        if (!retrigger) { oscillatorPhase += n*BloomLive::frequency(config)/config.sampleRate; oscillatorPhase -= std::floor(oscillatorPhase); }
        previewPosition.store(0.0f); sourcePreviewPosition.store(0.0f); previewStage.store(0); outputPeak.store(0.0f);
    }
    previewPending.store(pendingPacket!=activePacket);
    lfoPosition.store((float)oscillatorPhase);
    tailMeterL.store(meterL); tailMeterR.store(meterR);
    tailHeldPeak.store(juce::jmax(tailHeldPeak.load(),juce::jmax(meterL,meterR)));
}

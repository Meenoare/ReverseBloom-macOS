#include "Editor.h"
#include "Theme.h"
using namespace BloomTheme;
void BloomEditor::paint(juce::Graphics& g){g.fillAll(background);}
void BloomEditor::paintCanvas(juce::Graphics& g)
{
 g.setGradientFill(juce::ColourGradient(juce::Colour(0xff3b3a43),0,0,background,900,900,false));g.fillAll();
 // Reusable procedural satin grain, built once; no external graphics asset.
 static const juce::Image grain=[] {
   juce::Image image(juce::Image::ARGB,900,900,true);juce::Random random(0x52424c);
   for(int y=0;y<900;++y)for(int x=0;x<900;++x) {
     const auto colour=random.nextBool()?juce::Colours::white:juce::Colours::black;
     image.setPixelAt(x,y,colour.withAlpha((juce::uint8)(random.nextInt(5)+1)));
   }
   return image;
 }();
 g.drawImageAt(grain,0,0);

 // A recessed divider: highlight sits below the dark line, clear of the display.
 g.setColour(border);g.drawHorizontalLine(80,8,892);g.setColour(text.withAlpha(0.1f));g.drawHorizontalLine(81,8,892);
 g.setColour(text);g.setFont(font(31,true));g.drawText("RB",28,20,90,40,juce::Justification::left);
 g.setColour(muted);g.setFont(font(9));g.drawText("PRESET",246,7,120,11,juce::Justification::left);
 // Display surround with a smooth central relief, not a rectangle hidden by the knob.
 juce::Path surround;surround.startNewSubPath(44,96);surround.lineTo(856,96);
 surround.cubicTo(877,96,884,110,884,128);surround.lineTo(884,357);
 surround.cubicTo(884,380,872,390,850,390);surround.lineTo(573,390);
 surround.cubicTo(548,390,534,362,450,362);surround.cubicTo(366,362,352,390,327,390);
 surround.lineTo(50,390);surround.cubicTo(27,390,16,380,16,357);surround.lineTo(16,128);surround.cubicTo(16,108,24,96,44,96);surround.closeSubPath();
 g.setGradientFill(juce::ColourGradient(raised,0,96,juce::Colour(0xff2b2b32),0,390,false));g.fillPath(surround);
 g.setColour(border);g.strokePath(surround,juce::PathStrokeType(1.4f));
 g.setColour(text.withAlpha(0.12f));g.strokePath(surround,juce::PathStrokeType(0.5f));
 g.setColour(muted);g.setFont(font(12));g.drawText("REVERSE  B L O O M",46,112,300,20,juce::Justification::left);
 for(int side=0;side<2;++side)for(int row=0;row<2;++row)for(int col=0;col<3;++col){
  const float x=(side?820.0f:30.0f)+col*12,y=410+row*13.0f;
  g.setColour(juce::Colours::black.withAlpha(0.5f));g.fillEllipse(x,y,6,6);g.setColour(text.withAlpha(0.12f));g.drawEllipse(x,y,6,6,0.6f);
 }
 if(openPanel){
  juce::Path panel;panel.startNewSubPath(57,682);panel.lineTo(427,682);
  panel.cubicTo(429,701,439,706,450,706);panel.cubicTo(461,706,471,701,473,682);
  panel.lineTo(843,682);panel.cubicTo(855,682,862,690,862,702);panel.lineTo(862,818);panel.cubicTo(862,831,853,836,841,836);
  panel.lineTo(59,836);panel.cubicTo(46,836,38,829,38,817);panel.lineTo(38,702);panel.cubicTo(38,690,45,682,57,682);panel.closeSubPath();
  g.setGradientFill(juce::ColourGradient(surface,0,682,background,0,836,false));g.fillPath(panel);g.setColour(border);g.strokePath(panel,juce::PathStrokeType(1.4f));
  g.setColour(text.withAlpha(0.12f));g.strokePath(panel,juce::PathStrokeType(0.5f));
 }
 auto modes=juce::Rectangle<float>(776,350,88,30);
 g.setGradientFill(juce::ColourGradient(surface,776,350,raised,864,380,false));g.fillRoundedRectangle(modes,15);
 g.setColour(border);g.drawRoundedRectangle(modes,15,1.2f);
 g.setColour(text.withAlpha(0.12f));g.drawRoundedRectangle(modes.reduced(1),14,0.6f);
 g.setColour(border.withAlpha(0.6f));g.drawVerticalLine(820,353,377);
 // One capsule shared by all tabs: the selected inset glides between thirds.
 auto tabRail=juce::Rectangle<float>(267,848,366,37);
 g.setColour(juce::Colours::black.withAlpha(0.38f));g.fillRoundedRectangle(tabRail.translated(0,2),19);
 g.setGradientFill(juce::ColourGradient(juce::Colour(0xff18181d),tabRail.getX(),tabRail.getY(),raised,tabRail.getRight(),tabRail.getBottom(),false));g.fillRoundedRectangle(tabRail,19);
 g.setColour(border.withAlpha(0.9f));g.drawRoundedRectangle(tabRail,19,1.25f);
 auto segment=juce::Rectangle<float>(271.0f+tabTransition*118.0f,851,114,31);
 g.setColour(juce::Colours::black.withAlpha(0.55f));g.fillRoundedRectangle(segment.translated(0,1.5f),15);
 g.setGradientFill(juce::ColourGradient(raised.brighter(0.13f),segment.getX(),segment.getY(),surface,segment.getRight(),segment.getBottom(),false));g.fillRoundedRectangle(segment,15);
 juce::ColourGradient tabGlow(violet,segment.getX(),segment.getY(),juce::Colour(0xffba83f1),segment.getRight(),segment.getBottom(),false);
 g.setGradientFill(tabGlow);g.drawRoundedRectangle(segment.reduced(0.6f),15,1.5f);
 BloomTheme::glow(g,segment,15,violet.withAlpha(0.6f));
}
void BloomEditor::resized()
{
 capture.setVisible(false);stop.setVisible(false);selection.setVisible(false);drag.setVisible(false);exportButton.setVisible(false);
 undoButton.setVisible(false);redoButton.setVisible(false);scaleChoice.setVisible(false);status.setVisible(false);rangeInfo.setVisible(false);
 trimButton.setVisible(false);fitButton.setVisible(false);resetViewButton.setVisible(false);
 presetChoice.setBounds(240,19,264,43);previousPreset.setBounds(504,19,48,43);nextPreset.setBounds(552,19,48,43);
 abButton.setBounds(615,19,78,43);settingsButton.setBounds(802,19,70,43);
 sourceWave.setBounds(30,134,840,214);waveform.setBounds(sourceWave.getBounds());sourceWave.setVisible(showRaw);waveform.setVisible(!showRaw);
 resetWaveButton.setBounds(792,109,68,24);
 listen.setBounds(51,350,82,29);loop.setBounds(139,350,90,29);
 rawButton.setBounds(778,351,42,28);editButton.setBounds(820,351,42,28);
 rawButton.setToggleState(showRaw,juce::dontSendNotification);editButton.setToggleState(!showRaw,juce::dontSendNotification);
 for(size_t i=0;i<knobs.size();++i){const bool v=i==8||(openPanel==1&&i<5)||(openPanel==2&&i>=5&&i<=7)||(openPanel==3&&i==9);knobs[i]->setVisible(v);knobLabels[i]->setVisible(v);}
 knobs[8]->setBounds(275,354,350,390);knobLabels[8]->setVisible(false);
 for(int i=0;i<5;++i){knobLabels[(size_t)i]->setBounds(48+i*105,689,100,23);knobs[(size_t)i]->setBounds(48+i*105,714,100,112);}
 for(size_t i=0;i<tailDetails.size();++i){tailDetails[i]->setVisible(openPanel==1);tailDetailLabels[i]->setVisible(openPanel==1);tailDetailLabels[i]->setBounds(578,689+(int)i*35,110,30);tailDetails[i]->setBounds(692,689+(int)i*35,158,30);}
 for(int i=5;i<=7;++i){knobLabels[(size_t)i]->setBounds(48+(i-5)*110,689,104,23);knobs[(size_t)i]->setBounds(48+(i-5)*110,714,104,112);}
 knobs[9]->setBounds(48,714,100,112);knobLabels[9]->setBounds(48,689,100,23);
 for(int i=0;i<4;++i){bool v=i==0?openPanel==3:openPanel==2;choices[(size_t)i]->setVisible(v);choiceLabels[(size_t)i]->setVisible(v);int x=396+(i-1)*150;choices[(size_t)i]->setBounds(x,741,140,28);choiceLabels[(size_t)i]->setBounds(x,718,140,20);}
 sync.setVisible(openPanel==2);sync.setBounds(396,793,200,26);
 for(juce::Component* c:std::initializer_list<juce::Component*>{&autoGain,&gainLockButton,&tailMeter,&gapLabel,&gapSlider,&pauseLabel,&pauseSlider})c->setVisible(openPanel==3);
 autoGain.setBounds(157,736,110,26);gainLockButton.setBounds(157,773,110,26);tailMeter.setBounds(280,735,282,88);
 if(openPanel==3){choiceLabels[0]->setBounds(576,712,90,24);choices[0]->setBounds(668,712,180,26);}
 gapLabel.setBounds(576,753,90,24);gapSlider.setBounds(668,753,180,24);pauseLabel.setBounds(576,797,90,24);pauseSlider.setBounds(668,797,180,24);
 outputPanelButton.setBounds(271,848,118,37);tailPanelButton.setBounds(389,848,118,37);lfoPanelButton.setBounds(507,848,118,37);
 tailPanelButton.setToggleState(openPanel==1,juce::dontSendNotification);lfoPanelButton.setToggleState(openPanel==2,juce::dontSendNotification);outputPanelButton.setToggleState(openPanel==3,juce::dontSendNotification);
 for(auto& c:tailDetails)c->setVisible(openPanel==1);
}

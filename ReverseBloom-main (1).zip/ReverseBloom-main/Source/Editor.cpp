#include "Editor.h"
#include "Theme.h"
#include <cmath>
namespace { const auto bg=BloomTheme::background, panel=BloomTheme::surface, accent=BloomTheme::violet, mint=BloomTheme::amber; }
BloomLook::BloomLook()
{
    setColour(juce::PopupMenu::backgroundColourId,juce::Colour(0xff25252d));
    setColour(juce::PopupMenu::textColourId,BloomTheme::text);
    setColour(juce::PopupMenu::highlightedBackgroundColourId,juce::Colour(0xff51405f));
    setColour(juce::PopupMenu::highlightedTextColourId,juce::Colours::white);
    setColour(juce::PopupMenu::headerTextColourId,BloomTheme::muted);

    setColour (juce::TextButton::buttonColourId, BloomTheme::raised);
    setColour (juce::TextButton::textColourOffId, BloomTheme::text);
    setColour (juce::ComboBox::backgroundColourId, BloomTheme::surface);
    setColour (juce::ComboBox::outlineColourId, BloomTheme::border);
    setColour (juce::Slider::thumbColourId, BloomTheme::violet);
    setColour (juce::Slider::trackColourId, BloomTheme::amber);
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    setColour (juce::Slider::textBoxTextColourId, BloomTheme::text);
    setColour (juce::Label::textColourId, BloomTheme::muted);
    setColour (juce::ToggleButton::textColourId, BloomTheme::text);
    setColour (juce::ToggleButton::tickColourId, BloomTheme::violet);
}
void BloomEditor::WaveView::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    const auto frame=r.reduced(7);
    juce::Path bezel;bezel.addRoundedRectangle(frame,13);
    // Every layer strokes the exact same path; no mismatched corner radius.
    for(int i=6;i>=1;--i){g.setColour(BloomTheme::amber.withAlpha(0.035f));g.strokePath(bezel,juce::PathStrokeType((float)i*1.5f));}
    g.setGradientFill(juce::ColourGradient(panel.brighter(0.04f),0,0,panel,0,(float)getHeight(),false));g.fillPath(bezel);
    g.setColour(juce::Colour(0xff79cddd));g.strokePath(bezel,juce::PathStrokeType(1.65f));
    g.setColour(BloomTheme::muted.withAlpha(0.1f));g.drawHorizontalLine(getHeight()/2,14.0f,(float)getWidth()-14);
    const bool recording=processor.isRecordingCapture();
    if(recording) {
        const double now=juce::Time::getMillisecondCounterHiRes();
        if(!wasRecording) {liveBins.fill(0);liveEnvelope=0;lastLiveUpdate=0;}
        if(now-lastLiveUpdate>=25) {
            const float level=juce::jlimit(0.0f,1.0f,std::sqrt(processor.inputMeter.load()));
            liveEnvelope=level>liveEnvelope?level:liveEnvelope*0.84f;
            std::move(liveBins.begin()+1,liveBins.end(),liveBins.begin());liveBins.back()=liveEnvelope;lastLiveUpdate=now;
        }
        wasRecording=true;
        const float pulse=0.90f+0.10f*(float)std::sin(now*0.006283);
        const float dx=(getWidth()-32.0f)/liveBins.size();
        for(size_t i=0;i<liveBins.size();++i) {
            const float h=juce::jmax(1.0f,liveBins[i]*pulse*getHeight()*0.40f),x=16+i*dx;
            const auto c=BloomTheme::amber.interpolatedWith(BloomTheme::violet,(float)i/liveBins.size()*0.35f);
            for(int glow=3;glow>0;--glow) {g.setColour(c.withAlpha(0.025f));g.fillRoundedRectangle(x-glow*2,getHeight()*0.5f-h-glow*2,2+glow*4,2*h+glow*4,2);}
            g.setColour(c);g.fillRoundedRectangle(x,getHeight()*0.5f-h,2.7f,2*h,1.35f);
        }
        g.setFont(BloomTheme::font(12,true));g.setColour(BloomTheme::amber);g.drawText("REC  /  LIVE INPUT",18,8,240,20,juce::Justification::left);
        return;
    }
    wasRecording=false;
    auto audio = isSource ? processor.getSource() : processor.getResult();
    if(!isSource && !processor.isResultCurrent()) audio=processor.getSource();
    if (!audio) {
        // Decorative waiting state only: never replace held source/result with a simulation.
        if(!processor.getSource() && !processor.getResult()) {
            const double t=juce::Time::getMillisecondCounterHiRes()*0.001;
            constexpr int bars=132;
            const float usable=juce::jmax(1.0f,(float)getWidth()-48.0f);
            for(int i=0;i<bars;++i) {
                const double u=(double)i/(bars-1);
                const double edge=std::pow(std::sin(juce::MathConstants<double>::pi*u),1.2);
                // Incommensurate rates and travelling lobes avoid a metronomic pulse.
                const double breathe=0.57+0.18*std::sin(t*0.73)+0.12*std::sin(t*1.137+1.8);
                const double flow=0.50+0.24*std::sin(u*17.0-t*0.91+0.8*std::sin(t*0.27))
                                     +0.16*std::sin(u*31.0+t*0.57+2.0);
                const float h=(float)(1.0+edge*(0.06+breathe*flow)*getHeight()*0.43);
                const float x=24.0f+(float)u*usable;
                const auto colour=BloomTheme::violet.interpolatedWith(juce::Colour(0xffff9b66),(float)u);
                g.setColour(colour.withAlpha(0.055f));
                g.fillRoundedRectangle(x-2,getHeight()*0.5f-h-3,6,2*h+6,3);
                g.setColour(colour.withAlpha(0.90f));
                g.fillRoundedRectangle(x,getHeight()*0.5f-h,2.7f,2*h,1.35f);
            }
            g.setColour(BloomTheme::muted);g.setFont(BloomTheme::font(11));
            g.drawText("WAITING FOR AUDIO",18,getHeight()-34,getWidth()-36,16,juce::Justification::centred);
        }
        return;
    }
    const int width = juce::jmax (1,getWidth()-24);
    g.setColour (isSource ? mint : accent);
    updatePeaks(audio);
    for(int x=0;x<width;x+=5)
    {
        float peak=0;
        if(peakSource==audio && (int)peakBins.size()==width)
            for(int j=x;j<juce::jmin(x+5,width);++j) peak=juce::jmax(peak,peakBins[(size_t)j]);
        const float height=juce::jlimit(0.0f,1.0f,peak)*(getHeight()*0.40f);
        const auto colour=BloomTheme::violet.interpolatedWith(juce::Colour(0xffff9b66),(float)x/width);
        g.setColour(colour.withAlpha(0.10f));
        g.fillRoundedRectangle((float)x+10,getHeight()*0.5f-height-3,7,juce::jmax(2.0f,2*height+6),3);
        g.setColour(colour.withAlpha(0.92f));
        g.fillRoundedRectangle((float)x+12,getHeight()*0.5f-height,2.9f,juce::jmax(1.5f,2*height),1.2f);
    }
    g.setColour (mint.withAlpha (0.7f));
    if (isSource)
    {
        const float x1=12+(processor.getSelectionBegin()-viewStart)/viewSpan*width;
        const float x2=12+(processor.getSelectionEnd()-viewStart)/viewSpan*width;
        g.setColour(mint.withAlpha(0.15f)); g.fillRect(juce::Rectangle<float>(x1,28,x2-x1,(float)getHeight()-30).getIntersection(getLocalBounds().toFloat()));
        g.setColour(mint); g.drawVerticalLine((int)x1,28.0f,(float)getHeight()); g.drawVerticalLine((int)x2,28.0f,(float)getHeight());
        if(processor.playing.load() && processor.previewStage.load()==BloomPreview::source)
        { g.setColour(juce::Colours::white); g.drawVerticalLine((int)(12+(processor.sourcePreviewPosition.load()-viewStart)/viewSpan*width),26.0f,(float)getHeight()-5); }
    }
    else if (processor.playing.load() && processor.previewStage.load()==BloomPreview::tail)
    {
        g.setColour(juce::Colours::white); g.drawVerticalLine(12+(int)(processor.previewPosition.load()*width),26.0f,(float)getHeight()-8);
    }
}
float BloomEditor::WaveView::fraction(float x) const
{ return juce::jlimit(0.0f,1.0f,viewStart+viewSpan*(x-12.0f)/juce::jmax(1,getWidth()-24)); }
void BloomEditor::WaveView::mouseDown(const juce::MouseEvent& e)
{ dragOrigin=e.getPosition();waveDragStarted=false;if(isSource && !processor.isCapturing()) anchor=fraction(e.position.x); }
void BloomEditor::WaveView::mouseDrag(const juce::MouseEvent& e)
{
    if(!isSource) {
        if(!waveDragStarted && !processor.isCapturing() && e.getPosition().getDistanceFrom(dragOrigin)>6) {
            const auto file=processor.getExportFile();
            if(file.existsAsFile()){waveDragStarted=true;juce::DragAndDropContainer::performExternalDragDropOfFiles({file.getFullPathName()},false,this);}
        }
        return;
    }
    if(processor.isCapturing()) return;
    const float end=fraction(e.position.x);
    processor.setSelection(juce::jmin(anchor,end),juce::jmax(anchor,end)); repaint();
}
void BloomEditor::WaveView::mouseDoubleClick(const juce::MouseEvent&)
{ if(isSource) { viewStart=0.0f; viewSpan=1.0f; processor.setSelection(0.0f,1.0f); repaint(); } }
void BloomEditor::WaveView::mouseWheelMove(const juce::MouseEvent& e,const juce::MouseWheelDetails& w)
{
    if(!isSource) return;
    if(e.mods.isShiftDown()) viewStart=juce::jlimit(0.0f,1.0f-viewSpan,viewStart-w.deltaY*viewSpan);
    else
    {
        const float at=fraction(e.position.x), relative=juce::jlimit(0.0f,1.0f,(e.position.x-12.0f)/juce::jmax(1,getWidth()-24));
        viewSpan=juce::jlimit(0.01f,1.0f,viewSpan*std::exp(-w.deltaY*2.0f));
        viewStart=juce::jlimit(0.0f,1.0f-viewSpan,at-relative*viewSpan);
    }
    repaint();
}
void BloomEditor::DragButton::mouseDrag (const juce::MouseEvent& e)
{
    juce::TextButton::mouseDrag (e);
    if (!dragged && e.getPosition().getDistanceFrom (origin)>5)
    {
        const auto file = processor.getExportFile();
        if (file.existsAsFile())
        {
            dragged = true;
            juce::DragAndDropContainer::performExternalDragDropOfFiles ({file.getFullPathName()},false,this);
        }
    }
}
BloomEditor::BloomEditor (BloomProcessor& p)
    : AudioProcessorEditor (p), processor (p), tailMeter(p), waveform (p), sourceWave(p,true), drag (p)
{
    setLookAndFeel (&look);
    addAndMakeVisible(canvas);
    canvas.draw = [this](juce::Graphics& g) { paintCanvas(g); };
    canvas.setBounds(0,0,900,900);
    scaleChoice.addItemList({"50%","75%","100%"},1);
    canvas.addAndMakeVisible(scaleChoice);
    scaleChoice.onChange=[this] { processor.uiScale.store(scaleChoice.getSelectedId()-1); applyScale(); };
    for (juce::Component* c : std::initializer_list<juce::Component*>
         { &tailMeter,&gapSlider,&pauseSlider,&gapLabel,&pauseLabel,&sourceWave,&autoGain,&waveform,&capture,&stop,&listen,&drag,&exportButton,&loop,&sync,&status,&selection })
        canvas.addAndMakeVisible (c);
    capture.onClick = [this] { processor.startCapture(); };
    stop.onClick = [this] { processor.stopCapture(); };
    listen.onClick = [this] { processor.togglePreview(); };
    loop.setToggleState (processor.loop.load(),juce::dontSendNotification);
    loop.onClick = [this] { processor.loop.store (loop.getToggleState()); };
    selection.setSliderStyle (juce::Slider::TwoValueHorizontal);
    selection.setTextBoxStyle (juce::Slider::NoTextBox,false,0,0);
    selection.setRange (0.0,1.0,0.001);
    selection.setMinAndMaxValues (processor.getSelectionBegin(),processor.getSelectionEnd(),juce::dontSendNotification);
    selection.onValueChange = [this]
    { processor.setSelection ((float)selection.getMinValue(),(float)selection.getMaxValue()); };
    addKnob ("size","Room"); addKnob ("decay","Decay");
    addKnob ("tone","Tone"); addKnob ("swell","Rise");
    addKnob ("source","Source Blend"); addKnob ("depth","Depth");
    addKnob ("rate","Rate"); addKnob ("phase","Phase");
    addKnob("length","Reverse Length");
    knobs.back()->textFromValueFunction = [](double v) { return juce::StringArray{"1/4 BAR","1/2 BAR","1 BAR","2 BARS","4 BARS"}[juce::jlimit(0,4,(int)std::round(v))]; };
    knobs.back()->valueFromTextFunction = [](const juce::String& text) { if(text.contains("1/4")) return 0.0; if(text.contains("1/2")) return 1.0; if(text.startsWith("2")) return 3.0; if(text.startsWith("4")) return 4.0; return 2.0; };
    knobs.back()->updateText();
    addKnob("output","Level");
    addChoice("previewmode","PREVIEW",{"Tail Only","Tail -> Source"});
    addChoice("lfomode","Mode",{"Retrigger","Free Run"});
    addChoice ("target","Target",{"Volume","Filter","Pan"});
    addChoice ("shape","Shape",{"Sine","Triangle","Saw","Soft square"});
    // division remains a host parameter, now driven by Rate in synced mode.
    syncAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (processor.parameters,"sync",sync);
    gainAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(processor.parameters,"autogain",autoGain);
    exportButton.onClick = [this]
    {
        if(processor.exportStatus.load()==-1) { processor.retryExport(); return; }
        const auto file = processor.getExportFile();
        if (!file.existsAsFile()) return;
        chooser = std::make_unique<juce::FileChooser> ("Export ReverseBloom WAV",
            juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("ReverseBloom.wav"),"*.wav");
        juce::Component::SafePointer<BloomEditor> safe (this);
        chooser->launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles
                            | juce::FileBrowserComponent::warnAboutOverwriting,
            [safe,file] (const juce::FileChooser& fc)
            {
                if (!safe) return;
                auto dest = fc.getResult();
                if (dest == juce::File()) return;
                dest = dest.withFileExtension ("wav");
                safe->processor.saveExportTo(dest);
            });
    };
    gapSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    pauseSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    for(auto* slider : {&gapSlider,&pauseSlider}) slider->setTextBoxStyle(juce::Slider::TextBoxRight,false,68,22);
    gapAttachment=std::make_unique<SliderAttachment>(processor.parameters,"endgap",gapSlider);
    pauseAttachment=std::make_unique<SliderAttachment>(processor.parameters,"looppause",pauseSlider);
    gapSlider.setNumDecimalPlacesToDisplay(0); pauseSlider.setNumDecimalPlacesToDisplay(0);
    gapSlider.setTextValueSuffix(" ms"); pauseSlider.setTextValueSuffix(" ms");
    exportButton.setTooltip("Export follows Settings > Export contents. Joined mode includes selected source and End Gap, never Loop Pause.");
    gapLabel.setText("End Gap",juce::dontSendNotification); pauseLabel.setText("Loop Pause",juce::dontSendNotification);
    gapSlider.setTooltip("Silence between tail and source in joined preview/export; applied on next Listen/loop.");
    pauseSlider.setTooltip("Silence after source before the next full loop. Tail -> Source mode only.");
    listen.setTooltip("Preview replaces live input. Tail -> Source plays the selected capture after the tail. No host transport control.");
    drag.setTooltip("Drag uses the same export contents as Export WAV.");
    const char* tips[] = {
        "Reverb room size; larger values make a more spacious tail.",
        "Tail decay envelope in seconds; not a calibrated reverb RT60.",
        "Brightness of the reverse tail, in Hz.",
        "Rise curve: lower values rise earlier, higher values rise later.",
        "Blend: 0% = reverse reverb, 100% = reversed source.",
        "LFO modulation amount, from 0 to 100%.",
        "LFO speed: musical divisions with Tempo sync, Hz otherwise.",
        "LFO starting phase, in degrees.",
        "Reverse tail duration in musical bars, following host tempo and time signature.",
        "Reverse tail output level in dB; does NOT change source preview volume."};
    const char* ids[]={"size","decay","tone","swell","source","depth","rate","phase","length","output"};
    for(size_t i=0;i<knobs.size();++i)
    {
        knobs[i]->setTooltip(tips[i]);
        auto* parameter=processor.parameters.getParameter(ids[i]);
        knobs[i]->setDoubleClickReturnValue(true,parameter->convertFrom0to1(parameter->getDefaultValue()));
        knobs[i]->setNumDecimalPlacesToDisplay(i==2 ? 0 : 2);
    }
    for(int i : {4,5})
    {
        knobs[(size_t)i]->textFromValueFunction=[](double v) {return juce::String(v*100.0,0)+" %";};
        knobs[(size_t)i]->valueFromTextFunction=[](const juce::String& t){return t.getDoubleValue()/100.0;};
    }
    knobs[7]->textFromValueFunction=[](double v){return juce::String(v*360.0,0)+" deg";};
    knobs[7]->valueFromTextFunction=[](const juce::String& t){return t.getDoubleValue()/360.0;};
    knobs[1]->setTextValueSuffix(" s"); knobs[2]->setTextValueSuffix(" Hz");
    knobs[6]->setTextValueSuffix(" Hz"); knobs[9]->setTextValueSuffix(" dB");
    for(auto& k:knobs) k->updateText();
    tailMeter.setTooltip("Reverse tail after LFO and Level, before preview fade. Peak hold: click to reset. Source and live input are excluded. Not a limiter or true-peak meter.");
    setupTools(); setupWorkflowUI();
    updateLengthBinding(); updateRateBinding(); applyScale();
    startTimerHz (30);
}
BloomEditor::~BloomEditor() { stopTimer(); setLookAndFeel (nullptr); }
void BloomEditor::addKnob (const char* id,const char* title)
{
    auto slider = std::make_unique<juce::Slider>();
    slider->setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    slider->setTextBoxStyle (juce::Slider::TextBoxBelow,false,86,20);
    slider->setVelocityModeParameters(1.0,1,0.0,true,juce::ModifierKeys::shiftModifier);
    canvas.addAndMakeVisible (*slider);
    auto label = std::make_unique<juce::Label>();
    label->setFont(juce::FontOptions(12.5f));
    label->setText (title,juce::dontSendNotification); label->setJustificationType (juce::Justification::centred);
    canvas.addAndMakeVisible (*label);
    if(juce::String(id)!="rate" && juce::String(id)!="length") sliderAttachments.push_back (std::make_unique<SliderAttachment> (processor.parameters,id,*slider));
    knobs.push_back (std::move(slider)); knobLabels.push_back (std::move(label));
}
void BloomEditor::addChoice (const char* id,const char* title,const juce::StringArray& items)
{
    auto box = std::make_unique<juce::ComboBox>(); box->addItemList (items,1);
    canvas.addAndMakeVisible (*box);
    auto label = std::make_unique<juce::Label>(); label->setText (title,juce::dontSendNotification);
    canvas.addAndMakeVisible (*label);
    comboAttachments.push_back (std::make_unique<ComboAttachment> (processor.parameters,id,*box));
    choices.push_back (std::move(box)); choiceLabels.push_back (std::move(label));
}
void BloomEditor::timerCallback()
{
    bool editing=juce::ModifierKeys::getCurrentModifiersRealtime().isAnyMouseButtonDown();
    for(auto& k:knobs) editing=editing || k->isMouseButtonDown();
    processor.userEditing.store(editing);
    processor.pollHistory();
    // Signature below marks changed presets; clicking navigation is not a sound edit.
    if(presetChoice.getSelectedId()>0) {
        juce::String signature;for(auto* p:processor.getParameters()) signature<<p->getValue()<<":";
        if(signature!=presetSignature) presetChoice.setSelectedId(0,juce::dontSendNotification);
    }
    undoButton.setEnabled(processor.canUndo()); redoButton.setEnabled(processor.canRedo());
    abButton.setButtonText(processor.isSlotB()?"A / [B]":"[A] / B");
    trimButton.setEnabled(!processor.isCapturing() && !processor.isAnalysisBusy() && processor.getSource()!=nullptr);
    const double selectedMs=1000.0*(processor.getSelectionEnd()-processor.getSelectionBegin())*processor.getCapturedSamples()/processor.getSampleRateForUI();
    const auto result=processor.getResult();
    const double tailMs=result ? 1000.0*result->getNumSamples()/processor.getSampleRateForUI() : 0.0;
    rangeInfo.setText(juce::String(selectedMs,1)+" ms / Tail "+juce::String(tailMs,0)+" ms",juce::dontSendNotification);
    rangeInfo.setTooltip(processor.previewPending.load()?"New tail/source pair will be used on the next full loop or Listen restart.":"Selected source duration / last rendered tail duration. PULSING dot means updating or pending adoption.");
    clearCacheButton.setEnabled(processor.cacheStatus.load()!=1);
    const bool busy = processor.isBusy(), recording = processor.isCapturing();
    const bool together=processor.parameters.getRawParameterValue("previewmode")->load()>0.5f;
    gapSlider.setEnabled(together || processor.parameters.getRawParameterValue("exportmode")->load()>0.5f); pauseSlider.setEnabled(together);
    status.setText(juce::String(processor.bpm.load(),1)+" BPM",juce::dontSendNotification);
    // Keep diagnostics in tooltips, without adding permanent status text.
    juce::String diagnostic;
    if(processor.isSignalArmed()) diagnostic="Waiting for input signal";
    else if(recording) diagnostic="Recording until host Stop";
    else if(busy) diagnostic="Updating tail";
    else if(processor.renderStatus.load()==-1) diagnostic="Render failed. Check selected source.";
    if(processor.outputPeak.load()>1.0f) diagnostic+=" Output exceeds 0 dBFS; reduce Level.";
    status.setTooltip(diagnostic);
    capture.setEnabled (!busy && !recording);
    stop.setEnabled (recording);
    capture.setButtonText(processor.isSignalArmed()?"ARMED":"CAPTURE");
    listen.setButtonText (processor.playing.load() ? "STOP" : "LISTEN");
    listen.setEnabled (!recording && processor.getResult()!=nullptr);
    const bool ready = processor.isResultCurrent() && processor.exportStatus.load()==2;
    if(processor.exportStatus.load()==-1 && lastExportStatus!=-1)
        juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,"Export failed","Cannot write WAV. Check disk space and destination permissions.");
    lastExportStatus=processor.exportStatus.load();
    canvas.repaint();
    settingsButton.repaint();tailPanelButton.repaint();lfoPanelButton.repaint();outputPanelButton.repaint();
    const float desired=outputPanelButton.getToggleState()?0.0f:tailPanelButton.getToggleState()?1.0f:lfoPanelButton.getToggleState()?2.0f:tabTransition;
    tabTransition+=(desired-tabTransition)*0.24f;
    if(knobs.size()>8)knobs[8]->repaint();
    drag.setEnabled (ready); exportButton.setEnabled (ready || (processor.isResultCurrent() && processor.exportStatus.load()==-1));
    exportButton.setButtonText(processor.exportStatus.load()==-1 ? "RETRY EXPORT":"EXPORT WAV");
    updateLengthBinding(); updateRateBinding();
    if(appliedScale!=processor.uiScale.load()) applyScale();
    if (!selection.isMouseButtonDown())
        selection.setMinAndMaxValues(processor.getSelectionBegin(),processor.getSelectionEnd(),juce::dontSendNotification);
    loop.setToggleState(processor.loop.load(),juce::dontSendNotification);
    tailMeter.refresh();
    sourceWave.repaint(); waveform.repaint();
}

#include "Editor.h"
void BloomEditor::setupWorkflowUI()
{
    for(auto* b:{&rawButton,&editButton,&tailPanelButton,&lfoPanelButton,&outputPanelButton}) canvas.addAndMakeVisible(*b);
    rawButton.onClick=[this]{showRaw=true;resized();canvas.repaint();};
    editButton.onClick=[this]{showRaw=false;resized();canvas.repaint();};
    tailPanelButton.onClick=[this]{openPanel=openPanel==1?0:1;resized();canvas.repaint();};
    lfoPanelButton.onClick=[this]{openPanel=openPanel==2?0:2;resized();canvas.repaint();};
    outputPanelButton.onClick=[this]{openPanel=openPanel==3?0:3;resized();canvas.repaint();};
    canvas.addAndMakeVisible(previousPreset);canvas.addAndMakeVisible(nextPreset);
    previousPreset.setTooltip("Previous factory preset");nextPreset.setTooltip("Next factory preset");
    previousPreset.onClick=[this]{const int n=processor.factoryPresetNames().size();presetChoice.setSelectedId((presetChoice.getSelectedId()+n-2)%n+1,juce::sendNotificationSync);};
    nextPreset.onClick=[this]{const int n=processor.factoryPresetNames().size();presetChoice.setSelectedId(presetChoice.getSelectedId()%n+1,juce::sendNotificationSync);};
    rawButton.setName("source-mode");tailPanelButton.setName("tail-module");
    rawButton.setTooltip("Captured source: select, zoom and trim. Does not change Listen mode.");
    editButton.setTooltip("Rendered effect waveform. Display only; export contents are selected in Settings.");
    exportButton.setName("export-action"); knobs[8]->setName("reverse-hero");
    for(auto* b:{&rawButton,&editButton,&tailPanelButton,&lfoPanelButton,&outputPanelButton}) b->setWantsKeyboardFocus(true);
    canvas.addAndMakeVisible(resetWaveButton);
    resetWaveButton.onClick=[this]{sourceWave.resetView();};
    resetWaveButton.setTooltip("Reset waveform zoom");
    tailPanelButton.setButtonText("CHORUS");lfoPanelButton.setButtonText("TREMOLO");outputPanelButton.setButtonText("TEXTURE");
    tailPanelButton.setTooltip("Tail and reverb controls");
    lfoPanelButton.setTooltip("All LFO settings: rate, sync, depth, phase, target, shape and retrigger");
    outputPanelButton.setTooltip("Output and preview settings");
    settingsButton.setButtonText("MENU");abButton.setButtonText("[A]...");
    settingsButton.setName("neon-menu");
    for(auto* b:{&rawButton,&editButton,&listen,&resetWaveButton,&tailPanelButton,&lfoPanelButton,&outputPanelButton}) b->setName("reference-flat");
    for(auto* b:{&tailPanelButton,&lfoPanelButton,&outputPanelButton})b->setName("reference-tab");
    outputPanelButton.setComponentID("tab-0");tailPanelButton.setComponentID("tab-1");lfoPanelButton.setComponentID("tab-2");
    previousPreset.setName("preset-arrow");nextPreset.setName("preset-arrow");abButton.setName("ab-slot");
    for(auto& label:knobLabels)label->setFont(juce::FontOptions(14));
    for(size_t i=0;i<5;++i)knobs[i]->setTextBoxStyle(juce::Slider::TextBoxBelow,false,96,26);
    const juce::StringArray ids {"lowcut","highcut","tailfade","sourcefade"};
    const juce::StringArray labels {"Low Cut Hz","High Cut Hz","Tail Fade ms","Source Fade ms"};
    for(int i=0;i<ids.size();++i) {
        auto slider=std::make_unique<juce::Slider>();slider->setSliderStyle(juce::Slider::LinearHorizontal);
        slider->setTextBoxStyle(juce::Slider::TextBoxRight,false,62,28);
        auto label=std::make_unique<juce::Label>();label->setText(labels[i],juce::dontSendNotification);label->setFont(juce::FontOptions(12.5f));
        canvas.addChildComponent(*slider);canvas.addChildComponent(*label);
        tailDetailAttachments.push_back(std::make_unique<SliderAttachment>(processor.parameters,ids[i],*slider));
        tailDetails.push_back(std::move(slider));tailDetailLabels.push_back(std::move(label));
    }
    capture.setVisible(false);stop.setVisible(false);
    knobs[8]->setTextBoxStyle(juce::Slider::TextBoxBelow,false,210,26);
    knobs[8]->setTooltip("Reverse length in bars or milliseconds. Double-click resets; drag for length.");
    knobLabels[8]->setText("REVERSE LENGTH",juce::dontSendNotification);
}

#include "Processor.h"
#if RB_WEB_UI
#include "WebEditor.h"
#endif
#include "Editor.h"
#include "LiveEngine.h"
#include "StateCodec.h"

juce::AudioProcessorValueTreeState::ParameterLayout BloomProcessor::layout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout l;
    auto f = [&l] (const char* id, const char* name, float lo, float hi, float def)
    { l.add (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID {id,1}, name, lo, hi, def)); };
    auto c = [&l] (const char* id, const char* name, juce::StringArray options, int def)
    { l.add (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID {id,1}, name, options, def)); };
    c ("length", "Length (bars)", {"1/4", "1/2", "1", "2", "4"}, 2);
    f ("size", "Room size", 0.1f, 0.98f, 0.8f);
    f ("decay", "Tail decay (s)", 0.2f, 12.0f, 4.0f);
    f ("tone", "Tone (Hz)", 300.0f, 18000.0f, 9000.0f);
    f ("swell", "Swell curve", 0.25f, 5.0f, 1.5f);
    f ("source", "Reverse source", 0.0f, 1.0f, 0.0f);
    f ("depth", "LFO depth", 0.0f, 1.0f, 0.5f);
    f ("rate", "LFO rate (Hz)", 0.05f, 20.0f, 2.0f);
    f ("phase", "LFO phase", 0.0f, 1.0f, 0.0f);
    c ("target", "LFO target", {"Volume", "Filter", "Pan"}, 0);
    c ("shape", "LFO shape", {"Sine", "Triangle", "Saw", "Soft square"}, 0);
    c ("division", "LFO division", {"1/1", "1/2", "1/4", "1/8", "1/16", "1/32"}, 3);
    l.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID {"sync",1}, "Tempo sync", true));
    f ("output", "Output (dB)", -36.0f, 12.0f, 0.0f);
    l.add (std::make_unique<juce::AudioParameterBool> (juce::ParameterID {"autogain",1}, "Auto gain", true));
    l.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"gainlock",1},"Gain Lock",false));
    c ("lfomode", "LFO mode", {"Retrigger", "Free Run"}, 0);
    c ("previewmode", "Preview mode", {"Tail Only", "Tail -> Source"}, 0);
    f ("endgap", "End gap (ms)", 0.0f, 200.0f, 0.0f);
    f ("looppause", "Loop pause (ms)", 0.0f, 1000.0f, 250.0f);
    c("lengthmode","Length mode",{"Bars","Milliseconds"},0);
    f("lengthms","Length (ms)",100.0f,60000.0f,2000.0f);
    f("lowcut","Tail Low Cut (Hz)",20.0f,2000.0f,20.0f);
    f("highcut","Tail High Cut (Hz)",1000.0f,20000.0f,20000.0f);
    f("tailfade","Tail End Fade (ms)",0.0f,200.0f,3.0f);
    f("sourcefade","Source Fade In (ms)",0.0f,200.0f,3.0f);
    c("exportmode","Export contents",{"Tail Only","Tail -> Source"},0);
    l.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"signalcap",1},"Capture by signal",false));
    l.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"autoselect",1},"Auto selection",true));
    f("threshold","Capture threshold (dBFS)",-72.0f,-6.0f,-36.0f);
    f("holdms","Capture silence stop (ms)",100.0f,3000.0f,600.0f);
    f("preroll","Capture pre-roll (ms)",0.0f,200.0f,50.0f);
    l.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"autocapture",1},"Automatic transport capture",true));
    f("predelay","Pre-delay (ms)",0.0f,250.0f,0.0f);
    c("reverbtype","Reverb character",{"Room","Hall","Plate"},0);
    c("curvemode","Rise envelope",{"Rise","Custom"},0);
    f("curve1","Envelope 25%",0.0f,1.0f,0.125f);
    f("curve2","Envelope 50%",0.0f,1.0f,0.35355339f);
    f("curve3","Envelope 75%",0.0f,1.0f,0.64951905f);
    return l;
}
BloomProcessor::BloomProcessor()
    : AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                      .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      parameters (*this, nullptr, "ReverseBloomState", layout()) {
          cacheLease=std::make_unique<juce::InterProcessLock>("ReverseBloomCache_"+cacheInstanceID);
          cacheLease->enter(0); loadWorkflowDefaults(); startTimerHz (20);
      }
BloomProcessor::~BloomProcessor()
{
    stopTimer();
    cancel.store (true);
    if (worker.joinable()) worker.join();
    exportEpoch.fetch_add(1);
    if(exportWorker.joinable()) exportWorker.join();
    if(analysisWorker.joinable()) analysisWorker.join();
    if(cacheLease) cacheLease->exit();
}
bool BloomProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    const auto out = l.getMainOutputChannelSet();
    return (out == juce::AudioChannelSet::mono() || out == juce::AudioChannelSet::stereo())
        && out == l.getMainInputChannelSet();
}
void BloomProcessor::prepareToPlay (double sr, int expectedBlockSize)
{
    const juce::ScopedLock control (controlLock);
    exportEpoch.fetch_add(1);
    if(exportWorker.joinable()) exportWorker.join();
    exportBusy.store(false); exportStatus.store(0); exportAttemptKey.clear();
    cancel.store (true);
    if(analysisWorker.joinable()) { analysisWorker.join(); }
    analysisBusy.store(false); trimReady.store(false);
    if (worker.joinable()) worker.join();
    busy.store (false); cancel.store (false);
    if (captureState.load() == 3) publishSource();
    const auto retained = getSource();
    activeRate.store (sr); bufferSize.store(expectedBlockSize);
    auditionBase.reset(); fadingBase.reset(); cachedBase.reset(); activePacket.reset();
    std::atomic_store(&publishedPacket,std::shared_ptr<PreviewPacket>{});
    std::atomic_store (&baseResult, std::shared_ptr<juce::AudioBuffer<float>> {});
    requestedKey.clear(); requestedBaseKey.clear(); cachedBaseKey.clear();
    fadeLength = juce::jmax (1, (int) (sr * 0.02)); fadePosition = fadeLength;
    liveFilter[0] = liveFilter[1] = oldFilter[0] = oldFilter[1] = 0.0f;
    depthSmooth.reset (sr, 0.015); rateSmooth.reset (sr, 0.015); phaseSmooth.reset (sr, 0.015);
    const auto initial = settings();
    depthSmooth.setCurrentAndTargetValue (initial.depth);
    rateSmooth.setCurrentAndTargetValue ((float)BloomLive::frequency(initial));
    phaseSmooth.setCurrentAndTargetValue (initial.phase);
    capturedAudio.setSize (2, (int) (sr * 30.0));
    preRollBuffer.setSize(2,juce::jmax(1,(int)(sr*0.2))); preRollBuffer.clear();
    transportSession=false; autoHostWasPlaying=false; autoFallbackUsed=false;
    preRollWrite=preRollCount=quietSamples=0; signalArmed.store(false); signalRecording=false;
    analysedRevision=0;
    capturedAudio.clear(); captured.store (0); captureState.store (0);
    if (retained && retained->getNumSamples() > 0)
    {
        auto converted = BloomState::resample (*retained, sourceRate, sr);
        const int count = juce::jmin (converted->getNumSamples(),capturedAudio.getNumSamples());
        for (int ch=0; ch<2; ++ch) capturedAudio.copyFrom (ch,0,*converted,ch,0,count);
        captured.store(count); captureState.store(3); captureRevision.fetch_add(1);
        sourceRate = sr; snapshotRevision = 0; publishSource();
    }
    previewMix.reset(sr,0.015); previewMix.setCurrentAndTargetValue(0.0f);
    outputSmooth.reset(sr,0.015);
    outputSmooth.setCurrentAndTargetValue(juce::Decibels::decibelsToGain(initial.outputDb));
    oscillatorPhase = 0.0; sequencePosition=0; previewSource.reset();
    tailMeterL.store(0); tailMeterR.store(0); tailHeldPeak.store(0);
    previewStage.store(0); sourcePreviewPosition.store(0.0f);
    playing.store (false); playbackPosition = 0;
    std::atomic_store (&result, std::shared_ptr<juce::AudioBuffer<float>> {});
    analysedRevision=captureRevision.load();
    if(retained) autoFallbackUsed=true;
    renderStatus.store (0);
    const juce::ScopedLock lock (exportLock); exportFile = juce::File();
}
void BloomProcessor::startCapture()
{
    const juce::ScopedLock callback(getCallbackLock());
    const int state = captureState.load();
    if (!busy.load() && !analysisBusy.load() && (state == 0 || state == 3))
    {
        resetEditHistory();
        playing.store (false);
        selectionBegin.store(0.0f); selectionEnd.store(1.0f);
        signalArmed.store(parameters.getRawParameterValue("signalcap")->load()>0.5f);
        captureState.store (4); // armed: audio thread owns reset and recording
    }
}
void BloomProcessor::stopCapture()
{
    const juce::ScopedLock callback(getCallbackLock());
    const bool wasArmed=signalArmed.exchange(false);
    if(wasArmed && captureState.load()==0 && captured.load()>0) captureState.store(3);
    int expected = 1;
    captureState.compare_exchange_strong (expected, 2);
    expected = 4;
    captureState.compare_exchange_strong (expected, wasArmed && captured.load()>0 ? 3 : 0);
}
RenderSettings BloomProcessor::settings() const
{
    auto v = [this] (const char* id) { return parameters.getRawParameterValue (id)->load(); };
    RenderSettings s;
    s.sampleRate = activeRate.load(); s.bpm = bpm.load();
    s.numerator = numerator.load(); s.denominator = denominator.load();
    s.lengthIndex = (int) v("length"); s.size = v("size"); s.decay = v("decay");
    s.preDelayMs=v("predelay");s.reverbType=(int)v("reverbtype");s.customCurve=v("curvemode")>0.5f;s.curve1=v("curve1");s.curve2=v("curve2");s.curve3=v("curve3");
    s.tone = v("tone"); s.swell = v("swell"); s.reverseSource = v("source");
    s.depth = v("depth"); s.rate = v("rate"); s.phase = v("phase");
    s.target = (int) v("target"); s.shape = (int) v("shape");
    s.rateIndex = (int) v("division"); s.sync = v("sync") > 0.5f;
    s.autoGain = v("autogain") > 0.5f; s.outputDb = v("output");
    s.lengthInMs=v("lengthmode")>0.5f; s.lengthMs=v("lengthms");
    s.lowCut=v("lowcut"); s.highCut=v("highcut");
    s.tailFadeMs=v("tailfade"); s.sourceFadeMs=v("sourcefade");
    return s;
}
void BloomProcessor::generate (float begin, float end)
{
    if (captureState.load() != 3 || busy.exchange (true)) return;
    const int count = captured.load();
    const int first = juce::jlimit (0, count, (int) (begin*count));
    const int last = juce::jlimit (first, count, (int) (end*count));
    if (last-first < 64) { busy.store (false); renderStatus.store (-1); setLastError("Selection too short (minimum 64 samples)"); return; }
    if (worker.joinable()) worker.join();
    auto capturedSource=getSource();
    if(!capturedSource || last>capturedSource->getNumSamples()) { busy.store(false); return; }
    const auto config = settings();
    const bool gainLock=parameters.getRawParameterValue("gainlock")->load()>0.5f;
    const auto key = requestedKey, baseKey = requestedBaseKey;
    cancel.store (false); renderStatus.store (1);
    exportStatus.store(0);
    worker = std::thread ([this, capturedSource, first, last, config, gainLock, key, baseKey]() mutable
    {
        try
        {
            if (!cachedBase || cachedBaseKey != baseKey)
            {
                juce::AudioBuffer<float> input(2,last-first);
                for(int ch=0;ch<2;++ch) input.copyFrom(ch,0,*capturedSource,ch,first,last-first);
                auto neutral = config;
                neutral.target = 0; neutral.depth = 0.0f;
                if(gainLock) neutral.autoGain=false;
                auto fresh = BloomRenderer::render (input,neutral,cancel);
                if (fresh && !cancel.load())
                {
                    if(gainLock && config.autoGain)
                    {
                        if(!lockedGainValid.load()) {
                            const float peak=juce::jmax(fresh->getMagnitude(0,0,fresh->getNumSamples()),fresh->getMagnitude(1,0,fresh->getNumSamples()));
                            lockedGain.store(peak>0.000001f?juce::jmin(16.0f,0.89125f/peak):1.0f);
                            lockedGainValid.store(true);
                        }
                        fresh->applyGain(lockedGain.load());
                    }
                    cachedBase = fresh; cachedBaseKey = baseKey;
                }
            }
            if (!cancel.load() && cachedBase && cachedBaseKey == baseKey)
            {
                auto packet=std::make_shared<PreviewPacket>();
                packet->tail=cachedBase; packet->source=capturedSource; packet->first=first; packet->count=last-first;
                if(std::find(retainedAudio.begin(),retainedAudio.end(),cachedBase)==retainedAudio.end()) retainedAudio.push_back(cachedBase);
                retainedPackets.push_back(packet);
                std::atomic_store(&publishedPacket,packet);
                std::atomic_store (&baseResult,cachedBase);
                auto output = BloomLive::bake (*cachedBase,config,cancel);
                if (output && !cancel.load())
                {
                    const juce::ScopedLock lock (exportLock);
                    std::atomic_store (&result,output); resultKey = key;
                    renderStatus.store (2);
                }
            }
        }
        catch (...) { setLastError("Tail render failed"); renderStatus.store (-1); }
        busy.store (false);
    });
}

juce::String BloomProcessor::fingerprint (bool baseOnly) const
{
    juce::String key;
    key << (int)captureRevision.load() << ":" << activeRate.load() << ":"
        << bpm.load() << ":" << numerator.load() << ":" << denominator.load()
        << ":" << selectionBegin.load() << ":" << selectionEnd.load();
    for (const auto* id : {"length","size","decay","tone","swell","source","autogain","gainlock","lengthmode","lengthms","lowcut","highcut","tailfade","predelay","reverbtype","curvemode","curve1","curve2","curve3"})
        key << ":" << juce::String (parameters.getRawParameterValue (id)->load(),7);
    if (!baseOnly)
        for (const auto* id : {"depth","rate","phase","target","shape","division","sync","output","sourcefade","exportmode","endgap"})
            key << ":" << juce::String (parameters.getRawParameterValue (id)->load(),7);
    return key;
}

void BloomProcessor::timerCallback()
{
    const juce::ScopedLock control (controlLock);
    if(newCaptureHistory.exchange(false)) resetEditHistory();
    if(isCapturing()) return;
    if(!busy.load()) {
        collectRetired();
        const bool lock=parameters.getRawParameterValue("gainlock")->load()>0.5f;
        if(!lock || !gainWasLocked || gainCaptureRevision.load()!=captureRevision.load()) lockedGainValid.store(false);
        gainWasLocked=lock; gainCaptureRevision.store(captureRevision.load());
    }
    if(clearCacheRequested.load() && !exportBusy.load()) {
        if(exportWorker.joinable()) exportWorker.join();
        exportBusy.store(true);
        exportWorker=std::thread([this] { cleanCache(true); clearCacheRequested.store(false); exportBusy.store(false); });
    }
    if (captureState.load() != 3) return;
    publishSource();
    if(analysedRevision!=captureRevision.load() && parameters.getRawParameterValue("autoselect")->load()>0.5f && !analysisBusy.load()) {
        analysedRevision=captureRevision.load(); requestTrim(true);
    }
    serviceAnalysis();
    if(analysisBusy.load() || trimRequested.load() || trimReady.load()) return;
    const auto key = fingerprint (false);
    if (busy.load())
    {
        if (key != requestedKey) cancel.store (true);
        return;
    }
    if (key == requestedKey && !cancel.load()) { prepareExport(); return; }
    requestedKey = key; requestedBaseKey = fingerprint (true);
    generate (selectionBegin.load(),selectionEnd.load());
}
void BloomProcessor::togglePreview()
{
    if (isCapturing()) return;
    if (playing.load()) playing.store (false);
    else if (getResult()) { resetPreview.store (true); playing.store (true); }
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new BloomProcessor(); }
juce::AudioProcessorEditor* BloomProcessor::createEditor() {
#if RB_WEB_UI
 return new BloomWebEditor(*this);
#else
 return new BloomEditor(*this);
#endif
}

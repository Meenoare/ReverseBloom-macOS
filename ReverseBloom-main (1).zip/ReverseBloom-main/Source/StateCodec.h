#pragma once
#include "Renderer.h"
#include <cstring>

// Bounded lossless float capture serialization. 2 channels, <=30 s, <=192 kHz.
namespace BloomState
{
struct Capture { std::shared_ptr<juce::AudioBuffer<float>> audio; double rate = 44100.0; };
inline void encode(juce::XmlElement& xml, const juce::AudioBuffer<float>& audio, double rate)
{
    const int n = audio.getNumSamples();
    if (n < 1 || rate < 8000.0 || rate > 192000.0 || n > rate*30.0) return;
    juce::MemoryOutputStream raw;
    for(int ch=0;ch<2;++ch)
        for(int i=0;i<n;++i) raw.writeFloat(audio.getSample(juce::jmin(ch,audio.getNumChannels()-1),i));
    juce::MemoryOutputStream packed;
    { juce::GZIPCompressorOutputStream compressor(packed,6); compressor.write(raw.getData(),raw.getDataSize()); }
    auto* child = xml.createNewChildElement("BloomCapture");
    child->setAttribute("version",1); child->setAttribute("samples",n); child->setAttribute("rate",rate);
    child->addTextElement(packed.getMemoryBlock().toBase64Encoding());
}
inline Capture decode(const juce::XmlElement& xml)
{
    Capture c;
    auto* child = xml.getChildByName("BloomCapture");
    if (!child || child->getIntAttribute("version") != 1) return c;
    const int n = child->getIntAttribute("samples"); c.rate=child->getDoubleAttribute("rate");
    if(c.rate<8000.0 || c.rate>192000.0 || !std::isfinite(c.rate) || n<1 || n>c.rate*30.0) return {};
    juce::MemoryBlock packed;
    if (!packed.fromBase64Encoding(child->getAllSubText()) || packed.getSize()>64*1024*1024) return {};
    juce::MemoryInputStream input(packed,false);
    juce::GZIPDecompressorInputStream unzip(input);
    const size_t bytes=(size_t)n*2*sizeof(float);
    juce::MemoryBlock raw(bytes);
    size_t read=0;
    while(read<bytes)
    {
        const int got=unzip.read((char*)raw.getData()+read,(int)juce::jmin((size_t)65536,bytes-read));
        if(got<=0) return {};
        read+=(size_t)got;
    }
    char extra; if(unzip.read(&extra,1)!=0) return {};
    juce::MemoryInputStream stream(raw,false);
    c.audio=std::make_shared<juce::AudioBuffer<float>>(2,n);
    for(int ch=0;ch<2;++ch)
        for(int i=0;i<n;++i)
        {
            const float v=stream.readFloat(); if(!std::isfinite(v)) return {};
            c.audio->setSample(ch,i,v);
        }
    return c;
}
inline std::shared_ptr<juce::AudioBuffer<float>> resample(const juce::AudioBuffer<float>& source, double from, double to)
{
    if(from==to) return std::make_shared<juce::AudioBuffer<float>>(source);
    const int count=juce::jmax(1,(int)std::round(source.getNumSamples()*to/from));
    auto result=std::make_shared<juce::AudioBuffer<float>>(2,count);
    // JUCE windowed-sinc interpolation; padding accommodates filter support at clip boundaries.
    constexpr int padding=256;
    for(int ch=0;ch<2;++ch)
    {
        std::vector<float> input((size_t)source.getNumSamples()+padding,0.0f);
        std::memcpy(input.data(),source.getReadPointer(juce::jmin(ch,source.getNumChannels()-1)),(size_t)source.getNumSamples()*sizeof(float));
        juce::WindowedSincInterpolator interpolator;
        const double ratio = from/to;
        const int delay = (int)std::ceil(juce::WindowedSincInterpolator::getBaseLatency()/ratio);
        std::vector<float> temporary((size_t)count+delay);
        interpolator.process(ratio,input.data(),temporary.data(),count+delay);
        std::memcpy(result->getWritePointer(ch),temporary.data()+delay,(size_t)count*sizeof(float));
    }
    return result;
}
}

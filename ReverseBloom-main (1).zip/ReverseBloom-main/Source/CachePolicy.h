#pragma once
#include <cstdint>
namespace BloomCachePolicy {
constexpr std::int64_t day=24LL*60*60*1000;
constexpr std::int64_t budget=512LL*1024*1024;
inline bool eligible(bool registered,bool current,bool activeOther,std::int64_t age)
{ return registered && !current && !activeOther && age>=day; }
inline bool shouldRemove(bool eligibleFile,bool manual,std::int64_t age,std::int64_t total)
{ return eligibleFile && (manual || age>=7*day || total>budget); }
}

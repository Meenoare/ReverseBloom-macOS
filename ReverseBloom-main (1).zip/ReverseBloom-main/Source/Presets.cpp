#include "Processor.h"
#include <map>
namespace {
const juce::StringArray soundIDs {"predelay","reverbtype","curvemode","curve1","curve2","curve3","length","lengthmode","lengthms","size","decay","tone","swell","source","depth","rate","phase","target","shape","division","sync","output","autogain","lowcut","highcut","tailfade","sourcefade","lfomode"};
const juce::StringArray workflowIDs {"autocapture","previewmode","exportmode","signalcap","autoselect","threshold","holdms","preroll","endgap","looppause"};
void setValue(juce::AudioProcessorValueTreeState& state,const juce::String& id,float value) {
    if(auto* p=state.getParameter(id)) {p->beginChangeGesture();p->setValueNotifyingHost(p->convertTo0to1(value));p->endChangeGesture();}
}
juce::File defaultsFile() {return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("ReverseBloom").getChildFile("WorkflowDefaults.xml");}
}
juce::StringArray BloomProcessor::factoryPresetNames() const
{ return {"Clean Bloom","Velvet Vocal","Neon Pulse","Glass Lift","Dark Horizon","Ghost Whisper","Tape Mirage","Orbit Pan","Impact Rise","Frozen Cathedral","Micro Sweep","Silver Gate"}; }
void BloomProcessor::applyFactoryPreset(int index)
{
    if(index<0 || index>=factoryPresetNames().size()) return;
    pollHistory(); undoStack.push_back(readEditState()); redoStack.clear();
    for(const auto& id:soundIDs) if(auto* p=parameters.getParameter(id)) setValue(parameters,id,p->convertFrom0to1(p->getDefaultValue()));
    using Values=std::map<juce::String,float>;
    static const std::vector<Values> presets {
        {{"depth",0},{"lowcut",100},{"decay",2.8f}},
        {{"size",0.86f},{"decay",4.5f},{"tone",6500},{"lowcut",160},{"highcut",12000},{"depth",0.12f},{"swell",1.8f}},
        {{"shape",1},{"depth",0.85f},{"division",4},{"lowcut",180},{"tone",12000}},
        {{"size",0.65f},{"decay",2},{"tone",16000},{"swell",2.5f},{"depth",0.15f},{"length",1},{"lowcut",350}},
        {{"size",0.94f},{"decay",8},{"tone",2400},{"highcut",5000},{"lowcut",90},{"depth",0.25f},{"length",3}},
        {{"size",0.9f},{"source",0.18f},{"tone",4800},{"depth",0},{"lowcut",280},{"output",-3}},
        {{"target",1},{"shape",0},{"depth",0.4f},{"division",1},{"highcut",7000},{"source",0.25f}},
        {{"target",2},{"depth",0.8f},{"division",2},{"size",0.9f},{"lowcut",180}},
        {{"length",1},{"size",0.6f},{"decay",1.2f},{"swell",3.5f},{"depth",0},{"lowcut",70},{"tailfade",5}},
        {{"length",3},{"size",0.98f},{"decay",10},{"swell",1.1f},{"depth",0.2f},{"division",0},{"lowcut",220}},
        {{"lengthmode",1},{"lengthms",350},{"size",0.55f},{"decay",0.8f},{"swell",2},{"depth",0},{"lowcut",300}},
        {{"shape",3},{"depth",0.9f},{"division",5},{"tone",14000},{"lowcut",220},{"decay",2.5f}}
    };
    for(const auto& [id,value]:presets[(size_t)index]) setValue(parameters,id,value);
    historyState=readEditState(); lastEditTime=0;
}
void BloomProcessor::saveSoundPreset(const juce::File& file)
{
    juce::XmlElement xml("ReverseBloomSoundPreset"); xml.setAttribute("version",1);
    for(const auto& id:soundIDs) if(auto* p=parameters.getParameter(id)) xml.setAttribute(id,(double)p->convertFrom0to1(p->getValue()));
    if(!xml.writeTo(file)) setLastError("Cannot save sound preset");
}
void BloomProcessor::loadSoundPreset(const juce::File& file)
{
    if(file.getSize()>128*1024) {setLastError("Preset file too large"); return;}
    auto xml=juce::XmlDocument::parse(file);
    if(!xml || !xml->hasTagName("ReverseBloomSoundPreset")) {setLastError("Invalid sound preset"); return;}
    pollHistory(); undoStack.push_back(readEditState()); redoStack.clear();
    for(const auto* id:{"predelay","reverbtype","curvemode","curve1","curve2","curve3"})if(!xml->hasAttribute(id))if(auto* p=parameters.getParameter(id))setValue(parameters,id,p->convertFrom0to1(p->getDefaultValue()));
    for(const auto& id:soundIDs) if(xml->hasAttribute(id)) {const double value=xml->getDoubleAttribute(id); if(std::isfinite(value)) setValue(parameters,id,(float)value);}
    historyState=readEditState(); lastEditTime=0;
}
void BloomProcessor::saveWorkflowDefaults()
{
    const auto file=defaultsFile(); if(!file.getParentDirectory().createDirectory()) {setLastError("Cannot create defaults folder"); return;}
    juce::XmlElement xml("ReverseBloomWorkflow"); xml.setAttribute("scale",uiScale.load());
    for(const auto& id:workflowIDs) if(auto* p=parameters.getParameter(id)) xml.setAttribute(id,(double)p->convertFrom0to1(p->getValue()));
    if(!xml.writeTo(file)) setLastError("Cannot save workflow defaults");
}
void BloomProcessor::loadWorkflowDefaults()
{
    auto xml=juce::XmlDocument::parse(defaultsFile()); if(!xml || !xml->hasTagName("ReverseBloomWorkflow")) return;
    for(const auto& id:workflowIDs) if(xml->hasAttribute(id)) {const double value=xml->getDoubleAttribute(id);if(std::isfinite(value)) setValue(parameters,id,(float)value);}
    uiScale.store(juce::jlimit(0,2,xml->getIntAttribute("scale",1)));
}

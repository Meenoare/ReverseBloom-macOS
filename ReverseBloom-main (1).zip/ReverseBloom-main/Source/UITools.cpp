#include "Editor.h"
#include "Theme.h"

namespace {
class AdvancedPanel final : public juce::Component
{
public:
    explicit AdvancedPanel(BloomProcessor& p) {
        const juce::StringArray ids {"lowcut","highcut","tailfade","sourcefade","lengthms","threshold","holdms","preroll"};
        const juce::StringArray names {"Tail Low Cut (Hz)","Tail High Cut (Hz)","Tail End Fade (ms)","Source Fade In (ms)","Length (ms)","Trigger (dBFS)","Silence stop (ms)","Pre-roll (ms)"};
        for(int i=0;i<ids.size();++i) {
            auto l=std::make_unique<juce::Label>(); l->setText(names[i],juce::dontSendNotification);addAndMakeVisible(*l);l->setBounds(12,12+i*40,170,30);labels.push_back(std::move(l));
            auto slider=std::make_unique<juce::Slider>();slider->setSliderStyle(juce::Slider::LinearHorizontal);slider->setTextBoxStyle(juce::Slider::TextBoxRight,false,80,26);
            addAndMakeVisible(*slider);slider->setBounds(185,12+i*40,290,30);
            slider->onDragStart=[&p]{p.userEditing.store(true);p.pollHistory();};
            slider->onDragEnd=[&p]{p.pollHistory();p.userEditing.store(false);};
            attachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.parameters,ids[i],*slider));sliders.push_back(std::move(slider));
        }
        setSize(490,340);
    }
    void paint(juce::Graphics& g) override {g.fillAll(BloomTheme::surface);}
private:
    std::vector<std::unique_ptr<juce::Label>> labels;
    std::vector<std::unique_ptr<juce::Slider>> sliders;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> attachments;
};
}
void BloomEditor::setupTools()
{
    for(juce::Component* c:std::initializer_list<juce::Component*>{&settingsButton,&presetChoice,&fitButton,&resetViewButton,&rangeInfo,&trimButton,&abButton,&undoButton,&redoButton,&gainLockButton}) canvas.addAndMakeVisible(c);
    gainLockAttachment=std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(processor.parameters,"gainlock",gainLockButton);
    gainLockButton.setTooltip("Freeze Auto Gain multiplier. Not a limiter or loudness matching.");
    trimButton.setTooltip("Non-destructive audible-range selection in background. Full capture preserved.");
    trimButton.onClick=[this]{processor.trimSilence();};
    fitButton.onClick=[this]{sourceWave.fitSelection();}; resetViewButton.onClick=[this]{sourceWave.resetView();};
    abButton.onClick=[this]{processor.switchAB();};
    undoButton.onClick=[this]{processor.undoSettings();}; redoButton.onClick=[this]{processor.redoSettings();};
    presetChoice.addItemList(processor.factoryPresetNames(),1);presetChoice.setTextWhenNothingSelected("Sound preset / Custom");
    presetChoice.onChange=[this]{
        processor.applyFactoryPreset(presetChoice.getSelectedId()-1);
        presetSignature.clear();
        for(auto* p:processor.getParameters()) presetSignature<<p->getValue()<<":";
    };
    settingsButton.onClick=[this]{showSettings();};
}
void BloomEditor::showSettings()
{
    juce::PopupMenu menu;menu.setLookAndFeel(&look);
    auto value=[this](const char* id){return processor.parameters.getRawParameterValue(id)->load();};
    menu.addItem(1,"Advanced: filters, fades & capture...");
    menu.addSeparator();menu.addItem(2,"Automatic capture (disable to protect current source)",true,value("autocapture")>0.5f);
    menu.addItem(12,"Re-arm signal capture (hosts without transport)");
    menu.addItem(3,"Auto-select after capture",true,value("autoselect")>0.5f);
    menu.addItem(4,"Length in milliseconds",true,value("lengthmode")>0.5f);
    menu.addItem(5,"Export Tail -> Source",true,value("exportmode")>0.5f);
    menu.addSeparator();menu.addItem(6,"Save sound preset...");menu.addItem(7,"Load sound preset...");
    menu.addItem(8,"Save current workflow as default");menu.addItem(9,"Apply workflow defaults");
    menu.addSeparator();menu.addItem(20,"Export WAV...");menu.addItem(21,"Undo");menu.addItem(22,"Redo");
    menu.addItem(23,"Trim source silence");menu.addItem(24,"Fit source selection");
    menu.addItem(30,"Scale 50%");menu.addItem(31,"Scale 75%");menu.addItem(32,"Scale 100%");
    menu.addSeparator();menu.addItem(10,"Copy Diagnostics");menu.addItem(11,"Clear Cache...");
    juce::Component::SafePointer<BloomEditor> safe(this);
    menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&settingsButton),[safe](int id){
        if(!safe) return;
        auto& p=safe->processor;
        const auto toggle=[&](const char* key){if(auto* par=p.parameters.getParameter(key)) {p.userEditing.store(true); p.pollHistory(); par->beginChangeGesture();par->setValueNotifyingHost(par->getValue()>0.5f?0.0f:1.0f);par->endChangeGesture();p.pollHistory();p.userEditing.store(false);}};
        if(id==20 && safe->exportButton.onClick) safe->exportButton.onClick();
        if(id==21) p.undoSettings();
        if(id==22) p.redoSettings();
        if(id==23) p.trimSilence();
        if(id==24){safe->showRaw=true;safe->sourceWave.fitSelection();safe->resized();}
        if(id>=30 && id<=32){p.uiScale.store(id-30);safe->applyScale();}
        if(id==1) safe->showAdvanced();
        if(id==2) toggle("autocapture");
        if(id==12) p.requestAutomaticRearm();
        if(id==3) toggle("autoselect");
        if(id==4) toggle("lengthmode");
        if(id==5) toggle("exportmode");
        if(id==6 || id==7) safe->presetFileDialog(id==6);
        if(id==8) p.saveWorkflowDefaults();
        if(id==9) p.loadWorkflowDefaults();
        if(id==10) juce::SystemClipboard::copyTextToClipboard(p.diagnostics());
        if(id==11) juce::AlertWindow::showOkCancelBox(juce::MessageBoxIconType::QuestionIcon,"Clear export cache?",
            "Remove registered service WAVs older than 24 hours? Current files, recent exports and other active instances remain protected.","Clear Cache","Cancel",nullptr,
            juce::ModalCallbackFunction::create([safe](int result){if(safe && result) safe->processor.clearExportCache();}));
    });
}
void BloomEditor::showAdvanced()
{
    // Child modal callout is dismissed with editor, avoiding dangling processor references.
    auto panel=std::make_unique<AdvancedPanel>(processor);
    juce::CallOutBox::launchAsynchronously(std::move(panel),settingsButton.getBounds(),&canvas);
}
void BloomEditor::presetFileDialog(bool save)
{
    chooser=std::make_unique<juce::FileChooser>(save?"Save sound preset":"Load sound preset",
        juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile("ReverseBloomPreset.xml"),"*.xml");
    juce::Component::SafePointer<BloomEditor> safe(this);
    chooser->launchAsync((save?juce::FileBrowserComponent::saveMode:juce::FileBrowserComponent::openMode)|juce::FileBrowserComponent::canSelectFiles,
        [safe,save](const juce::FileChooser& fc){if(!safe || fc.getResult()==juce::File{}) return; if(save) safe->processor.saveSoundPreset(fc.getResult().withFileExtension("xml"));else {safe->processor.loadSoundPreset(fc.getResult());safe->presetChoice.setSelectedId(0,juce::dontSendNotification);}});
}
void BloomEditor::updateLengthBinding()
{
    const int mode=processor.parameters.getRawParameterValue("lengthmode")->load()>0.5f ? 1:0;
    if(mode==lengthBinding) return;
    lengthAttachment.reset();lengthBinding=mode;
    auto& slider=*knobs[8];
    if(mode) {
        slider.textFromValueFunction=[](double v){return juce::String(v,0)+" ms";};
        slider.valueFromTextFunction=[](const juce::String& t){return t.getDoubleValue();};
    } else {
        slider.textFromValueFunction=[](double v){return juce::StringArray{"1/4 BAR","1/2 BAR","1 BAR","2 BARS","4 BARS"}[juce::jlimit(0,4,(int)std::round(v))];};
        slider.valueFromTextFunction=[](const juce::String& t){if(t.contains("1/4"))return 0.0;if(t.contains("1/2"))return 1.0;if(t.startsWith("2"))return 3.0;if(t.startsWith("4"))return 4.0;return 2.0;};
    }
    const char* id=mode?"lengthms":"length";
    lengthAttachment=std::make_unique<SliderAttachment>(processor.parameters,id,slider);
    auto* p=processor.parameters.getParameter(id);slider.setDoubleClickReturnValue(true,p->convertFrom0to1(p->getDefaultValue()));slider.updateText();
}

#pragma once
#include "Processor.h"
#if RB_WEB_UI
class BloomWebEditor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
 explicit BloomWebEditor(BloomProcessor&);
 ~BloomWebEditor() override;
 void resized() override;
private:
 BloomProcessor& processor;
 bool sourceView=false,ready=false;
 int ticks=0;
 std::shared_ptr<juce::AudioBuffer<float>> previousAudio;
 juce::Array<juce::var> peaks,live;
 std::unique_ptr<juce::FileChooser> chooser;
 juce::WebBrowserComponent browser;
 juce::WebBrowserComponent::Options options();
 void message(const juce::var&);
 void publish(juce::var);
 void timerCallback() override;
 std::optional<juce::WebBrowserComponent::Resource> resource(const juce::String&);
};
#endif

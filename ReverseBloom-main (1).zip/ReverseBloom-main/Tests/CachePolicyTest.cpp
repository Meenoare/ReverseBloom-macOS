#include "CachePolicy.h"
#include <cassert>
#include <iostream>
int main() {
    using namespace BloomCachePolicy;
    assert(!eligible(false,false,false,30*day)); // unknown/user file
    assert(!eligible(true,true,false,30*day)); // current file
    assert(!eligible(true,false,true,30*day)); // another active instance
    assert(!eligible(true,false,false,day-1)); // recently created/exported
    assert(!eligible(true,false,false,-day)); // clock rolled back
    assert(eligible(true,false,false,day));
    assert(!shouldRemove(false,true,30*day,2*budget));
    assert(!shouldRemove(true,false,2*day,budget));
    assert(shouldRemove(true,false,7*day,0));
    assert(shouldRemove(true,false,day,budget+1));
    assert(shouldRemove(true,true,day,0));
    std::cout<<"PASS: cache retention policy (11 cases)\n";
}

#include "CaptureHarness.h"
#include <cassert>
#include <iostream>
int main() {
    BloomProcessor p;
    juce::AudioBuffer<float> silence(2,200);silence.clear();p.captureInput(silence);
    p.signalArmed.store(true);p.captureState.store(4);p.captureInput(silence);
    assert(p.signalArmed && p.captureState==0 && p.captured==0);
    juce::AudioBuffer<float> signal(2,20);signal.clear();signal.setSample(1,0,0.5f);p.captureInput(signal);
    assert(!p.signalArmed && p.captureState==1 && p.captured==70);
    assert(p.capturedAudio.getSample(1,50)==0.5f); // onset preserved, right channel triggers
    assert(p.captureRevision==1);
    juce::AudioBuffer<float> stop(2,100);stop.clear();p.captureInput(stop);
    assert(p.captureState==3 && p.captured==56); // onset+5ms, trailing silence excluded
    BloomProcessor m;m.captureState.store(4);m.captureInput(signal);
    assert(m.captureState==1 && m.captured==20); // manual capture ignores stop threshold
    m.captureState.store(2);m.captureInput(stop);assert(m.captureState==3 && m.captured==20);
    BloomProcessor full;full.captureState.store(1);full.captured.store(29999);full.captureInput(signal);
    assert(full.captureState==3 && full.captured==30000);
    BloomProcessor t;
    t.updateAutomaticCapture(true,false);assert(!t.signalArmed);
    t.updateAutomaticCapture(true,true);assert(t.signalArmed && t.transportSession);
    t.captureInput(signal);assert(t.captureState==1);
    t.captureInput(silence);assert(t.captureState==1); // pause inside phrase does not stop transport capture
    t.updateAutomaticCapture(true,false);t.captureInput(stop);assert(t.captureState==3 && !t.signalArmed);
    const auto revision=t.captureRevision.load();
    t.playing.store(true);t.updateAutomaticCapture(true,false);t.captureInput(signal);
    assert(t.captureRevision==revision); // own audition / stopped host never re-arms
    t.updateAutomaticCapture(true,true);assert(t.signalArmed && !t.playing);
    t.captureInput(signal);assert(t.captureRevision==revision+1);
    BloomProcessor fallback;
    fallback.updateAutomaticCapture(false,false);assert(fallback.signalArmed);
    fallback.captureInput(signal);fallback.captureInput(silence);assert(fallback.captureState==3);
    fallback.updateAutomaticCapture(false,false);assert(!fallback.signalArmed);
    fallback.rearmAutoCapture.store(true);fallback.updateAutomaticCapture(false,false);assert(fallback.signalArmed);
    BloomProcessor delayed;delayed.busy.store(true);delayed.updateAutomaticCapture(true,true);assert(!delayed.signalArmed);
    delayed.busy.store(false);delayed.updateAutomaticCapture(true,true);assert(delayed.signalArmed);
    std::cout<<"PASS: transport stop/start, pauses, audition protection, one-shot fallback, explicit rearm, busy retry\n";
    std::cout<<"PASS: production capture body with field harness: arming, stereo onset, pre-roll, silence stop, manual stop, capacity\n";
}

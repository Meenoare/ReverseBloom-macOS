#include <memory>
#include <vector>
#include <thread>
#include <atomic>
#include <algorithm>
#include <cassert>
#include <iostream>
struct Packet {std::shared_ptr<int> tail,source; int first,count;};
int main() {
    std::atomic<bool> wrong{false}; const auto control=std::this_thread::get_id();
    auto buffer=std::shared_ptr<int>(new int(42),[&](int* p){if(std::this_thread::get_id()!=control) wrong=true; delete p;});
    std::vector<std::shared_ptr<int>> keep{buffer};
    auto a=std::make_shared<Packet>(Packet{buffer,buffer,10,30});
    auto b=std::make_shared<Packet>(Packet{buffer,buffer,100,60});
    std::vector<std::shared_ptr<Packet>> packets{a,b};
    std::shared_ptr<Packet> published=a,active;
    std::thread audio([&]{
        active=std::atomic_load(&published); assert(active->first==10 && active->count==30);
        std::atomic_store(&published,b);
        assert(active->first==10 && active->count==30); // no mid-transition adoption
        active=std::atomic_load(&published); assert(active->first==100 && active->count==60);
        active.reset();
    }); audio.join();
    a.reset();b.reset();published.reset();buffer.reset();
    packets.erase(std::remove_if(packets.begin(),packets.end(),[](auto& p){return p.use_count()==1;}),packets.end());
    keep.erase(std::remove_if(keep.begin(),keep.end(),[](auto& p){return p.use_count()==1;}),keep.end());
    assert(packets.empty() && keep.empty() && !wrong);
    std::cout<<"PASS: snapshot boundary policy and deferred buffer destruction model\n";
}

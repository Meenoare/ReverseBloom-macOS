#pragma once
#include <juce_audio_formats/juce_audio_formats.h>
#include <atomic>
#include <map>
struct HarnessParameters {
    std::map<juce::String,std::unique_ptr<std::atomic<float>>> values;
    HarnessParameters() {for(const auto& kv:std::map<juce::String,float>{{"autocapture",1},{"threshold",-20},{"holdms",100},{"preroll",50}}) values[kv.first]=std::make_unique<std::atomic<float>>(kv.second);}
    std::atomic<float>* getRawParameterValue(const juce::String& id) {return values.at(id).get();}
};
// Minimal host-independent field harness; production captureInput body is compiled unchanged.
class BloomProcessor {
public:
    HarnessParameters parameters;
    juce::AudioBuffer<float> capturedAudio {2,30000},preRollBuffer {2,200};
    std::atomic<int> captureState{0},captured{0};
    std::atomic<unsigned int> captureRevision{0};
    std::atomic<bool> signalArmed{false};
    std::atomic<double> activeRate{1000};
    int preRollWrite=0,preRollCount=0,quietSamples=0;
    bool signalRecording=false;
    std::atomic<float> selectionBegin{0},selectionEnd{1};
    std::atomic<bool> newCaptureHistory{false},transportAvailable{false},hostTransportPlaying{false},rearmAutoCapture{false};
    std::atomic<bool> busy{false},analysisBusy{false},trimReady{false},trimRequested{false},playing{false};
    bool transportSession=false,autoHostWasPlaying=false,autoFallbackUsed=false,autoWasEnabled=true;
    void updateAutomaticCapture(bool,bool);
    void captureInput(juce::AudioBuffer<float>&);
};

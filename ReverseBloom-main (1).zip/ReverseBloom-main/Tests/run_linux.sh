#!/usr/bin/env bash
set -euo pipefail
# Usage: bash Tests/run_linux.sh /path/to/JUCE/modules
MODULES="${1:?Pass JUCE/modules path}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$(mktemp -d)"
trap 'rm -rf "$BUILD"' EXIT
printf '#include <juce_audio_formats/juce_audio_formats.h>\n' > "$BUILD/JuceHeader.h"
CXX="${CXX:-g++}"
"$CXX" -std=c++17 -O0 -DJUCE_GLOBAL_MODULE_SETTINGS_INCLUDED=1 -DJUCE_USE_CURL=0 -DJUCE_USE_FLAC=0 -DJUCE_USE_OGGVORBIS=0 -DJUCE_USE_MP3AUDIOFORMAT=0 \
 -I"$BUILD" -I"$ROOT/Source" -I"$MODULES" \
 "$ROOT/Tests/StateAndLive.cpp" "$ROOT/Source/Renderer.cpp" \
 "$MODULES/juce_core/juce_core.cpp" "$MODULES/juce_core/juce_core_CompilationTime.cpp" \
 "$MODULES/juce_audio_basics/juce_audio_basics.cpp" "$MODULES/juce_audio_formats/juce_audio_formats.cpp" \
 -pthread -ldl -lrt -lz -o "$BUILD/test"
"$BUILD/test"
"$CXX" -std=c++17 -Wall -Wextra -I"$ROOT/Source" "$ROOT/Tests/PreviewTimelineTest.cpp" -o "$BUILD/preview"
"$BUILD/preview"

"$CXX" -std=c++17 -Wall -Wextra -I"$ROOT/Source" "$ROOT/Tests/CachePolicyTest.cpp" -o "$BUILD/cache"
"$BUILD/cache"

# Compile the actual capture method against a minimal field harness (not a full DAW).
{ printf '#include "CaptureHarness.h"\n'; tail -n +2 "$ROOT/Source/Capture.cpp"; tail -n +2 "$ROOT/Source/AutoCapture.cpp"; } > "$BUILD/CaptureUnderTest.cpp"
"$CXX" -std=c++17 -O0 -DJUCE_GLOBAL_MODULE_SETTINGS_INCLUDED=1 -DJUCE_USE_CURL=0 \
 -I"$ROOT/Tests" -I"$MODULES" "$ROOT/Tests/CaptureTest.cpp" "$BUILD/CaptureUnderTest.cpp" \
 "$MODULES/juce_core/juce_core.cpp" "$MODULES/juce_core/juce_core_CompilationTime.cpp" \
 "$MODULES/juce_audio_basics/juce_audio_basics.cpp" -pthread -ldl -lrt -lz -o "$BUILD/capture"
"$BUILD/capture"

#include "Renderer.h"
#include <cmath>

namespace LegacyRenderer
{
std::shared_ptr<juce::AudioBuffer<float>> render (const juce::AudioBuffer<float>& source,
                                                const RenderSettings& s,
                                                const std::atomic<bool>& cancel)
{
    if (source.getNumSamples() < 1) return {};
    const double bars[] { 0.25, 0.5, 1.0, 2.0, 4.0 };
    const double beatsPerBar = s.numerator * 4.0 / juce::jmax (1, s.denominator);
    const double seconds = juce::jlimit (0.1, 60.0,
        s.lengthInMs ? s.lengthMs/1000.0 : bars[juce::jlimit (0, 4, s.lengthIndex)] * beatsPerBar * 60.0 / s.bpm);
    const int n = juce::jmax (64, (int) std::round (seconds * s.sampleRate));
    auto out = std::make_shared<juce::AudioBuffer<float>> (2, n);
    out->clear();
    juce::Reverb reverb;
    reverb.setSampleRate (s.sampleRate);
    juce::Reverb::Parameters p;
    p.roomSize = juce::jlimit (0.0f, 0.98f, s.size);
    p.damping = 0.35f; p.wetLevel = 1.0f; p.dryLevel = 0.0f;
    p.width = 1.0f; p.freezeMode = 0.0f;
    reverb.setParameters (p);
    // Process the selected source first; then extract its wet tail.
    // Decay is an explicit tail envelope, not a calibrated reverb RT60.
    constexpr int block = 512;
    juce::AudioBuffer<float> temp (2, block);
    const int inputN = source.getNumSamples();
    const int total = inputN + n;
    float lp[2] {};
    const float pole = std::exp (-juce::MathConstants<float>::twoPi
        * juce::jlimit (100.0f, (float) (s.sampleRate * 0.45), s.tone) / (float) s.sampleRate);
    for (int pos = 0; pos < total; pos += block)
    {
        if (cancel.load()) return {};
        const int count = juce::jmin (block, total - pos);
        temp.clear();
        for (int ch = 0; ch < 2; ++ch)
            for (int i = 0; i < count && pos + i < inputN; ++i)
                temp.setSample (ch, i, source.getSample (juce::jmin (ch, source.getNumChannels()-1), pos+i));
        reverb.processStereo (temp.getWritePointer (0), temp.getWritePointer (1), count);
        for (int i = 0; i < count; ++i)
        {
            const int tail = pos + i - inputN;
            if (tail < 0) continue;
            const int dst = n - 1 - tail;
            const float decay = std::exp (-6.907755f * (float) (tail / s.sampleRate) / s.decay);
            for (int ch = 0; ch < 2; ++ch)
            {
                lp[ch] = (1.0f-pole) * temp.getSample (ch, i) + pole * lp[ch];
                out->setSample (ch, dst, lp[ch] * decay);
            }
        }
    }
    const double cyclesPerBeat[] { 0.25, 0.5, 1, 2, 4, 8 };
    const double hz = s.sync ? s.bpm / 60.0 * cyclesPerBeat[juce::jlimit (0, 5, s.rateIndex)] : s.rate;
    float filterState[2] {}, hpIn[2]{},hpOut[2]{},lpOut[2]{};
    const float hpPole=std::exp(-juce::MathConstants<float>::twoPi*juce::jmin(s.lowCut,(float)s.sampleRate*0.45f)/(float)s.sampleRate);
    const float lpPole=std::exp(-juce::MathConstants<float>::twoPi*juce::jmin(s.highCut,(float)s.sampleRate*0.45f)/(float)s.sampleRate);
    for (int i = 0; i < n; ++i)
    {
        if ((i & 4095) == 0 && cancel.load()) return {};
        const double t = (double) i / s.sampleRate;
        const float phase = (float) (t * hz + s.phase - std::floor (t * hz + s.phase));
        float wave = 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * phase);
        if (s.shape == 1) wave = 1.0f - std::abs (2.0f * phase - 1.0f);
        if (s.shape == 2) wave = phase;
        if (s.shape == 3) wave = 0.5f + 0.5f * std::tanh (8.0f * std::sin (juce::MathConstants<float>::twoPi * phase));
        const float swell = std::pow ((float) i / (float) (n-1), s.swell);
        const float endFade = s.tailFadeMs<=0 ? 1.0f : juce::jlimit (0.0f, 1.0f, (float) (n-1-i) / (float) juce::jmax (1, (int) (s.sampleRate * s.tailFadeMs / 1000.0)));
        const float cutoff = 200.0f * std::pow (60.0f, 1.0f-s.depth+s.depth*wave);
        const float a = std::exp (-juce::MathConstants<float>::twoPi * juce::jmin (cutoff, (float) s.sampleRate*0.45f) / (float) s.sampleRate);
        for (int ch = 0; ch < 2; ++ch)
        {
            const int srcIndex = n-1-i;
            const float dry = srcIndex >= 0 && srcIndex < inputN
                ? source.getSample (juce::jmin (ch, source.getNumChannels()-1), srcIndex) : 0.0f;
            float v = ((1.0f-s.reverseSource)*out->getSample (ch,i) + s.reverseSource*dry) * swell;
            if (s.target == 0) v *= 1.0f-s.depth+s.depth*wave;
            if (s.target == 1) { filterState[ch] = (1.0f-a)*v+a*filterState[ch]; v = filterState[ch]; }
            if (s.target == 2)
            {
                const float pan = (2.0f*wave-1.0f)*s.depth;
                v *= std::sqrt (juce::jmax (0.0f, ch == 0 ? 1.0f-pan : 1.0f+pan));
            }
            if(s.lowCut>20.01f) { const float hp=hpPole*(hpOut[ch]+v-hpIn[ch]); hpIn[ch]=v; hpOut[ch]=hp; v=hp; }
            if(s.highCut<19999.0f) { lpOut[ch]=(1-lpPole)*v+lpPole*lpOut[ch]; v=lpOut[ch]; }
            out->setSample (ch,i,v*endFade);
        }
    }
    float peak = juce::jmax (out->getMagnitude (0,0,n), out->getMagnitude (1,0,n));
    if (s.autoGain && peak > 0.000001f) out->applyGain (juce::jmin (16.0f, 0.89125f/peak));
    return out;
}

bool writeWav (const juce::File& file, const juce::AudioBuffer<float>& buffer, double sr)
{
    auto stream = file.createOutputStream();
    if (!stream) return false;
    juce::WavAudioFormat format;
    std::unique_ptr<juce::AudioFormatWriter> writer (format.createWriterFor (stream.get(), sr,
        (unsigned int) buffer.getNumChannels(), 24, {}, 0));
    if (!writer) return false;
    stream.release();
    return writer->writeFromAudioSampleBuffer (buffer, 0, buffer.getNumSamples());
}
}

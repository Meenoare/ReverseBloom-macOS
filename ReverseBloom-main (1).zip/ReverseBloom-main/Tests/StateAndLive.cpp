#include "StateCodec.h"
#include "LiveEngine.h"
#include <iostream>
#include <stdexcept>
#include <cmath>
static void check(bool ok,const char* message) { if(!ok) throw std::runtime_error(message); }
int main()
{
    juce::AudioBuffer<float> input(2,4410);
    for(int ch=0;ch<2;++ch) for(int i=0;i<4410;++i)
        input.setSample(ch,i,(ch?0.3f:0.7f)*std::sin(i*0.071f));
    juce::XmlElement state("ReverseBloomState");
    BloomState::encode(state,input,44100.0);
    auto restored=BloomState::decode(state);
    check(restored.audio && restored.rate==44100.0,"Capture decode failed");
    check(restored.audio->getNumSamples()==4410,"Capture size mismatch");
    for(int ch=0;ch<2;++ch) for(int i=0;i<4410;++i)
        check(restored.audio->getSample(ch,i)==input.getSample(ch,i),"Capture not lossless");
    auto xml=juce::parseXML(state.toString());
    check(xml && BloomState::decode(*xml).audio!=nullptr,"XML round trip failed");
    state.getChildByName("BloomCapture")->setAttribute("samples",2147483647);
    check(!BloomState::decode(state).audio,"Oversized capture accepted");
    state.getChildByName("BloomCapture")->setAttribute("samples",4410);
    state.getChildByName("BloomCapture")->getFirstChildElement();
    juce::XmlElement invalid("ReverseBloomState");
    auto* child=invalid.createNewChildElement("BloomCapture");
    child->setAttribute("version",1); child->setAttribute("samples",100); child->setAttribute("rate",44100.0);
    child->addTextElement("corrupt"); check(!BloomState::decode(invalid).audio,"Corrupt data accepted");
    juce::XmlElement legacy("ReverseBloomState");
    check(!BloomState::decode(legacy).audio,"Legacy state rejected incorrectly");
    for(double rate : {8000.0,44100.0,48000.0,96000.0,192000.0})
    {
        auto converted=BloomState::resample(input,44100.0,rate);
        check(converted->getNumSamples()==(int)std::round(4410*rate/44100.0),"Resample length incorrect");
        for(int ch=0;ch<2;++ch) for(int i=0;i<converted->getNumSamples();++i)
            check(std::isfinite(converted->getSample(ch,i)),"Resample produced NaN");
    }
    std::atomic<bool> cancel{false}; RenderSettings s;
    s.sampleRate=44100; s.lengthIndex=0; s.depth=0; s.reverseSource=0.7f;
    s.autoGain=false;
    auto raw=BloomRenderer::render(input,s,cancel);
    s.autoGain=true; auto normal=BloomRenderer::render(input,s,cancel);
    check(raw && normal,"Render failed");
    float rawPeak=juce::jmax(raw->getMagnitude(0,0,raw->getNumSamples()),raw->getMagnitude(1,0,raw->getNumSamples()));
    const float factor=juce::jmin(16.0f,0.89125f/rawPeak);
    for(int ch=0;ch<2;++ch) for(int i=0;i<raw->getNumSamples();++i)
        check(std::abs(normal->getSample(ch,i)-raw->getSample(ch,i)*factor)<0.000001f,"Auto Gain toggle incorrect");
    s.outputDb=-6.0f;
    auto quiet=BloomLive::bake(*normal,s,cancel);
    for(int ch=0;ch<2;++ch) for(int i=0;i<quiet->getNumSamples();++i)
        check(std::abs(quiet->getSample(ch,i)-normal->getSample(ch,i)*juce::Decibels::decibelsToGain(-6.0f))<0.000001f,"Output gain missing from export");
    s.outputDb=0; s.depth=0.7f;
    for(int target=0;target<3;++target) for(int shape=0;shape<4;++shape)
    {
        s.target=target;s.shape=shape;
        auto baked=BloomLive::bake(*normal,s,cancel);float filters[2]{};double phase=0;
        for(int i=0;i<normal->getNumSamples();++i)
        {
            float l=normal->getSample(0,i),r=normal->getSample(1,i);
            BloomLive::processPhase(l,r,phase,s,filters);
            phase+=BloomLive::frequency(s)/s.sampleRate;phase-=std::floor(phase);
            check(std::abs(l-baked->getSample(0,i))<0.0001f && std::abs(r-baked->getSample(1,i))<0.0001f,"Integrated phase/static mismatch");
        }
    }
    RenderSettings extended=s;
    extended.lengthInMs=true;extended.lengthMs=350;extended.depth=0;extended.reverseSource=0.4f;
    extended.tailFadeMs=20;extended.lowCut=160;extended.highCut=7000;
    for(double sr:{22050.0,44100.0,48000.0,96000.0}) {
        extended.sampleRate=sr;
        auto filtered=BloomRenderer::render(input,extended,cancel);
        check(filtered && filtered->getNumSamples()==(int)std::round(0.350*sr),"Milliseconds length incorrect");
        for(int ch=0;ch<2;++ch) for(int i=0;i<filtered->getNumSamples();++i) check(std::isfinite(filtered->getSample(ch,i)),"Extended renderer NaN");
    }
    std::cout<<"PASS: millisecond lengths, fades/filters finite at 4 sample rates\n";
    std::cout << "PASS: lossless capture/XML roundtrip, bounds/corruption/legacy, 5 sample rates, Auto Gain, Output in export, integrated-phase parity (12 LFO modes)\n";
}

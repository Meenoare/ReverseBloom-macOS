#include "Renderer.h"
#include <cassert>
#include <iostream>
#include <random>
namespace LegacyRenderer{std::shared_ptr<juce::AudioBuffer<float>> render(const juce::AudioBuffer<float>&,const RenderSettings&,const std::atomic<bool>&);}
int main(){
 std::atomic<bool> cancel{false};
 for(double sr:{44100.,48000.,96000.}){
  juce::AudioBuffer<float> source(2,2048);std::mt19937 rng(7);std::uniform_real_distribution<float> noise(-.3f,.3f);
  for(int i=0;i<2048;++i)for(int c=0;c<2;++c)source.setSample(c,i,noise(rng));
  RenderSettings s;s.sampleRate=sr;s.lengthInMs=true;s.lengthMs=700;s.depth=0;s.autoGain=false;
  auto reference=BloomRenderer::render(source,s,cancel);assert(reference);
  auto legacy=LegacyRenderer::render(source,s,cancel);assert(legacy&&legacy->getNumSamples()==reference->getNumSamples());
  for(int i=0;i<reference->getNumSamples();++i)for(int c=0;c<2;++c)assert(reference->getSample(c,i)==legacy->getSample(c,i));
  for(int kind=0;kind<3;++kind){s.reverbType=kind;auto result=BloomRenderer::render(source,s,cancel);assert(result&&result->getNumSamples()==reference->getNumSamples());double difference=0,energy=0;
   for(int i=0;i<result->getNumSamples();++i)for(int c=0;c<2;++c){auto v=result->getSample(c,i);assert(std::isfinite(v));energy+=v*v;difference+=std::abs(v-reference->getSample(c,i));}
   assert(energy>1.e-8);if(kind)assert(difference>.01);
  }
  s.reverbType=0;s.preDelayMs=80;auto delayed=BloomRenderer::render(source,s,cancel);double diff=0;for(int i=0;i<reference->getNumSamples();++i)diff+=std::abs(delayed->getSample(0,i)-reference->getSample(0,i));assert(diff>.01);
  s.customCurve=true;s.curve1=.04f;s.curve2=.16f;s.curve3=.45f;float previous=-1;for(int i=0;i<=1000;++i){const float y=BloomRenderer::envelope(i/1000.f,s);assert(y>=previous&&y>=0&&y<=1);previous=y;}assert(BloomRenderer::envelope(0,s)==0&&BloomRenderer::envelope(1,s)==1);
  s.curve1=.25f;s.curve2=.5f;s.curve3=.75f;for(int i=0;i<=1000;++i)assert(std::abs(BloomRenderer::envelope(i/1000.f,s)-i/1000.f)<1.e-6);
  auto shaped=BloomRenderer::render(source,s,cancel);assert(shaped);cancel=true;assert(!BloomRenderer::render(source,s,cancel));cancel=false;
 }
 std::cout<<"PASS: Room/Hall/Plate finite and distinct; pre-delay audible data changes; fixed duration; monotone curve endpoints; cancellation; 44.1/48/96kHz\n";
}

#include "PreviewTimeline.h"
#include <iostream>
#include <stdexcept>
#include <cmath>
static void check(bool v,const char* message) { if(!v) throw std::runtime_error(message); }
int main()
{
    using namespace BloomPreview;
    for(int sr : {44100,48000,96000})
        for(int gapMs : {0,50,200})
            for(int pauseMs : {0,250,1000})
            {
                Timeline t{sr*2,sr*gapMs/1000,sr/3,sr*pauseMs/1000};
                int counts[5]{};
                for(std::int64_t p=0;p<t.total();++p)
                {
                    const auto f=t.at(p);check(f.stage!=idle,"Unexpected idle sample");++counts[f.stage];
                    const int limit=f.stage==tail?t.tailSamples:f.stage==gap?t.gapSamples:f.stage==source?t.sourceSamples:t.pauseSamples;
                    check(f.offset>=0 && f.offset<limit,"Out of range frame");
                }
                check(counts[tail]==t.tailSamples && counts[gap]==t.gapSamples && counts[source]==t.sourceSamples && counts[pause]==t.pauseSamples,"Wrong segment length");
                check(t.at(-1).stage==idle && t.at(t.total()).stage==idle,"End boundary incorrect");
                check(t.at(t.tailSamples+t.gapSamples).stage==source,"Source onset incorrect");
            }
    Timeline only{100,0,0,0};check(only.at(99).stage==tail && only.at(100).stage==idle,"Tail-only boundary");
    check(remap(50,100,200)==100,"Tail relative mapping");
    check(remap(125,100,200)==225,"Source/gap offset mapping");
    check(remap(250,200,100)==150,"Shorter tail offset mapping");
    for(int n : {1,2,10,100,48000}) for(int i=0;i<n;++i)
    {const float g=edgeGain(i,n,48);check(std::isfinite(g) && g>=0 && g<=1,"Invalid fade");}
    check(edgeGain(0,100,10)==0 && edgeGain(99,100,10)==0 && edgeGain(50,100,10)==1,"Fade endpoints");
    // Simulate three loops and verify every segment is visited exactly once per loop.
    Timeline t{100,5,40,10};int endings=0;std::int64_t p=0;
    for(int i=0;i<3*t.total();++i) { if(p==t.total()){p=0;++endings;}check(t.at(p).stage!=idle,"Loop gap");++p; }
    check(endings==2 && p==t.total(),"Full-sequence loop incorrect");
    std::cout<<"PASS: 27 sample-rate/gap/pause timelines, exact segment counts/onsets, tail-only, length remap, fade bounds, full-sequence loop\n";
}

#include "Renderer.h"
#include "LiveEngine.h"
#include <iostream>
#include <cmath>
#include <stdexcept>
static void require (bool ok, const char* message)
{ if (!ok) throw std::runtime_error (message); }
int main()
{
    std::atomic<bool> cancel {false};
    RenderSettings s; s.sampleRate = 44100; s.bpm = 120; s.lengthIndex = 1;
    s.depth = 0; s.target = 0;
    juce::AudioBuffer<float> input (2,4410); input.clear();
    for (int ch=0;ch<2;++ch) input.setSample (ch,0,0.5f);
    auto base = BloomRenderer::render (input,s,cancel);
    require (base && base->getNumSamples() == 44100,"Incorrect half-bar length");
    auto neutral = BloomLive::bake (*base,s,cancel);
    require (neutral != nullptr,"Neutral LFO bake failed");
    for (int i=0;i<44100;++i)
        require (neutral->getSample (0,i)==base->getSample (0,i),"Depth zero changed volume");
    for (int target=0;target<3;++target)
        for (int shape=0;shape<4;++shape)
        {
            s.target=target; s.shape=shape; s.depth=1;
            auto out = BloomLive::bake (*base,s,cancel);
            require (out != nullptr,"Bake failed");
            float filter[2] {};
            for (int i=0;i<44100;++i)
            {
                float l=base->getSample(0,i), r=base->getSample(1,i);
                BloomLive::process(l,r,i/s.sampleRate,s,filter);
                require (std::isfinite(l) && std::isfinite(r),"Non-finite output");
                require (l==out->getSample(0,i) && r==out->getSample(1,i),"Live/bake mismatch");
            }
        }
    cancel.store(true);
    require (!BloomLive::bake(*base,s,cancel),"Cancellation ignored");
    std::cout << "PASS: length, depth zero, 12 target/shape combinations, live/bake parity, cancellation\n";
}

# ReverseBloom 0.8.1 / Graphite Amber

Native C++/JUCE UI, no embedded browser or React dependency.
Reference: user-supplied RB image. One visible waveform, RAW/EDIT modes, no percent under Reverse.
Style: graphite surfaces, subtle hardware bevels, amber source/Reverse and violet result/modulation.
UI/UX Pro Max was read and queried from nextlevelbuilder/ui-ux-pro-max-skill.
Applied guidance: semantic colour tokens, clear focus/pressed/disabled states, progressive disclosure, restrained motion.
Desktop adaptation: web landing-page conversion recommendations and mobile safe-area rules do not apply.
Controls remain native JUCE widgets and retain parameter attachments.
Measured base contrast: secondary text/surface 8.88:1, primary text/raised 13.31:1, primary action 10.10:1.
These measurements do not certify overall accessibility: scaled text, screen readers and keyboard routing in DAWs require runtime testing.

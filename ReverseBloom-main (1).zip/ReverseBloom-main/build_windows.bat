@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul
if errorlevel 1 (
  echo ERROR: Install CMake and add it to PATH, then reopen this terminal.
  pause
  exit /b 1
)
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
if errorlevel 1 goto failed
cmake --build build --config Release --target ReverseBloom_VST3 ReverseBloom_Standalone --parallel 2
if errorlevel 1 goto failed
echo.
echo SUCCESS. VST3 bundle:
echo build\ReverseBloom_artefacts\Release\VST3\ReverseBloom.vst3
echo Copy the ENTIRE ReverseBloom.vst3 directory to:
echo C:\Program Files\Common Files\VST3\
echo Then rescan plugins in FL Studio.
pause
exit /b 0
:failed
echo Build failed. Run from a terminal to save the compiler output.
pause
exit /b 1
